package be.kdg.integratieprojectapp.activities;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.EditText;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.User.Token;
import be.kdg.integratieprojectapp.model.User.User;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginActivity extends AppCompatActivity {


    //Butterknife binding views
    @BindView(R.id.etUsername) EditText etUsername;
    @BindView(R.id.etPassword) EditText etPassword;
    @BindView(R.id.input_layout_username_login) TextInputLayout userWrapper ;
    @BindView(R.id.input_layout_password_login) TextInputLayout passwordWrapper ;

    private Datamanager datamanager = Datamanager.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        //bind the views
        ButterKnife.bind(this);

    }

    //validate a form
    private boolean validateForm() {

        if (etUsername.getText().toString().trim().isEmpty()) {
            userWrapper.setError(getString(R.string.err_msg_empty));
            etUsername.requestFocus();
            return false;
        }else if (etPassword.getText().toString().trim().isEmpty()) {
            passwordWrapper.setError(getString(R.string.err_msg_empty));
            etPassword.requestFocus();
            return false;
        }

        return true;
    }

    //login a user
    @OnClick(R.id.btnRegister)
    public void login(){
    //validate
        if(validateForm()) {
            final ProgressDialog progressDialog = ProgressDialog.show(this,"Inloggen","Inloggen",true);

            final DataService loginService =
                    Connector.connection(DataService.class, etUsername.getText().toString(), etPassword.getText().toString());

            Call<Token> call = loginService.basicLogin("password",etUsername.getText().toString(),etPassword.getText().toString());

            call.enqueue(new Callback<Token>() {
                @Override
                public void onResponse(Call<Token> call, Response<Token> response) {
                    if (response.isSuccessful()) {
                        setToken(response.body());
                        getUser(response.body().getUserID());
                        progressDialog.dismiss();
                    } else {
                            progressDialog.dismiss();
                            new AlertDialog.Builder(LoginActivity.this).setTitle("Fout").setMessage("Kan niet inloggen").show();
                    }
                }

                @Override
                public void onFailure(Call<Token> call, Throwable t) {
                    Log.d("User", "failure " + t.getMessage());

                }
            });

        }
    }

    //get user if login was succesful
    public void getUser(final String id){
            DataService loginService = Connector.connection(DataService.class, etUsername.getText().toString(), etPassword.getText().toString());

            Call<User> call = loginService.getUserById(id);

            call.enqueue(new Callback<User>() {
                @Override
                public void onResponse(Call<User> call, Response<User> response) {
                    if (response.isSuccessful()) {
                        datamanager.setUser(response.body());
                        datamanager.getUser().setUserId(id);
                        startOtherActivity();

                    } else {
                        Log.d("User", "Code " + response.code() + " Message: " + response.message()   );


                    }
                }

                @Override
                public void onFailure(Call<User> call, Throwable t) {
                    Log.d("User", "failure " + t.getMessage());

                }
            });


        }

    //finish the activity
    private void startOtherActivity(){
        finish();
    }

    //set bearer token for authentication login
    private void setToken(Token token){
        Token.setInstance(token);
    }
}
