package be.kdg.integratieprojectapp.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.NavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.GravityCompat;
import android.support.v4.view.ViewPager;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.fragments.GraphFragment;
import be.kdg.integratieprojectapp.fragments.ProjectFragment;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import be.kdg.integratieprojectapp.model.User.Token;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


/**
 * Provides UI for the main screen.
 */
public class MainActivity extends AppCompatActivity {

    //Butterknife bind views
    @BindView(R.id.drawer) DrawerLayout mDrawerLayout;
    @BindView(R.id.toolbar) Toolbar toolbar;
    @BindView(R.id.viewpager) ViewPager viewPager;
    @BindView(R.id.tabs)TabLayout tabs;
    @BindView(R.id.navigation) NavigationView navigationView;


    private static BudgetLine[] primaryBudgetLines;
    //TODO remove
    private static BudgetLine[] secondaryBudgetLines;
    private PostalHead primaryPostalhead = null;
    //TODO remove
    private static PostalHead secondaryPostalhead = null;
    private static final int YEAR = 2016;
    private Datamanager datamanager;
    private Token token;
    private TextView tvUsername;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        Log.d("datamanger","get instance");
        datamanager = Datamanager.getInstance();
        setTitle(datamanager.getPostalHead().getName());
        ButterKnife.bind(this);

        // Adding Toolbar to Main screen
        setSupportActionBar(toolbar);
        // Setting ViewPager for each Tabs
        setupViewPager(viewPager);
        // Set Tabs inside Toolbar
        tabs.setupWithViewPager(viewPager);



        // Adding menu icon to Toolbar
        ActionBar supportActionBar = getSupportActionBar();
        if (supportActionBar != null) {
            supportActionBar.setHomeAsUpIndicator(R.drawable.ic_menu_white_24dp);
            supportActionBar.setDisplayHomeAsUpEnabled(true);
        }



        // Set behavior of Navigation drawer
        navigationView.setNavigationItemSelectedListener(
                new NavigationView.OnNavigationItemSelectedListener() {
                    // This method will trigger on item Click of navigation menu
                    @Override
                    public boolean onNavigationItemSelected(MenuItem menuItem) {

                        switch (menuItem.toString()){
                            case "Aanmelden":
                                Intent loginIntent = new Intent(MainActivity.this,LoginActivity.class);
                                startActivity(loginIntent);
                                break;
                            case "Profiel":
                                Intent profileIntent = new Intent(MainActivity.this,ProfileActivity.class);
                                startActivity(profileIntent);
                                break;
                            case "Afmelden":
                                logOut();
                                break;
                            case "Home":
                                Log.d("item",menuItem.toString());
                                break;
                            case "Belasting berekenen":
                                Intent taxIntent = new Intent(MainActivity.this,TaxActivity.class);
                                startActivity(taxIntent);
                                break;
                            case "Gemeente vergelijken":
                                Intent compareIntent = new Intent(MainActivity.this,CompareBudget.class);
                                startActivity(compareIntent);
                                break;
                            case "Verander gemeente":
                                Log.d("activity change", "change");
                                Intent changeIntent = new Intent(MainActivity.this,PostalCodeActivity.class);
                                startActivity(changeIntent);
                                break;
                            case "Over ons":
                                Log.d("activity change", "change");
                                Intent AboutIntent = new Intent(MainActivity.this,AboutActivity.class);
                                startActivity(AboutIntent);
                                break;
                            default:
                                Log.e("Error","Unknown action");
                        }

                        // Closing drawer on item click
                        mDrawerLayout.closeDrawers();
                        return true;
                    }
                });
        View headerLayout = navigationView.getHeaderView(0);
        tvUsername = (TextView) headerLayout.findViewById(R.id.tvUsernameNavigation);
        updateNav();
    }



    @Override
    protected void onStart() {
        super.onStart();
        //needed because data gets reset on resume
        datamanager = Datamanager.getInstance();
        token = Token.getInstance();
        //if token is set update the navigationdrawer
        if( datamanager.getUser() != null){
            getUserPropositions();
            updateNav();
        }
    }

    //retrofit get user propositions from user
    public void getUserPropositions(){
        final DataService service = datamanager.getConnector().connection();

        final Call<Proposition[]> call = service.getPropositionByUserId(datamanager.getUser().getUserId());
        call.enqueue(new Callback<Proposition[]>() {
            @Override
            public void onResponse(Call<Proposition[]> call, Response<Proposition[]> response) {
                if (response.isSuccessful()) {

                    datamanager.setUserPropositions(response.body());
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Project Error" + response.code());
                }
            }

            @Override
            public void onFailure(Call<Proposition[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Project Crash: " + t.getMessage());
            }
        });
    }

    //update navigation with different menuitems and a username
    public void updateNav(){

        if(datamanager.getUser() != null) {
            if(tvUsername == null)
                Log.d("null","null");
            tvUsername.setText("Welkom, " + datamanager.getUser().getUserName());
            tvUsername.setVisibility(View.VISIBLE);
            Menu menuNav = navigationView.getMenu();
            MenuItem item = menuNav.findItem(R.id.LogIn);
            item.setVisible(false);
            item = menuNav.findItem(R.id.LogOut);
            item.setVisible(true);
            item = menuNav.findItem(R.id.Profile);
            item.setVisible(true);
            findViewById(R.id.drawer).invalidate();
        }else{
            tvUsername.setVisibility(View.INVISIBLE);
            Menu menuNav = navigationView.getMenu();
            MenuItem item = menuNav.findItem(R.id.LogIn);
            item.setVisible(true);
            item = menuNav.findItem(R.id.LogOut);
            item.setVisible(false);
            item = menuNav.findItem(R.id.Profile);
            item.setVisible(false);
            findViewById(R.id.drawer).invalidate();
        }
    }

    //logout a user
    private void logOut(){
        datamanager.setUser(null);
        datamanager.setToken(null);
        updateNav();

    }

    // Add Fragments to Tabs
    private void setupViewPager(ViewPager viewPager) {
        Adapter adapter = new Adapter(getSupportFragmentManager());

        adapter.addFragment(new GraphFragment(), "Grafiek");
        adapter.addFragment(new ProjectFragment(), "Project");


        viewPager.setAdapter(adapter);
    }


    //create the adapter for tabs with fragmentlists and title lists
    static class Adapter extends FragmentPagerAdapter {
        private final List<Fragment> mFragmentList = new ArrayList<>();
        private final List<String> mFragmentTitleList = new ArrayList<>();

        public Adapter(FragmentManager manager) {
            super(manager);
        }

        @Override
        public Fragment getItem(int position) {
            return mFragmentList.get(position);
        }

        @Override
        public int getCount() {
            return mFragmentList.size();
        }

        public void addFragment(Fragment fragment, String title) {
            mFragmentList.add(fragment);
            mFragmentTitleList.add(title);
        }

        @Override
        public CharSequence getPageTitle(int position) {
            return mFragmentTitleList.get(position);
        }
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();
        //noinspection SimplifiableIfStatement
         if (id == android.R.id.home) {
            mDrawerLayout.openDrawer(GravityCompat.START);
        }
        return super.onOptionsItemSelected(item);
    }

    public static BudgetLine[] getprimaryBudgetLines() {
        return primaryBudgetLines;
    }

    public static BudgetLine[] getSecondaryBudgetLines() {
        return secondaryBudgetLines;
    }

    public void setSecondaryBudgetLines(BudgetLine[] secondaryBudgetLines) {
        MainActivity.secondaryBudgetLines = secondaryBudgetLines;
    }

    public void setPrimaryBudgetLines(BudgetLine[] primaryBudgetLines) {
        MainActivity.primaryBudgetLines = primaryBudgetLines;
    }

    public PostalHead getprimaryPostalhead() {
        return primaryPostalhead;
    }

    public static PostalHead getSecondaryPostalhead() {
        return secondaryPostalhead;
    }

    public static void setSecondaryPostalhead(PostalHead secondaryPostalhead) {
        MainActivity.secondaryPostalhead = secondaryPostalhead;
    }

    public static int getYEAR() {
        return YEAR;
    }
}

