package be.kdg.integratieprojectapp.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import be.kdg.integratieprojectapp.model.Project.Project;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PostalCodeActivity extends AppCompatActivity {
    //Butterknife bindings
    @BindView(R.id.etPostalCodeMAin) EditText etPostalcode;
    @BindView(R.id.btnPostalCode) Button button;
    @BindView(R.id.input_layout_postalcode) TextInputLayout postalWrapper ;

    private Datamanager datamanager;
    private Connector connector;
    private ProgressDialog progressDialog;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_postalcode);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        setTitle("");
        ButterKnife.bind(this);
    }


    @OnClick(R.id.btnPostalCode)
    public void sendPostalCode(){
        if(validatePostalcode()) {
            int postalcode = Integer.parseInt(etPostalcode.getText().toString());
            datamanager =Datamanager.getInstance(postalcode);
            connector = datamanager.getConnector();
            getProjectByPostal(postalcode);
            getPostalHeadName(postalcode);

        }
    }

    //validate postalcode
    private boolean validatePostalcode() {
        if (etPostalcode.getText().toString().trim().isEmpty()) {
            postalWrapper.setError(getString(R.string.err_msg_empty));
            etPostalcode.requestFocus();
            return false;
        }else if(Integer.parseInt(etPostalcode.getText().toString().trim()) < 1000){
            postalWrapper.setError(getString(R.string.err_msg_postalcode_smaller));
            etPostalcode.requestFocus();
            return false;
        }else if(Integer.parseInt(etPostalcode.getText().toString().trim()) > 9999){
            postalWrapper.setError(getString(R.string.err_msg_postalcode_larger));
            etPostalcode.requestFocus();
            return false;
        } else {
            postalWrapper.setErrorEnabled(false);
        }

        return true;
    }

    //retrofit get postalhead with postalcode
    public void getPostalHeadName(final int postalcode){
        progressDialog = ProgressDialog.show(this,"Gegevens postcode laden","Laden...",true);


        final DataService service = connector.connection();

        Call<PostalHead> call = service.getPostalHeadName(postalcode);
        call.enqueue(new Callback<PostalHead>() {
            @Override
            public void onResponse(Call<PostalHead> call, Response<PostalHead> response) {
                if (response.isSuccessful()) {
                    datamanager.setPostalHead(response.body());
                    progressDialog.dismiss();

                    getBudgetJson(postalcode,service);

                    //loadMainCategory();
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error" + response.code());
                }
            }

            @Override
            public void onFailure(Call<PostalHead> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Postal Crash: " + t.getMessage());
            }
        });

    }

    //retrofit get projects with postalcode
    public void getProjectByPostal(int postalcode){


        final DataService service = connector.connection();

        Call<Project[]> call = service.getProjectByPostal(postalcode);
        call.enqueue(new Callback<Project[]>() {
            @Override
            public void onResponse(Call<Project[]> call, Response<Project[]> response) {
                if (response.isSuccessful()) {

                    datamanager.setProjects(response.body());
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Project Error" + response.code());
                }
            }

            @Override
            public void onFailure(Call<Project[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Project Crash: " + t.getMessage());
            }
        });

    }

    //retrofit get budgetlines with prostalcodes
    public void getBudgetJson(final int postalcode, DataService dataService){


        progressDialog = ProgressDialog.show(this,"Begroting "+ datamanager.getPostalHead().getName() +" laden","Laden...",true);

        final DataService service = dataService;

        Call<BudgetLine[]> call = service.getYearCityBudget(2016,postalcode);
        call.enqueue(new Callback<BudgetLine[]>() {
            @Override
            public void onResponse(Call<BudgetLine[]> call, Response<BudgetLine[]> response) {
                if (response.isSuccessful()) {
                    datamanager.setPrimaryBudgetLines(response.body());

                    if(datamanager.getPrimaryBudgetLines().length == 0){
                        showAlertEmptyBudgetlines();
                    }else{
                        Intent intent = new Intent(PostalCodeActivity.this, MainActivity.class);
                        startActivity(intent);
                    }
                    progressDialog.dismiss();


                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Budget Error");
                }
            }

            @Override
            public void onFailure(Call<BudgetLine[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Budget: " + t.getMessage());
            }
        });
    }

    //show alert box if there is no budgetlines found
    public void showAlertEmptyBudgetlines(){

        new AlertDialog.Builder(this).setMessage(R.string.alert_message_empty_budgetlines)
                .setTitle(R.string.alert_message_title_error_empty).show();



    }
}
