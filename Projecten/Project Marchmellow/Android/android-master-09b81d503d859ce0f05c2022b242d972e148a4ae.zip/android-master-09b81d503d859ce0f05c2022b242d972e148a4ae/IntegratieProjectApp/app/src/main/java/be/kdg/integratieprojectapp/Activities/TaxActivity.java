package be.kdg.integratieprojectapp.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.Spinner;

import com.github.mikephil.charting.charts.PieChart;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.graph.Graph;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class TaxActivity extends AppCompatActivity {
    //Butterknife bindings
    @BindView(R.id.btnCalculateTax) Button btn;
    @BindView(R.id.spJobType) Spinner spinner;
    @BindView(R.id.etSalary) EditText etSalary;

    private Datamanager datamanager = Datamanager.getInstance();
    private double percentage ;

    private static final double RSZ = 0.1307;


    private Graph graph ;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tax);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        this.setTitle("Belasting berekenen");
        getTax(datamanager.getPostalHead().getPostalCode());
        ButterKnife.bind(this);


        LinearLayout linearLayout = (LinearLayout) findViewById(R.id.includeGraph);
        PieChart pieChart = (PieChart) linearLayout.findViewById(R.id.chart);
        graph = new Graph(datamanager.getPrimaryBudgetLines(),pieChart,this);

        // Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this, R.array.JobType, android.R.layout.simple_spinner_item);
        // Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        // Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    }

    @OnClick(R.id.btnCalculateTax)
    public void startDraw(){
        graph.drawTaxGraph(Double.parseDouble(etSalary.getText().toString()),percentage,calculateTax()*percentage);
    }

    //calculate tax returns taxable sum
    public Double calculateTax(){
        double level1 = 8710;
        double level2 = 12400;
        double level3 = 20660;
        double level4 = 37870;
        double salaryLevel1 = 0;
        double salaryLevel2 = 0;
        double salaryLevel3 = 0;
        double salaryLevel4 = 0;
        double salaryLevel5 = 0;
        double yearSalary = 0;

        yearSalary = Double.parseDouble(etSalary.getText().toString());
        yearSalary = yearSalary*12;

        //RSZ deduction
        if(spinner.getSelectedItem().equals("Arbeider")) {
            Log.d("if","arbeider");
            yearSalary = yearSalary - (yearSalary * 1.08) * RSZ;
        }
        else {
            Log.d("if","bediende");
            yearSalary = yearSalary - (yearSalary) * RSZ;
        }

        //25%
        salaryLevel1 = 0.25*Math.min(Math.max(yearSalary,0),level1);

        //30%
        salaryLevel2 = 0.3*Math.min(Math.max(yearSalary-level1,0),(level2-(level1+1)));

        //40%
        salaryLevel3 = 0.4*Math.min(Math.max(yearSalary-level2,0),(level3-(level2 +1)));

        //45%
        salaryLevel4 = 0.45*Math.min(Math.max(yearSalary-level3,0),(level4-(level3 +1)));

        //50%
        salaryLevel5 = 0.5*Math.max(yearSalary-level4,0);

        double totalAllLevels = salaryLevel1+salaryLevel2+salaryLevel3+salaryLevel4+salaryLevel5;
        double taxfree = ((Double.parseDouble(etSalary.getText().toString())*12) < 7090)?(Double.parseDouble(etSalary.getText().toString())*12)*0.25:7090*0.25;

        double totalTax = totalAllLevels - taxfree;

        return totalTax;

    }

    //get tax from postalcode
    public void getTax(int postalcode){
        DataService service = Connector.connection();

        Call<Double> call = service.getTax(postalcode);
        final double[] tax = new double[1];

        call.enqueue(new Callback<Double>() {
            @Override
            public void onResponse(Call<Double> call, Response<Double> response) {
                if (response.isSuccessful()) {
                    Log.d("response",response.body()+"");
                    percentage = response.body()/100;

                } else {
                    Log.d("User", "Code " + response.code() + " Message: " + response.message()   );


                }
            }

            @Override
            public void onFailure(Call<Double> call, Throwable t) {
                Log.d("User", "failure " + t.getMessage());

            }
        });

    }

}
