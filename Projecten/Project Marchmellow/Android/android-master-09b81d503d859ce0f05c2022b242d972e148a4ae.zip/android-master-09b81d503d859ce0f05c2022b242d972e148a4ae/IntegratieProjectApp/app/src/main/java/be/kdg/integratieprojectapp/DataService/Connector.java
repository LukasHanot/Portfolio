package be.kdg.integratieprojectapp.dataService;

import android.util.Base64;
import android.util.Log;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.IOException;

import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import be.kdg.integratieprojectapp.model.User.Token;
import okhttp3.Interceptor;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

/**
 * Creates retrofit from dataservice & intercepts requests for authorization
 */
public class Connector {
    //TODO all request through here
    private static Datamanager datamanager ;
    private static int postalcode;
    private int year;
    private static PostalHead postalHead;
    private static BudgetLine[] budgetLines;
    private static Token token;

    //for server
    //public static final String API_BASE_URL = "http://10.134.216.25:8011";

    //for localhost emulator
    public static final String API_BASE_URL = "http://10.0.2.2:5678";

    //for localhost physical device
    //public static final String API_BASE_URL = "http://192.168.43.144:5678";

    //interceptor used for debugging
    //private static HttpLoggingInterceptor logging = new HttpLoggingInterceptor().setLevel(HttpLoggingInterceptor.Level.BODY);


    private static OkHttpClient.Builder httpClient = new OkHttpClient.Builder();//.addInterceptor(logging);

    private static Retrofit retrofit ;

    private static Gson gson = new GsonBuilder().setLenient().create();

    public Connector(int postalcode, int year, Datamanager datamanager) {
        this.postalcode = postalcode;
        this.year = year;
        this.datamanager = datamanager;


    }

    public static DataService connection(){
        return connection(DataService.class, null, null);
    }

    public static DataService connection(Class<DataService> dataService, String username, String password) {
        if (username != null && password != null) {
            username = username.trim();
            password = password.trim();
            String credentials = username + ":" + password;
            final String auth;


            token = Token.getInstance();
            if(token.getAccess_token() == null) {
                Log.d("null", "isnull");
                auth = "Basic " + Base64.encodeToString(credentials.getBytes(), Base64.NO_WRAP);
            }
            else{
                Log.d("null","is not null");
                auth = "Bearer " + token.getAccess_token();
            }


            httpClient.addInterceptor(new Interceptor() {
                @Override
                public okhttp3.Response intercept(Chain chain) throws IOException {
                    Request original = chain.request();



                    Request.Builder requestBuilder = original.newBuilder()
                            .header("Authorization", auth)
                            .header("accept","application/json")
                            .header("grant_type","client_credentials")
                            .method(original.method(), original.body());

                    Request request = requestBuilder.build();
                    return chain.proceed(request);
                }
            });
        }


        Retrofit retrofit = new Retrofit.Builder()
                .baseUrl(API_BASE_URL)
                .addConverterFactory(GsonConverterFactory.create(gson))
                .client(httpClient.build())
                .build();
        return retrofit.create(dataService);
    }




    public void getBudgetLinesAPI(final boolean primary) throws IOException {

        DataService service = connection();



        Call<BudgetLine[]> call = service.getYearCityBudget(year,postalcode);
        call.enqueue(new Callback<BudgetLine[]>() {
            @Override
            public void onResponse(Call<BudgetLine[]> call, Response<BudgetLine[]> response) {
                if (response.isSuccessful()) {
                    if(primary)
                        datamanager.setPrimaryBudgetLines(response.body());
                    else
                        datamanager.setSecondaryBudgetLines(response.body());

                } else {
                    // error response, no access to resource?
                    Log.e("Error response","error response, no access to resource?");
                }
            }

            @Override
            public void onFailure(Call<BudgetLine[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error Budget", t.getMessage());
            }
        });



    }

    public void getPostalHeadAPI(final boolean primary) throws IOException {
        Log.d("getPostal","get Postal");


        Log.d("postalcode", postalcode +"");
        DataService service = connection();

        Call<PostalHead> call = service.getPostalHeadName(postalcode);
        call.enqueue(new Callback<PostalHead>() {
            @Override
            public void onResponse(Call<PostalHead> call, Response<PostalHead> response) {
                if (response.isSuccessful()) {
                        Log.d("getPostal","success");
                        postalHead = response.body();
                    datamanager.setPostalHead(postalHead);
                    try {

                            getBudgetLinesAPI(primary);


                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error");
                }
            }

            @Override
            public void onFailure(Call<PostalHead> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Postal Crash");
            }
        });


    }

    public PostalHead getPostalHead() {
        return postalHead;
    }

    public static BudgetLine[] getBudgetLines() {
        return budgetLines;
    }

    public static void setBudgetLines(BudgetLine[] budgetLines) {
        Connector.budgetLines = budgetLines;
    }

}
