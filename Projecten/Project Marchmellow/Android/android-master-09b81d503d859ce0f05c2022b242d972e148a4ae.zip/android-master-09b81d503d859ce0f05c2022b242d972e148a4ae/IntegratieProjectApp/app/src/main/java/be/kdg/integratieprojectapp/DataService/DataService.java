package be.kdg.integratieprojectapp.dataService;

import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import be.kdg.integratieprojectapp.model.Project.Project;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import be.kdg.integratieprojectapp.model.User.Token;
import be.kdg.integratieprojectapp.model.User.User;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.GET;
import retrofit2.http.POST;
import retrofit2.http.Path;

/**
 * Created by jeroe on 20/04/2016.
 */
public interface DataService {

    //get postalhead for a postalcode
    @GET("api/{postal}")
    Call<PostalHead> getPostalHeadName(@Path("postal") int postal);

    //get budget for a year and a postalcode
    @GET("api/Budget/{year}/{postal}")
    Call<BudgetLine[]> getYearCityBudget(@Path("year") int year,@Path("postal") int postal);

    //get get user for userid
    @GET("api/User/{id}/full")
    Call<User> getUserById(@Path("id") String id);

    //get get user for userid
    @GET("api/User/{id}")
    Call<String> getUsernameById(@Path("id") String id);

    //get project for postalcode
    @GET("api/Project/{postalcode}")
    Call<Project[]> getProjectByPostal(@Path("postalcode") int postalcode);

    //get propositions for project with project nr
    @GET("api/Proposition/Project/{projnr}")
    Call<Proposition[]> getPropositionByProjnr(@Path("projnr") int projnr);

    //get propositions for user with userid
    @GET("api/Proposition/User/{userId}")
    Call<Proposition[]> getPropositionByUserId(@Path("userId") String userId);

    //get a proposition with propositionid
    @GET("api/Proposition/{propId}")
    Call<Proposition> getPropositionById(@Path("propId") int userId);

    //get comments for a proposition with propositionid
    @GET("api/comments/{propId}")
    Call<Comment[]> getComments(@Path("propId") int propId);

    //get comments for a proposition with propositionid
    @GET("api/Proposition/UpVote/{propId}/{userId}")
    Call<Void> voteUp(@Path("propId") int propId,@Path("userId") String userId);

    //get comments for a proposition with propositionid
    @GET("api/Proposition/Vote/{propId}/{userId}")
    Call<Boolean> voted(@Path("propId") int propId,@Path("userId") String userId);

    //get tax percentage for postalcode
    @GET("api/Postalcode/tax/{postalcode}")
    Call<Double> getTax(@Path("postalcode") int postalcode);

    //get bearer token for user with username and password
    @FormUrlEncoded
    @POST("/token")
    Call<Token> basicLogin(@Field("grant_type") String grantType, @Field("UserName") String username, @Field("Password") String paswoord);
}
