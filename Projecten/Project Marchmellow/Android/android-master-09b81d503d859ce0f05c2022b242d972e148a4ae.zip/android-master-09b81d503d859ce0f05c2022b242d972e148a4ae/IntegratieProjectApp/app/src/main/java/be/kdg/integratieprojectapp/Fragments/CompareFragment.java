package be.kdg.integratieprojectapp.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.github.mikephil.charting.charts.PieChart;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.activities.CompareBudget;
import be.kdg.integratieprojectapp.activities.MainActivity;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.graph.Graph;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//first fragment of the compare feature
public class CompareFragment extends Fragment  {

    //butterknife bindigs
    @BindView(R.id.btnChange) Button btnChange;
    @BindView(R.id.etPostalCompare) EditText etPostal;

    private PieChart pieChartMain;
    private Button btnBack;

    private Datamanager datamanager = Datamanager.getInstance();
    private Graph graph ;

    private ProgressDialog progressDialog;

    private static BudgetLine[] tempBudgetLines;
    private PostalHead tempPostalHead;
    private Connector connector = datamanager.getConnector();

    public CompareFragment() {
        // Required empty public constructor
    }

    public static CompareFragment newInstance(String param1, String param2) {
        CompareFragment fragment = new CompareFragment();
        Bundle args = new Bundle();
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_compare, container, false);

        ButterKnife.bind(this,v);
        LinearLayout linearLayout = (LinearLayout) v.findViewById(R.id.includeGraph);
        pieChartMain = (PieChart) linearLayout.findViewById(R.id.chart);
        btnBack = (Button) linearLayout.findViewById(R.id.btnBack);
        tempGraph();
        return v;
    }

    public void tempGraph(){
        graph = new Graph(datamanager.getPrimaryBudgetLines(),pieChartMain,getActivity());
        graph.loadGraph(-1);





        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(graph.isLevel2()) {

                    graph.loadLastGraph(-1);
                }
                else
                    graph.loadLastGraph(graph.getLevel1Id());
            }
        });
    }


    public void drawGraph(){
        graph = new Graph(tempBudgetLines,pieChartMain,getActivity());
        graph.loadGraph(-1);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(graph.isLevel2()) {

                    graph.loadLastGraph(-1);
                }
                else
                    graph.loadLastGraph(graph.getLevel1Id());
            }
        });
    }

    @OnClick(R.id.btnChange)
    public void getData(){
        getPostalHead(Integer.parseInt(etPostal.getText().toString()));
    }

    //retrofi call to get postalhead from postalcode
    public void getPostalHead(final int postalcode){

        progressDialog = ProgressDialog.show(getActivity(),"Gegevens postcode laden","Laden...",true);


        DataService service = connector.connection();

        Call<PostalHead> call = service.getPostalHeadName(postalcode);
        call.enqueue(new Callback<PostalHead>() {
            @Override
            public void onResponse(Call<PostalHead> call, Response<PostalHead> response) {
                if (response.isSuccessful()) {
                    setTempPostalHead(response.body());

                    progressDialog.dismiss();
                    ((CompareBudget) getActivity()).updateViewPager((datamanager.getSecondaryPostalHead() != null)?datamanager.getSecondaryPostalHead().getName():"Kies gemeente",tempPostalHead.getName());
                    getBudgetJson(tempPostalHead.getPostalCode());

                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<PostalHead> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Postal Crash: " + t.getMessage());
            }
        });

    }

    //retrofit call to get Budgetlines from prostcode
    public void getBudgetJson(int postalcode){
        progressDialog = ProgressDialog.show(getActivity(),"Begroting "+ tempPostalHead.getName() +" laden","Laden...",true);

        DataService service = connector.connection();

        Call<BudgetLine[]> call = service.getYearCityBudget(MainActivity.getYEAR(),postalcode);
        call.enqueue(new Callback<BudgetLine[]>() {
            @Override
            public void onResponse(Call<BudgetLine[]> call, Response<BudgetLine[]> response) {
                if (response.isSuccessful()) {
                    setTempBudgetLines(response.body());
                    drawGraph();
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error");
                }
            }

            @Override
            public void onFailure(Call<BudgetLine[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Budget: " + t.getMessage());
            }
        });
    }

    public static void setTempBudgetLines(BudgetLine[] tempBudgetLines) {
        CompareFragment.tempBudgetLines = tempBudgetLines;
    }


    public void setTempPostalHead(PostalHead tempPostalHead) {
        this.tempPostalHead = tempPostalHead;
    }
}
