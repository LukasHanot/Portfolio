package be.kdg.integratieprojectapp.fragments;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

import com.github.mikephil.charting.charts.PieChart;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.activities.CompareBudget;
import be.kdg.integratieprojectapp.activities.MainActivity;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.graph.Graph;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//second fragment of the compare feature
public class CompareFragmentSecondary extends Fragment  {
    //butterknife bindings
    @BindView(R.id.btnChange) Button btnChange;
    @BindView(R.id.etPostalCompare) EditText etPostal;

    private Button btnBack;
    private PieChart pieChartMain;

    private ProgressDialog progressDialog;

    private Datamanager datamanager = Datamanager.getInstance();

    private Graph graph ;
    private Connector connector = datamanager.getConnector();

    public CompareFragmentSecondary() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v =inflater.inflate(R.layout.fragment_compare_fragment_secondary, container, false);
        ButterKnife.bind(this,v);
        LinearLayout linearLayout = (LinearLayout) v.findViewById(R.id.includeGraph);
        pieChartMain = (PieChart) linearLayout.findViewById(R.id.chart);
        btnBack = (Button) linearLayout.findViewById(R.id.btnBack);
        return v;
    }

    //draw graph if data is already set
    @OnClick(R.id.btnChange)
    public void getData(){
        if(datamanager.getSecondaryPostalHead() != null) {
            Log.d(" not null","not null");

            drawGraph();
        }
        else {
            Log.d(" not null","not null");
            getPostalHeadName(Integer.parseInt(etPostal.getText().toString()));
        }
    }

    //drawing graph
    public void drawGraph(){
        graph = new Graph(datamanager.getSecondaryBudgetLines(),pieChartMain,getActivity());
        graph.loadGraph(-1);


        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if(graph.isLevel2()) {

                    graph.loadLastGraph(-1);
                }
                else
                    graph.loadLastGraph(graph.getLevel1Id());
            }
        });
    }
    //retrofit call to get the postalhead
    public void getPostalHeadName(final int postalcode){
        Log.d("getPostal","get Postal");

        progressDialog = ProgressDialog.show(getActivity(),"Gegevens postcode laden","Laden...",true);


        DataService service = connector.connection();

        Call<PostalHead> call = service.getPostalHeadName(postalcode);
        call.enqueue(new Callback<PostalHead>() {
            @Override
            public void onResponse(Call<PostalHead> call, Response<PostalHead> response) {
                if (response.isSuccessful()) {
                    MainActivity.setSecondaryPostalhead(response.body());
                    progressDialog.dismiss();
                    getBudgetJson(postalcode);

                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error: " + response.code());
                }
            }

            @Override
            public void onFailure(Call<PostalHead> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Postal Crash: " + t.getMessage());
            }
        });

    }

    //retrofit call to get the Budgetlines
    public void getBudgetJson(int postalcode){
        progressDialog = ProgressDialog.show(getActivity(),"Begroting "+ MainActivity.getSecondaryPostalhead().getName() +" laden","Laden...",true);


        DataService service = connector.connection();

        Call<BudgetLine[]> call = service.getYearCityBudget(MainActivity.getYEAR(),postalcode);
        call.enqueue(new Callback<BudgetLine[]>() {
            @Override
            public void onResponse(Call<BudgetLine[]> call, Response<BudgetLine[]> response) {
                if (response.isSuccessful()) {
                    datamanager.setSecondaryBudgetLines(response.body());
                    progressDialog.dismiss();

                    ((CompareBudget) getActivity()).updateViewPager(MainActivity.getSecondaryPostalhead().getName(),datamanager.getPostalHead().getName());
                    drawGraph();
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Postal Error");
                }
            }

            @Override
            public void onFailure(Call<BudgetLine[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Budget: " + t.getMessage());
            }
        });
    }



}
