package be.kdg.integratieprojectapp.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import com.github.mikephil.charting.charts.PieChart;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.graph.Graph;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import butterknife.BindView;
import butterknife.ButterKnife;

//Fragment with the graph of the chosen city
public class GraphFragment extends Fragment {
    @BindView(R.id.chart) PieChart pieChartMain;

    private Button btnBack ;

    private Datamanager datamanager = Datamanager.getInstance();

    private Graph graph;

    public GraphFragment() {
        // Required empty public constructor
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        View v = inflater.inflate(R.layout.fragment_graph, container, false);
        ButterKnife.bind(this, v);
        Log.d("binding","binding");
        LinearLayout linearLayout = (LinearLayout) v.findViewById(R.id.includeGraph);
        pieChartMain = (PieChart) linearLayout.findViewById(R.id.chart);
        btnBack = (Button) linearLayout.findViewById(R.id.btnBack);
        drawGraph();
        return v;
    }


    public void drawGraph() {
        graph = new Graph(datamanager.getPrimaryBudgetLines(), pieChartMain, getActivity());
        graph.loadGraph(-1);

        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (graph.isLevel2()) {
                    graph.loadLastGraph(-1);
                } else
                    graph.loadLastGraph(graph.getLevel1Id());
            }
        });
    }


}





