package be.kdg.integratieprojectapp.activities;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.CollapsingToolbarLayout;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Project.ProjectType;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailProjectActivity extends AppCompatActivity {
    private RecyclerView propositionRecyclerView;
    private ContentAdapter adapter;
    private RecyclerView projectInfoRecyclerView;
    private ProjectInfoAdapter projectInfoAdapter;

    private Datamanager datamanager = Datamanager.getInstance();
    private ProgressDialog progressDialog;
    private boolean hasVoted;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);
        setSupportActionBar((Toolbar) findViewById(R.id.toolbar));
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        // Set Collapsing Toolbar layout to the screen
        CollapsingToolbarLayout collapsingToolbar =
                (CollapsingToolbarLayout) findViewById(R.id.collapsing_toolbar);
        collapsingToolbar.setTitle("Project");

        //recyclerview for propositions
        propositionRecyclerView = (RecyclerView) findViewById(R.id.proposition_recycler_view);
        adapter = new ContentAdapter();
        propositionRecyclerView.setAdapter(adapter);
        propositionRecyclerView.setHasFixedSize(true);
        propositionRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        //recyclerview for project information
        projectInfoRecyclerView = (RecyclerView) findViewById(R.id.project_recycler_view);
        projectInfoAdapter = new ProjectInfoAdapter();
        projectInfoRecyclerView.setAdapter(projectInfoAdapter);
        projectInfoRecyclerView.setHasFixedSize(true);
        projectInfoRecyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    //Create viewholder for the adapters with title and description
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView desc;


        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.list_title);
            desc = (TextView) itemView.findViewById(R.id.list_desc);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    int itemPosition = propositionRecyclerView.getChildLayoutPosition(v);
                    datamanager.setSelectedProposition(datamanager.getPropositions()[itemPosition].getNr());
                    if(datamanager.getUser() != null)
                    voted(datamanager.getSelectedProposition());
                    getProposition(context,datamanager.getPropositions()[itemPosition].getNr());
                }
            });
        }
    }

    //retrofit async call for propositions with proposition id
    public void getProposition(final Context context, final int id){
        progressDialog = ProgressDialog.show(context,"Laden","Gegevens inladen",true);

        DataService service = Connector.connection();

        Call<Proposition> call = service.getPropositionById(id);

        call.enqueue(new Callback<Proposition>() {
            @Override
            public void onResponse(Call<Proposition> call, Response<Proposition> response) {
                if (response.isSuccessful()) {

                    datamanager.setDetailProposition(response.body());

                    getComments(context,id);

                } else {
                    Log.d("Proposition", "Code " + response.code() + " Message: " + response.message()   );


                }
            }

            @Override
            public void onFailure(Call<Proposition> call, Throwable t) {
                Log.d("User", "failure " + t.getMessage());

            }
        });
    }



    //get comments for a proposition with a proposition id
    public void getComments(final Context context,int id){
        DataService service = Connector.connection();

        Call<Comment[]> call = service.getComments(id);

        call.enqueue(new Callback<Comment[]>() {
            @Override
            public void onResponse(Call<Comment[]> call, Response<Comment[]> response) {
                if (response.isSuccessful()) {
                    datamanager.setComments(response.body());

                    success(context);

                } else {
                    Log.d("Proposition", "Code " + response.code() + " Message: " + response.message()   );


                }
            }

            @Override
            public void onFailure(Call<Comment[]> call, Throwable t) {
                Log.d("User", "failure " + t.getMessage());

            }
        });
    }

    //called when getComments was succesful and start a new intent
    public void success(Context context){
        progressDialog.dismiss();
        Intent detailIntent = new Intent(context, DetailPropositionActivity.class);
        detailIntent.putExtra("voted",hasVoted);
        startActivity(detailIntent);
    }

    //adapters

    //adapter for propositions
    public class ContentAdapter extends RecyclerView.Adapter<ViewHolder> {
        Datamanager datamanager = Datamanager.getInstance();
        private Proposition[] propositions = datamanager.getPropositions();

        public ContentAdapter() {

        }

        // Create new views (invoked by the layout manager)
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent,
                                                       int viewType) {
            // create a new view
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list, parent, false);
            // set the view's size, margins, paddings and layout parameters

            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            getUsername(propositions[position].userId,holder, position);

        }

        public void setTextViewHolder(String username,ViewHolder holder, int position){
            holder.title.setText(String.valueOf(username));
            holder.desc.setText(String.valueOf(((propositions[position].getExtraInformation()==null)?"Geen extra informatie":"Extra informatie: " + propositions[position].getExtraInformation()) ));

        }
        //retrofit call to get usernames from propositions
        public void getUsername(String id, final ViewHolder holder, final int position){
            DataService Service = Connector.connection();

            Call<String> call = Service.getUsernameById(id);

            call.enqueue(new Callback<String>() {
                @Override
                public void onResponse(Call<String> call, Response<String> response) {
                    if (response.isSuccessful()) {



                        setTextViewHolder(response.body(),holder,position);

                    } else {
                        Log.d("User", "Code " + response.code() + " Message: " + response.message()   );


                    }
                }

                @Override
                public void onFailure(Call<String> call, Throwable t) {
                    Log.d("User", "failure " + t.getMessage());

                }
            });

        }



        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return propositions.length;
        }
    }

    //adapter for project info
    public class ProjectInfoAdapter extends RecyclerView.Adapter<ViewHolder> {
        Datamanager datamanager = Datamanager.getInstance();
        private Proposition[] propositions = datamanager.getPropositions();
        private List<String> labels = new ArrayList<>();
        private List<String> data = new ArrayList<>();

        public ProjectInfoAdapter() {
            createData();
        }

        private void createData(){
            labels.add("Project Type");
            labels.add("Postcode");
            labels.add("Jaar");
            labels.add("Start");
            labels.add("Einde");

            ProjectType projectType = ProjectType.values()[propositions[0].getProject().getType()];
            data.add(String.valueOf(projectType));
            data.add(String.valueOf(propositions[0].getProject().getPostalCode()));
            data.add(String.valueOf(propositions[0].getProject().getYear()));
            data.add(String.valueOf(propositions[0].getProject().getStartDate().split("T")[0]));
            data.add(String.valueOf(propositions[0].getProject().getEndDate().split("T")[0]));

        }

        // Create new views (invoked by the layout manager)
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent,
                                             int viewType) {

            // create a new view
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list, parent, false);
            // set the view's size, margins, paddings and layout parameters

            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {


            holder.title.setText(labels.get(position));
            holder.desc.setText(data.get(position));

        }



        // Return the size of your dataset (invoked by the layout manager)
        @Override
        public int getItemCount() {
            return labels.size();
        }
    }

    //check if user has already voted
    public void voted(int id){
        DataService service = Connector.connection();
        Log.d("position",id+"");
        Log.d("Userid",Datamanager.getInstance().getUser().getUserId());
        Call<Boolean> call = service.voted(id,Datamanager.getInstance().getUser().getUserId());



        call.enqueue(new Callback<Boolean>() {
            @Override
            public void onResponse(Call<Boolean> call, Response<Boolean> response) {
                if (response.isSuccessful()) {
                    hasVoted = response.body();
                } else {
                    Log.d("Vote", "Code " + response.code() + " Message: " + response.message()   );
                    new AlertDialog.Builder(DetailProjectActivity.this).setTitle("Fout").setMessage("Stemmen niet gelukt").show();

                }
            }

            @Override
            public void onFailure(Call<Boolean> call, Throwable t) {
                Log.d("Vote", "failure " + t.getMessage());

            }
        });

    }
}
