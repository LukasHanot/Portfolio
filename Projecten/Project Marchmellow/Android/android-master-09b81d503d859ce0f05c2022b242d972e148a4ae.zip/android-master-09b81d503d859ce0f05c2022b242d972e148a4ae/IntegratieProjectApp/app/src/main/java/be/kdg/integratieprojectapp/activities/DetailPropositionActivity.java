package be.kdg.integratieprojectapp.activities;

import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.like.LikeButton;
import com.like.OnLikeListener;

import java.math.BigDecimal;
import java.util.List;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Proposition.PropositionDetail;
import butterknife.BindView;
import butterknife.ButterKnife;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DetailPropositionActivity extends AppCompatActivity {

    private ContentInfoAdapter infoAdapter;
    private ContentCommentAdapter commentAdapter;
    @BindView(R.id.proposition_data_recycler_view) RecyclerView infoRecyclerView;
    @BindView(R.id.comments_recycler_view) RecyclerView commentRecyclerView;
    @BindView(R.id.star_button) LikeButton likeButton;
    private Datamanager datamanager = Datamanager.getInstance();
    private List<PropositionDetail> propositionsDetails = datamanager.getDetailProposition().details;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_proposition);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        setTitle("Details");
        ButterKnife.bind(this);
        if(Datamanager.getInstance().getUser() == null){
            likeButton.setVisibility(View.GONE);
        }else if(getIntent().getBooleanExtra("voted",false)){
            likeButton.setLiked(true);
        }

        //project info adapter
        infoRecyclerView = (RecyclerView) findViewById(R.id.proposition_data_recycler_view);
        infoAdapter = new ContentInfoAdapter();
        infoRecyclerView.setAdapter(infoAdapter);
        infoRecyclerView.setHasFixedSize(true);
        infoRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        //comment adapter
        commentRecyclerView = (RecyclerView) findViewById(R.id.comments_recycler_view);
        commentAdapter = new ContentCommentAdapter();
        commentRecyclerView.setAdapter(commentAdapter);
        commentRecyclerView.setHasFixedSize(true);
        commentRecyclerView.setLayoutManager(new LinearLayoutManager(this));

        likeButton.setOnLikeListener(new OnLikeListener() {
            @Override
            public void liked(LikeButton likeButton) {
                voteUp(Datamanager.getInstance().getSelectedProposition());
            }

            @Override
            public void unLiked(LikeButton likeButton) {
                //unliking is not implemented in back-end
                likeButton.setLiked(true);
            }
        });
    }

    //Create viewholder for the adapters with title and description
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView desc;


        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.list_title);
            desc = (TextView) itemView.findViewById(R.id.list_desc);

        }
    }
    //adapter for proposition info
    public class ContentInfoAdapter extends RecyclerView.Adapter<ViewHolder> {


        public ContentInfoAdapter() {

        }

        // Create new views (invoked by the layout manager)
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent,
                                             int viewType) {
            // create a new view
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list, parent, false);
            // set the view's size, margins, paddings and layout parameters
            ViewHolder vh = new ViewHolder(v);
            return vh;
        }



        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {


            holder.title.setText(propositionsDetails.get(position).categoryA.getName() );
            Log.d("amount" , propositionsDetails.get(position).amount +"");
            holder.desc.setText(String.valueOf("€" + new BigDecimal(String.valueOf(propositionsDetails.get(position).amount)).intValue()));


        }

        @Override
        public int getItemCount() {
            return propositionsDetails.size();
        }

    }

    //adapter for comments
    public class ContentCommentAdapter extends RecyclerView.Adapter<ViewHolder> {
        Datamanager datamanager = Datamanager.getInstance();
        private Comment[] comments = datamanager.getComments();

        public ContentCommentAdapter() {

        }

        // Create new views (invoked by the layout manager)
        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent,
                                             int viewType) {
            // create a new view
            View v = LayoutInflater.from(parent.getContext())
                    .inflate(R.layout.item_list, parent, false);
            // set the view's size, margins, paddings and layout parameters

            ViewHolder vh = new ViewHolder(v);
            return vh;
        }

        // Replace the contents of a view (invoked by the layout manager)
        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            getUsername(comments[position].getUserId(),holder, position);

        }

        public void setTextViewHolder(String username,ViewHolder holder, int position){
            holder.title.setText(String.valueOf(comments[position].getText()));
            holder.desc.setText(String.valueOf(username + " " + comments[position].getDate()));
        }


        //retrofit call to get usernames for comments
        public void getUsername(String id,final ViewHolder holder, final int position){
            DataService loginService = Connector.connection();



            Call<String> call = loginService.getUsernameById(id);

            call.enqueue(new Callback<String>() {
                @Override
                public void onResponse(Call<String> call, Response<String> response) {
                    if (response.isSuccessful()) {

                        setTextViewHolder(response.body(),holder,position);


                    } else {
                        Log.d("User", "Code " + response.code() + " Message: " + response.message()   );


                    }
                }

                @Override
                public void onFailure(Call<String> call, Throwable t) {
                    Log.d("User", "failure " + t.getMessage());

                }
            });
        }

        @Override
        public int getItemCount() {
            return comments.length;
        }

    }

    //Upvote
    public void voteUp(int id){
        DataService service = Connector.connection();

        Call<Void> call = service.voteUp(id,Datamanager.getInstance().getUser().getUserId());

        call.enqueue(new Callback<Void>() {
            @Override
            public void onResponse(Call<Void> call, Response<Void> response) {
                if (response.isSuccessful()) {
                    Log.d("success","success");
                } else {
                    Log.d("Vote", "Code " + response.code() + " Message: " + response.message()   );
                    new AlertDialog.Builder(DetailPropositionActivity.this).setTitle("Fout").setMessage("Stemmen niet gelukt").show();

                }
            }

            @Override
            public void onFailure(Call<Void> call, Throwable t) {
                Log.d("Vote", "failure " + t.getMessage());

            }
        });


    }





}
