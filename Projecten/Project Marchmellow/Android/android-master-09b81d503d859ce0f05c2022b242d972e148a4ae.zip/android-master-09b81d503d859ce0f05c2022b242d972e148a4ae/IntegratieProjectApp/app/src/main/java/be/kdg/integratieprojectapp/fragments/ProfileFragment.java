package be.kdg.integratieprojectapp.fragments;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.User.User;

//fragment to show profile information
public class ProfileFragment extends Fragment {

    private ContentAdapter adapter;
    private RecyclerView recyclerView;
    private static Datamanager datamanager = Datamanager.getInstance();
    private List<String> data = new ArrayList<>();
    private List<String> label = new ArrayList<>();

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        recyclerView = (RecyclerView) inflater.inflate(
                R.layout.recycler_view, container, false);
        adapter = new ContentAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        createData();
        return recyclerView;
    }

    //create the labels and data for adapter
    public void createData(){
        Log.d("data","creating data");
        User user = datamanager.getUser();

        label.add("Gebruikersnaam");
        label.add("Voornaam");
        label.add("Achternaam");
        label.add("Email");
        label.add("Postcode");

        data.add(user.getUserName());
        data.add(user.getName());
        data.add(user.getLastname());
        data.add(user.getEmail());
        data.add(String.valueOf(user.getPostalCode()));
    }

    //viewholder to display the data
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView desc;


        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.list_title);
            desc = (TextView) itemView.findViewById(R.id.list_desc);
        }
    }


    /**
     * Adapter to display recycler view.
     */
    public class ContentAdapter extends RecyclerView.Adapter<ViewHolder> {
        // Set numbers of List in RecyclerView.
        private Datamanager datamanager = Datamanager.getInstance();
        private int length = data.size();

        public ContentAdapter() {
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
            ViewHolder holder = new ViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
                holder.title.setText(label.get(position));
                holder.desc.setText(data.get(position));
        }

        @Override
        public int getItemCount() {
                return data.size();
        }


        public int getLength() {
            return length;
        }

        public void setLength(int length) {
            this.length = length;
        }

        public Datamanager getDatamanager() {
            return datamanager;
        }

        public void setDatamanager(Datamanager datamanager) {
            this.datamanager = datamanager;
        }
    }
}
