

package be.kdg.integratieprojectapp.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.activities.DetailProjectActivity;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Project.Project;
import be.kdg.integratieprojectapp.model.Project.ProjectType;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import be.kdg.integratieprojectapp.model.Proposition.Status;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//fragment that shows projects on the mainactivity
public class ProjectFragment extends Fragment {

    private ContentAdapter adapter;
    private RecyclerView recyclerView;
    private static Datamanager datamanager = Datamanager.getInstance();
    private ProgressDialog progressDialog;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        recyclerView = (RecyclerView) inflater.inflate(
                R.layout.recycler_view, container, false);
        adapter = new ContentAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return recyclerView;
    }

    //viewholder to display the projects
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView desc;


        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.list_title);
            desc = (TextView) itemView.findViewById(R.id.list_desc);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();

                    int itemPosition = recyclerView.getChildLayoutPosition(v);
                    Log.d("projNr",datamanager.getProjects()[itemPosition].getNr() +"");
                    getPropositionsForProject(datamanager.getProjects()[itemPosition].getNr(),context);

                }
            });
        }
    }

    //refresh the recyclerview & adapter
    public void updateProjects(){
        adapter.updateData();
        recyclerView.invalidate();
    }

    @Override
    public void onResume() {
        super.onResume();
       updateProjects();

    }

    //retrofit call to get propositions for a specific
    public void getPropositionsForProject(int projNr, final Context context){
        progressDialog = ProgressDialog.show(context,"Laden","Voorstellen inladen",true);

        final DataService service = datamanager.getConnector().connection();

        final Call<Proposition[]> call = service.getPropositionByProjnr(projNr);
        call.enqueue(new Callback<Proposition[]>() {
            @Override
            public void onResponse(Call<Proposition[]> call, Response<Proposition[]> response) {
                if (response.isSuccessful()) {

                    datamanager.setPropositions(response.body());
                    progressDialog.dismiss();
                    Intent intent = new Intent(context, DetailProjectActivity.class);
                    context.startActivity(intent);
                } else {
                    // error response, no access to resource?
                    Log.e("Error response","Project Error" + response.code());
                }
            }

            @Override
            public void onFailure(Call<Proposition[]> call, Throwable t) {
                // something went completely south (like no internet connection)
                Log.e("Error", "Project Crash: " + t.getMessage());
            }
        });
    }

    /**
     * Adapter to display recycler view.
     */
    public class ContentAdapter extends RecyclerView.Adapter<ViewHolder> {
        // Set numbers of List in RecyclerView.
        private Datamanager datamanager = Datamanager.getInstance();
        private Project[] projects;
        private boolean projectsSet;
        private int length = 0;

        public ContentAdapter() {
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
            ViewHolder holder = new ViewHolder(view);
            projects = (datamanager.getProjects() != null)?datamanager.getProjects(): null;
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {
            if(projectsSet) {

                ProjectType type = ProjectType.values()[projects[position].getType()-1];
                Status status = Status.values()[projects[position].getStatus()-1];

                    holder.title.setText(String.valueOf(type + " met €" + projects[position].getAmount()));
                    holder.desc.setText(String.valueOf(status + " van " + projects[position].getStartDate().split("T")[0] + " tot " + projects[position].getEndDate().split("T")[0]));
            }
        }

        @Override
        public int getItemCount() {
            if(projectsSet)
            return length;
            else
                return 0;
        }

        //update data
        public void updateData(){
            projectsSet = true;
            setProjects(datamanager.getProjects());
            setLength(getProjects().length);
            notifyDataSetChanged();
        }

        public void setLength(int length) {
            this.length = length;
        }

        public Project[] getProjects() {
            return projects;
        }

        public void setProjects(Project[] projects) {
            this.projects = projects;
        }

        public Datamanager getDatamanager() {
            return datamanager;
        }

        public void setDatamanager(Datamanager datamanager) {
            this.datamanager = datamanager;
        }
    }

}
