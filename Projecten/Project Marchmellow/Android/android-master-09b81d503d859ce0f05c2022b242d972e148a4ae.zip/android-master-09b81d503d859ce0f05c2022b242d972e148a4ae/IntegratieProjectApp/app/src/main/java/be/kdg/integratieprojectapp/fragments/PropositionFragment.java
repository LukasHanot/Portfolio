package be.kdg.integratieprojectapp.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.activities.DetailPropositionActivity;
import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.dataService.DataService;
import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Data.Datamanager;
import be.kdg.integratieprojectapp.model.Project.ProjectType;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

//fragment to show User propositions
public class  PropositionFragment extends Fragment {

    private ContentAdapter adapter;
    private RecyclerView recyclerView;
    private static Datamanager datamanager = Datamanager.getInstance();
    private Proposition[] propositions = datamanager.getUserPropositions();
    private ProgressDialog progressDialog ;

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        recyclerView = (RecyclerView) inflater.inflate(
                R.layout.recycler_view, container, false);
        adapter = new ContentAdapter();
        recyclerView.setAdapter(adapter);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        return recyclerView;
    }

    //viewholder to display propositions
    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView title;
        TextView desc;


        public ViewHolder(View itemView) {
            super(itemView);

            title = (TextView) itemView.findViewById(R.id.list_title);
            desc = (TextView) itemView.findViewById(R.id.list_desc);


            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Context context = v.getContext();
                    int itemPosition = recyclerView.getChildLayoutPosition(v);
                    getProposition(context,datamanager.getUserPropositions()[itemPosition].getNr());





                }
            });
        }
    }

    //retrofit call to get a proposition with proposition id
    public void getProposition(final Context context, final int id){
        progressDialog = ProgressDialog.show(context,"Laden","Gegevens inladen",true);
        DataService service = Connector.connection();

        Call<Proposition> call = service.getPropositionById(id);

        call.enqueue(new Callback<Proposition>() {
            @Override
            public void onResponse(Call<Proposition> call, Response<Proposition> response) {
                if (response.isSuccessful()) {

                    datamanager.setDetailProposition(response.body());
                    getComments(context,id);

                } else {
                    Log.d("Proposition", "Code " + response.code() + " Message: " + response.message());
                }
            }

            @Override
            public void onFailure(Call<Proposition> call, Throwable t) {
                Log.d("User", "failure " + t.getMessage());

            }
        });
    }


    //get comments for a specific proposition
    public void getComments(final Context context,int propid){
        DataService service = Connector.connection();

        Call<Comment[]> call = service.getComments(propid);

        call.enqueue(new Callback<Comment[]>() {
            @Override
            public void onResponse(Call<Comment[]> call, Response<Comment[]> response) {
                if (response.isSuccessful()) {

                    datamanager.setComments(response.body());
                    success(context);

                } else {
                    Log.d("Proposition", "Code " + response.code() + " Message: " + response.message()   );


                }
            }

            @Override
            public void onFailure(Call<Comment[]> call, Throwable t) {
                Log.d("User", "failure " + t.getMessage());

            }
        });
    }

    //called after all retrofit calls are succesful
    public void success(Context context){
        progressDialog.dismiss();
        Intent detailIntent = new Intent(context, DetailPropositionActivity.class);
        startActivity(detailIntent);
    }
    /**
     * Adapter to display recycler view.
     */
    public class ContentAdapter extends RecyclerView.Adapter<ViewHolder> {
        // Set numbers of List in RecyclerView.
        private Datamanager datamanager = Datamanager.getInstance();
        private int length = propositions.length;

        public ContentAdapter() {
        }

        @Override
        public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list,parent,false);
            ViewHolder holder = new ViewHolder(view);
            return holder;
        }

        @Override
        public void onBindViewHolder(ViewHolder holder, int position) {

            ProjectType type = ProjectType.values()[propositions[position].getProject().getType()];

                holder.title.setText(String.valueOf("Postcode: " + propositions[position].getProject().getPostalCode()));
                holder.desc.setText(String.valueOf("Project type: " + type + " " + ((propositions[position].getExtraInformation()==null)?"":"Extra informatie: " + propositions[position].getExtraInformation())));

        }

        @Override
        public int getItemCount() {
            return propositions.length;
        }

        public int getLength() {
            return length;
        }

        public void setLength(int length) {
            this.length = length;
        }

        public Datamanager getDatamanager() {
            return datamanager;
        }

        public void setDatamanager(Datamanager datamanager) {
            this.datamanager = datamanager;
        }
    }




}
