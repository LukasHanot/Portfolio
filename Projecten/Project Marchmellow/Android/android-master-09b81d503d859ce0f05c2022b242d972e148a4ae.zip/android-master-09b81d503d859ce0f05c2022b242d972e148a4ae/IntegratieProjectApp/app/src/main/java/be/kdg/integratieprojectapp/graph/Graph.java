package be.kdg.integratieprojectapp.graph;

import android.content.Context;
import android.util.Log;

import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.Legend;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.github.mikephil.charting.utils.ViewPortHandler;

import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

import be.kdg.integratieprojectapp.R;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;

/**
 * Created by jeroe on 9/05/2016.
 */
public class Graph {
    private BudgetLine[] budgetLines;
    private PieChart pieChart;

    private List<Entry> entries ;
    private List<String> labels;
    private PieDataSet dataset;
    private int level1Id;
    private int level2Id;
    private int level3Id;
    private boolean Level1 = true;
    private boolean Level2;
    private boolean Level3;
    private String level;
    private List<Double> expenses ;
    private List<Double> percentages;
    private Context context;


    public Graph(BudgetLine[] budgetLines, PieChart pieChart, Context context) {
        this.budgetLines = budgetLines;
        this.pieChart = pieChart;
        this.context = context;
    }

    //load catagory depending on level
    public void loadData(int clickedId){
        if(isLevel1())
            loadLevel1Category();
        else if(isLevel2())
            loadLevel2Category(clickedId);
        else if(isLevel3())
            loadLevel3Category(clickedId);
    }

    //move up a level in graph
    public void loadLastGraph(int clickedId){
        if(isLevel2()){
            setLevel1(true);
            setLevel2(false);
            setLevel3(false);
            setLevel("Niveau 1");
            drawGraph(getLevel(),clickedId);
        }else if(isLevel3()){
            setLevel3(false);
            setLevel2(true);
            setLevel1(false);
            setLevel("Niveau 2");
            drawGraph(getLevel(),clickedId);
        }
    }

    //update graph after a value selected
    public void updateData(int id){
        pieChart.highlightValues(null);
        if(isLevel1())
            pieChart.setCenterText("Niveau 1");
        else if(isLevel2())
            pieChart.setCenterText("Niveau 2");
        else
            pieChart.setCenterText("Niveau 3");


        loadData(id);
        createDataValues();
        createPieData();
        setPieData();
        setDesign();
        pieChart.invalidate();

    }

    //draw the graph
    public void drawGraph(String level,int clickedId){
        expenses = new ArrayList<>(10);
        pieChart.setDragDecelerationEnabled(false);
        pieChart.setCenterText(level);
        pieChart.setDrawCenterText(true);
        pieChart.setRotationEnabled(false);
        pieChart.setDescription("");
        pieChart.setHardwareAccelerationEnabled(true);


        loadData(clickedId);

        createDataValues();

        createPieData();
        setPieData();
        setDesign();
        setValueSelectedListener();

    }

    //create values in the entries list
    public void createDataValues(){

        entries = new ArrayList<>();

        int teller = 0;
        for (Double d : expenses) {
            teller++;
            double val = d;
            float number = (float)val;
            Entry tmp = new Entry(number,teller);
            entries.add(tmp);
        }
    }

    //create dataset with entries
    public void createPieData(){
        dataset = new PieDataSet(entries,"");
        dataset.setValueTextSize(9);
        dataset.setValueFormatter(new MyValueFormatter());


    }


    //create piedata with labels and dataset
    public void setPieData(){
        //Set data
        // initialize Piedata
        PieData data = new PieData(labels, dataset);
        //set data into chart
        pieChart.setData(data);

    }

    //set design of the chart
    public void setDesign(){
        // set the color
        dataset.setColors(new int[]{ R.color.chart_one,R.color.chart_two, R.color.chart_three,R.color.chart_four, R.color.chart_five,R.color.chart_six, R.color.chart_seven,R.color.chart_eight, R.color.chart_nine,R.color.chart_ten},context);
        Legend legend = pieChart.getLegend();
        legend.setWordWrapEnabled(true);
        legend.setEnabled(true);
        legend.setForm(Legend.LegendForm.CIRCLE);
        legend.setPosition(Legend.LegendPosition.BELOW_CHART_CENTER);
        pieChart.setDrawSliceText(false);

        //Animate
        pieChart.animateY(1000);
    }

    //set onvalue selected listener
    public void setValueSelectedListener(){
        //Wanneer er een waarde wordt geselecteerd
        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry entry, int i, Highlight highlight) {
                if(isLevel1()){
                    Log.d("id",entry.getXIndex() +"");
                    setLevel1(false);
                    setLevel2(true);
                    setLevel3(false);
                    //TODO check index start 0
                    Log.d("index",entry.getXIndex() +"");
                    setLevel1Id(entry.getXIndex());

                    updateData(entry.getXIndex());
                    //loadGraph(entry.getXIndex());

                }else if(isLevel2()){
                    Log.d("id",entry.getXIndex() +"");

                    setLevel1(false);
                    setLevel2(false);
                    setLevel3(true);
                    setLevel2Id(entry.getXIndex());
                    updateData(entry.getXIndex());
                    //loadGraph(entry.getXIndex());
                }

            }

            @Override
            public void onNothingSelected() {

            }
        });
    }

    //load level 1
    public void loadLevel1Category(){
        //STATIC voor andere activity?

        clearList();

        labels = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            labels.add("");
        }

        for (BudgetLine b : budgetLines) {
            int idA =Integer.parseInt(b.getCategoryA().getCategoryID())%10;

            if(!labels.contains(b.getCategoryA().getName())) {
                labels.set(idA, b.getCategoryA().getName());
            }
            expenses.set(idA,expenses.get(idA) + b.getExpense());
        }

        removeZero();

    }

    public void removeZero(){
        for (int i = 0; i < expenses.size(); i++) {
            if(expenses.get(i) == 0){

                expenses.remove((i==0)?i:i--);
                labels.remove((i==0)?i:i--);
            }
        }
    }


    //load level 2
    public void loadLevel2Category(int clickedId){
        //STATIC voor andere activity?

        clearList();


        labels = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            labels.add("");
        }
        for (BudgetLine b : budgetLines) {
            int idA =Integer.parseInt(b.getCategoryA().getCategoryID());


            if (idA == clickedId) {
                int idB =Integer.parseInt(b.getCategoryB().getCategoryID())%10;
                if(!labels.contains(b.getCategoryB().getName())) {
                    labels.set(idB, b.getCategoryB().getName());
                }
                expenses.set(idB,expenses.get(idB) + b.getExpense());
            }
        }

        removeZero();
    }

    //load level 3
    public void loadLevel3Category(int clickedId){
        //STATIC voor andere activity?

        clearList();

        labels = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            labels.add("");
        }

        for (BudgetLine b : budgetLines) {
            int idB =Integer.parseInt(b.getCategoryB().getCategoryID());

            if (idB == clickedId + (level1Id*10)) {
                int idC =Integer.parseInt(b.getCategoryC().getCategoryID())%10;
                Log.d("cid",idC +"");
                Log.d("catC",b.getCategoryC().getName() +"");
                if(!labels.contains(b.getCategoryC().getName())){
                    Log.d("category", b.getCategoryB().getName());
                    labels.set(idC,b.getCategoryC().getName());
                }
                expenses.set(idC,expenses.get(idC) + b.getExpense());
            }
        }
        removeZero();
    }

    //clear lists
    public void clearList(){
        expenses.clear();
        for (int i = 0; i < 10; i++) {
            expenses.add(0.0);
        }
    }

    //load graph
    public void loadGraph(int clickedId){
        //STATIC voor andere activity?
        drawGraph("Niveau 1",clickedId);

    }




    //draw the tax graph
    public void drawTaxGraph(double bruto, double percentage,double tax){
        expenses = new ArrayList<>(10);
        pieChart.setDragDecelerationEnabled(false);
        pieChart.setCenterText("Gemeente tax van: " + percentage*100 + "% op €" + bruto +" is €" + Math.round(tax*100)/100 );
        pieChart.setDrawCenterText(true);
        pieChart.setRotationEnabled(false);
        pieChart.setDescription("");
        pieChart.setHardwareAccelerationEnabled(true);

        pieChart.setHighlightPerTapEnabled(false);




        //speciaal voor taxen
        loadTaxValues(tax);

        createDataValues();

        createPieData();
        setPieData();
        setDesign();

        //Spaciaal voor tax
        setTaxValueSelectedListener(percentage,bruto,tax);
    }


    //load tax values
    public void loadTaxValues(double tax){
        clearList();

        labels = new ArrayList<>();
        for (int i = 0; i < 10; i++) {
            labels.add("");
        }

        for (BudgetLine b : budgetLines) {
            int idA =Integer.parseInt(b.getCategoryA().getCategoryID())%10;
            if(!labels.contains(b.getCategoryA().getName()))
                labels.set(idA,b.getCategoryA().getName());
            expenses.set(idA,expenses.get(idA) + b.getExpense());
        }


        double total = 0;
        //totaal berekenen
        for (Double d : expenses) {
            total += d;
        }

        percentages = new ArrayList<>(10);
        //percentages per expense berekenen
        for (int i = 0; i < expenses.size(); i++) {
            percentages.add(expenses.get(i)/total);
        }

        //expenses vervangen met percentages van tax
        for (int i = 0; i < expenses.size(); i++) {
            expenses.set(i,(tax*percentages.get(i)));
        }

    }

    //set value selected listener for tax
    public void setTaxValueSelectedListener(final double percentage, final double bruto, final double tax){
        //Wanneer er een waarde wordt geselecteerd
        pieChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry entry, int i, Highlight highlight) {

                pieChart.setCenterText("Categorie " +entry.getXIndex() + ": "+ expenses.get(entry.getXIndex()));
            }

            @Override
            public void onNothingSelected() {
                pieChart.setCenterText("Gemeente tax van: " + percentage*100 + "% op €" + bruto +" is €" + Math.round(tax*100)/100 );
            }
        });
    }

    //value formatter to add €, comma's and 2 decimals
    public class MyValueFormatter implements ValueFormatter {

        private DecimalFormat mFormat;

        public MyValueFormatter() {
            mFormat = new DecimalFormat("###,###,###.00"); // use one decimal
        }

        @Override
        public String getFormattedValue(float value, Entry entry, int dataSetIndex, ViewPortHandler viewPortHandler) {
            // write your logic here
            return "€" + mFormat.format(value) ; // e.g. append a dollar-sign
        }
    }


    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public boolean isLevel1() {
        return Level1;
    }

    public void setLevel1(boolean level1) {
        Level1 = level1;
    }

    public boolean isLevel2() {
        return Level2;
    }

    public void setLevel2(boolean level2) {
        Level2 = level2;
    }

    public boolean isLevel3() {
        return Level3;
    }

    public void setLevel3(boolean level3) {
        Level3 = level3;
    }

    public int getLevel1Id() {
        return level1Id;
    }

    public void setLevel1Id(int level1Id) {
        this.level1Id = level1Id;
    }

    public int getLevel2Id() {
        return level2Id;
    }

    public void setLevel2Id(int level2Id) {
        this.level2Id = level2Id;
    }

    public int getLevel3Id() {
        return level3Id;
    }

    public void setLevel3Id(int level3Id) {
        this.level3Id = level3Id;
    }
}
