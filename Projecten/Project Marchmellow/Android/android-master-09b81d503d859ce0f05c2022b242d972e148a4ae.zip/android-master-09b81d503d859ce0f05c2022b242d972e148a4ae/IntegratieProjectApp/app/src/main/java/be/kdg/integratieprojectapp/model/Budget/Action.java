package be.kdg.integratieprojectapp.model.Budget;

/**
 * Created by jeroe on 21/04/2016.
 */
public class Action {
    private int nr;
    private String code;
    private String shortDescription;
    private String longDescription;

    public Action(int nr, String code, String shortDescription, String longDescription) {
        this.nr = nr;
        this.code = code;
        this.shortDescription = shortDescription;
        this.longDescription = longDescription;
    }

    public int getNr() {
        return nr;
    }

    public String getCode() {
        return code;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public String getLongDescription() {
        return longDescription;
    }
}
