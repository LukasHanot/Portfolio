package be.kdg.integratieprojectapp.model.Budget;

/**
 * Created by jeroe on 21/04/2016.
 */
public class BudgetLine  {
    private String group;
    private int management;
    private Action action;
    private CategoryA categoryA;
    private CategoryB categoryB;
    private CategoryC categoryC;
    private int bookingYear;
    private double expense;
    private int number;

    public BudgetLine(String group, int management, Action action, CategoryA categoryA, CategoryB categoryB, CategoryC categoryC, int bookingYear, int expense, int number) {
        this.group = group;
        this.management = management;
        this.action = action;
        this.categoryA = categoryA;
        this.categoryB = categoryB;
        this.categoryC = categoryC;
        this.bookingYear = bookingYear;
        this.expense = expense;
        this.number = number;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public int getManagement() {
        return management;
    }

    public void setManagement(int management) {
        this.management = management;
    }

    public Action getAction() {
        return action;
    }

    public void setAction(Action action) {
        this.action = action;
    }

    public CategoryA getCategoryA() {
        return categoryA;
    }

    public void setCategoryA(CategoryA categoryA) {
        this.categoryA = categoryA;
    }

    public CategoryB getCategoryB() {
        return categoryB;
    }

    public void setCategoryB(CategoryB categoryB) {
        this.categoryB = categoryB;
    }

    public CategoryC getCategoryC() {
        return categoryC;
    }

    public void setCategoryC(CategoryC categoryC) {
        this.categoryC = categoryC;
    }

    public int getBookingYear() {
        return bookingYear;
    }

    public void setBookingYear(int bookingYear) {
        this.bookingYear = bookingYear;
    }

    public double getExpense() {
        return expense;
    }

    public void setExpense(double expense) {
        this.expense = expense;
    }

    public int getNumber() {
        return number;
    }

    public void setNumber(int number) {
        this.number = number;
    }
}
