package be.kdg.integratieprojectapp.model.Budget;

import java.util.List;

/**
 * Created by jeroe on 22/04/2016.
 */
public class CategoryA {
    private int nr;
    private String name;
    private String categoryID;

    private List<CategoryB> CategoriesB;

    public CategoryA(int nr, String name, String categoryID, List<CategoryB> categoriesB) {
        this.nr = nr;
        this.name = name;
        this.categoryID = categoryID;
        CategoriesB = categoriesB;
    }

    public int getNr() {
        return nr;
    }

    public String getName() {
        return name;
    }

    public String getCategoryID() {
        return categoryID;
    }

    public List<CategoryB> getCategoriesB() {
        return CategoriesB;
    }
}
