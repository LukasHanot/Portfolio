package be.kdg.integratieprojectapp.model.Budget;

import java.util.List;

/**
 * Created by jeroe on 22/04/2016.
 */
public class CategoryB {
    private int nr;
    private String name;
    private String categoryID;

    private List<CategoryC> CategoriesC;

    public CategoryB(int nr, String name, String categoryID, List<CategoryC> categoriesC) {
        this.nr = nr;
        this.name = name;
        this.categoryID = categoryID;
        CategoriesC = categoriesC;
    }

    public int getNr() {
        return nr;
    }

    public String getName() {
        return name;
    }

    public String getCategoryID() {
        return categoryID;
    }

    public List<CategoryC> getCategoriesC() {
        return CategoriesC;
    }
}
