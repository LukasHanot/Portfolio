package be.kdg.integratieprojectapp.model.Budget;

/**
 * Created by jeroe on 22/04/2016.
 */
public class CategoryC {

    private int nr;
    private String name;
    private String categoryID;

    public CategoryC(int nr, String name, String categoryID) {
        this.nr = nr;
        this.name = name;
        this.categoryID = categoryID;
    }

    public int getNr() {
        return nr;
    }

    public String getName() {
        return name;
    }

    public String getCategoryID() {
        return categoryID;
    }
}
