package be.kdg.integratieprojectapp.model.Comments;

import be.kdg.integratieprojectapp.model.Proposition.Proposition;

/**
 * Created by jeroe on 21/05/2016.
 */
public class Comment {
    public int nr ;
    public String date ;
    public String text ;
    public String userId ;
    public String userEmail ;
    public CommentStatus commentState ;
    public Proposition proposition ;

    public Comment(int nr, String date, String text, String userId, String userEmail, CommentStatus commentState, Proposition proposition) {
        this.nr = nr;
        this.date = date;
        this.text = text;
        this.userId = userId;
        this.userEmail = userEmail;
        this.commentState = commentState;
        this.proposition = proposition;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserEmail() {
        return userEmail;
    }

    public void setUserEmail(String userEmail) {
        this.userEmail = userEmail;
    }

    public CommentStatus getCommentState() {
        return commentState;
    }

    public void setCommentState(CommentStatus commentState) {
        this.commentState = commentState;
    }

    public Proposition getProposition() {
        return proposition;
    }

    public void setProposition(Proposition proposition) {
        this.proposition = proposition;
    }
}
