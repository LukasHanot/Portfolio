package be.kdg.integratieprojectapp.model.Comments;

/**
 * Created by jeroe on 21/05/2016.
 */
public enum CommentStatus
{
    APPROVED , DENIED, STATELESS
}
