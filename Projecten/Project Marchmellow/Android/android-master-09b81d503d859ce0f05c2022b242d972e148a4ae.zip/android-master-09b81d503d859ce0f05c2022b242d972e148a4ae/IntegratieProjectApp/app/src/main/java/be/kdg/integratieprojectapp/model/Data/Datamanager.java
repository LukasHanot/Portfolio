package be.kdg.integratieprojectapp.model.Data;

import android.util.Log;

import be.kdg.integratieprojectapp.dataService.Connector;
import be.kdg.integratieprojectapp.model.Budget.BudgetLine;
import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Location.PostalHead;
import be.kdg.integratieprojectapp.model.Project.Project;
import be.kdg.integratieprojectapp.model.Proposition.Proposition;
import be.kdg.integratieprojectapp.model.User.Token;
import be.kdg.integratieprojectapp.model.User.User;

/**
 * Created by jeroe on 7/05/2016.
 */
public class Datamanager {
    private BudgetLine[] primaryBudgetLines;
    private BudgetLine[] secondaryBudgetLines;
    private PostalHead primaryPostalHead;
    private PostalHead secondaryPostalHead;
    private PostalHead thirdPostalHead;
    private Connector connector;
    private Token token ;
    private User user;
    private int year = 2016;
    private Project[] projects;
    private Proposition[] propositions;
    private Proposition[] userPropositions;
    private Proposition detailProposition;
    private Project detailProject;
    private Comment[] comments;
    private int selectedProposition;
    public boolean voted;


    private static Datamanager instance = null;

    protected Datamanager(int postalcode) {
        // Exists only to defeat instantiation.
        Log.d("postalcodeDATA", postalcode +"");
        connector = createConnector(postalcode);
        token = Token.getInstance();

    }

    public Connector createConnector(int postalcode){
        return new Connector(postalcode,year,this);
    }

    public static Datamanager getInstance(int postalcode) {
        if(instance == null) {
            instance = new Datamanager(postalcode);
        }
        return instance;
    }

    public static Datamanager getInstance() {

        return instance;
    }





    public BudgetLine[] getPrimaryBudgetLines() {

        return primaryBudgetLines;
    }

    public void setPrimaryBudgetLines(BudgetLine[] primaryBudgetLines) {
        this.primaryBudgetLines = primaryBudgetLines;
    }

    public PostalHead getPostalHead() {
        return primaryPostalHead;
    }

    public void setPostalHead(PostalHead postalHead) {
        this.primaryPostalHead = postalHead;
    }

    public Connector getConnector() {
        return connector;
    }

    public BudgetLine[] getSecondaryBudgetLines() {
        return secondaryBudgetLines;
    }

    public void setSecondaryBudgetLines(BudgetLine[] secondaryBudgetLines) {
        this.secondaryBudgetLines = secondaryBudgetLines;
    }

    public PostalHead getSecondaryPostalHead() {
        return secondaryPostalHead;
    }

    public void setSecondaryPostalHead(PostalHead secondaryPostalHead) {
        this.secondaryPostalHead = secondaryPostalHead;
    }

    public Token getToken() {
        if(token != null)
        return token;
        else
            return null;
    }

    public void setToken(Token token) {
        this.token = token;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }

    public Project[] getProjects() {
        return projects;
    }

    public void setProjects(Project[] projects) {
        this.projects = projects;
    }

    public Proposition[] getPropositions() {
        return propositions;
    }

    public void setPropositions(Proposition[] propositions) {
        this.propositions = propositions;
    }

    public Proposition[] getUserPropositions() {
        return userPropositions;
    }

    public void setUserPropositions(Proposition[] userPropositions) {
        this.userPropositions = userPropositions;
    }

    public Proposition getDetailProposition() {
        return detailProposition;
    }

    public void setDetailProposition(Proposition detailProposition) {
        this.detailProposition = detailProposition;
    }

    public Project getDetailProject() {
        return detailProject;
    }

    public void setDetailProject(Project detailProject) {
        this.detailProject = detailProject;
    }

    public Comment[] getComments() {
        return comments;
    }

    public void setComments(Comment[] comments) {
        this.comments = comments;
    }

    public int getSelectedProposition() {
        return selectedProposition;
    }

    public void setSelectedProposition(int selectedProposition) {
        this.selectedProposition = selectedProposition;
    }


}
