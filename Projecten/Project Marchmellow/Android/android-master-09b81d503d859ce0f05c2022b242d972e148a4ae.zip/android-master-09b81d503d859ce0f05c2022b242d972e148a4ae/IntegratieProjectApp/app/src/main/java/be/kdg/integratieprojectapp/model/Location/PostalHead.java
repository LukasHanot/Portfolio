package be.kdg.integratieprojectapp.model.Location;

/**
 * Created by jeroe on 26/04/2016.
 */
public class PostalHead {
    private int nr ;
    private int postalCode ;
    private String name ;
    private String province ;

    public PostalHead(int nr, int postalCode, String name, String province) {
        this.nr = nr;
        this.postalCode = postalCode;
        this.name = name;
        this.province = province;
    }

    public int getNr() {
        return nr;
    }

    public int getPostalCode() {
        return postalCode;
    }

    public String getName() {
        return name;
    }

    public String getProvince() {
        return province;
    }
}
