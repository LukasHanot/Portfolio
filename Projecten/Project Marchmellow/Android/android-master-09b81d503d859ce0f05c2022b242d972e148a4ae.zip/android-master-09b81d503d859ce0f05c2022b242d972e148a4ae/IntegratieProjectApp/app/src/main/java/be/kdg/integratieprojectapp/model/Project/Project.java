package be.kdg.integratieprojectapp.model.Project;

import be.kdg.integratieprojectapp.model.Proposition.Proposition;

/**
 * Created by jeroe on 20/05/2016.
 */
public class Project {
    private int nr;
    private String startDate;
    private String endDate;
    private String text;
    private int type;
    private int status;
    private int postalCode;
    private int year;
    private int amount;
    private ProjectDetail[] projectDetails;
    private Proposition[] propositions;

    public Project(int nr, String startDate, String endDate, String text, int type, int status, int postalCode, int year, int amount) {
        this.nr = nr;
        this.startDate = startDate;
        this.endDate = endDate;
        this.text = text;
        this.type = type;
        this.status = status;
        this.postalCode = postalCode;
        this.year = year;
        this.amount = amount;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public String getStartDate() {
        return startDate;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public int getPostalCode() {
        return postalCode;
    }

    public void setPostalCode(int postalCode) {
        this.postalCode = postalCode;
    }

    public int getYear() {
        return year;
    }

    public void setYear(int year) {
        this.year = year;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }
}
