package be.kdg.integratieprojectapp.model.Project;

import be.kdg.integratieprojectapp.model.Budget.CategoryA;
import be.kdg.integratieprojectapp.model.Budget.CategoryB;
import be.kdg.integratieprojectapp.model.Budget.CategoryC;

/**
 * Created by jeroe on 21/05/2016.
 */
public class ProjectDetail {
    public int nr;
    public boolean canModify ;
    public double minAmount ;
    public double maxAmount ;
    public CategoryA categoryA ;
    public CategoryB categoryB ;
    public CategoryC categoryC ;

    public ProjectDetail(int nr, boolean canModify, double minAmount, double maxAmount, CategoryA categoryA, CategoryB categoryB, CategoryC categoryC) {
        this.nr = nr;
        this.canModify = canModify;
        this.minAmount = minAmount;
        this.maxAmount = maxAmount;
        this.categoryA = categoryA;
        this.categoryB = categoryB;
        this.categoryC = categoryC;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public boolean isCanModify() {
        return canModify;
    }

    public void setCanModify(boolean canModify) {
        this.canModify = canModify;
    }

    public double getMinAmount() {
        return minAmount;
    }

    public void setMinAmount(double minAmount) {
        this.minAmount = minAmount;
    }

    public double getMaxAmount() {
        return maxAmount;
    }

    public void setMaxAmount(double maxAmount) {
        this.maxAmount = maxAmount;
    }

    public CategoryA getCategoryA() {
        return categoryA;
    }

    public void setCategoryA(CategoryA categoryA) {
        this.categoryA = categoryA;
    }

    public CategoryB getCategoryB() {
        return categoryB;
    }

    public void setCategoryB(CategoryB categoryB) {
        this.categoryB = categoryB;
    }

    public CategoryC getCategoryC() {
        return categoryC;
    }

    public void setCategoryC(CategoryC categoryC) {
        this.categoryC = categoryC;
    }
}
