package be.kdg.integratieprojectapp.model.Project;

/**
 * Created by jeroe on 20/05/2016.
 */
public enum ProjectType {
    Herschikking, Besparing, Bestemming
}
