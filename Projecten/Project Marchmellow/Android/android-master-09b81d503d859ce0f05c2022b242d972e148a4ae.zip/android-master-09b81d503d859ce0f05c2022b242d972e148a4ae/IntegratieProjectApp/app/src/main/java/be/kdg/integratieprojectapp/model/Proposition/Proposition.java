package be.kdg.integratieprojectapp.model.Proposition;

import java.util.List;

import be.kdg.integratieprojectapp.model.Comments.Comment;
import be.kdg.integratieprojectapp.model.Project.Project;

/**
 * Created by jeroe on 20/05/2016.
 */
public class Proposition {
    public String date ;
    //public Uri VideoURL { get; set; }
    public List<Comment> comments;
    //public PropositionDetail propositionDetail { get; set; }
    public int nr ;
    public String userId ;
    public Project project ;
    public String extraInformation ;
    public List<PropositionDetail> details ;
    public List<Vote> votes ;

    public Proposition(String date, List<Comment> comments, int nr, String userId, Project project, String extraInformation, List<PropositionDetail> details, List<Vote> votes) {
        this.date = date;
        this.comments = comments;
        this.nr = nr;
        this.userId = userId;
        this.project = project;
        this.extraInformation = extraInformation;
        this.details = details;
        this.votes = votes;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public List<Comment> getComments() {
        return comments;
    }

    public void setComments(List<Comment> comments) {
        this.comments = comments;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public String getExtraInformation() {
        return extraInformation;
    }

    public void setExtraInformation(String extraInformation) {
        this.extraInformation = extraInformation;
    }

    public List<PropositionDetail> getDetails() {
        return details;
    }

    public void setDetails(List<PropositionDetail> details) {
        this.details = details;
    }

    public List<Vote> getVotes() {
        return votes;
    }

    public void setVotes(List<Vote> votes) {
        this.votes = votes;
    }
}
