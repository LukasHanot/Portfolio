package be.kdg.integratieprojectapp.model.Proposition;

import be.kdg.integratieprojectapp.model.Budget.CategoryA;
import be.kdg.integratieprojectapp.model.Budget.CategoryB;
import be.kdg.integratieprojectapp.model.Budget.CategoryC;

/**
 * Created by jeroe on 21/05/2016.
 */
public class PropositionDetail {
    public int nr ;
    public double amount ;
    public CategoryA categoryA ;
    public CategoryB categoryB ;
    public CategoryC categoryC ;

}
