package be.kdg.integratieprojectapp.model.Proposition;

/**
 * Created by jeroe on 20/05/2016.
 */
public enum Status {
    Open,Closed
}
