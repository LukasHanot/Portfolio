package be.kdg.integratieprojectapp.model.Proposition;

/**
 * Created by jeroe on 21/05/2016.
 */
public class Vote {
    public int nr ;
    public String userId ;
    public Proposition proposition ;

    public Vote(int nr, String userId, Proposition proposition) {
        this.nr = nr;
        this.userId = userId;
        this.proposition = proposition;
    }

    public int getNr() {
        return nr;
    }

    public void setNr(int nr) {
        this.nr = nr;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public Proposition getProposition() {
        return proposition;
    }

    public void setProposition(Proposition proposition) {
        this.proposition = proposition;
    }
}
