package be.kdg.integratieprojectapp.model.User;

import android.util.Log;

/**
 * Created by jeroen on 17/05/2016.
 */
public class Token {

    private String access_token;
    private int expires_in;
    private String token_type;
    private static Token instance = null;
    private String userID;
    private boolean set = false;

    private Token() {

    }

    public static Token getInstance() {
        if(instance == null){
            Log.d("token", "creating");
            instance = new Token();
        }
        return instance;
    }


    public String getAccess_token() {
        return access_token;
    }

    public void setAccess_token(String access_token) {
        this.access_token = access_token;
    }

    public int getExpires_in() {
        return expires_in;
    }

    public void setExpires_in(int expires_in) {
        this.expires_in = expires_in;
    }

    public String getToken_type() {
        return token_type;
    }

    public void setToken_type(String token_type) {
        this.token_type = token_type;
    }

    public boolean isSet() {
        return set;
    }

    public void setSet(boolean set) {
        this.set = set;
    }

    public static void setInstance(Token instance) {
        Token.instance = instance;
    }

    public String getUserID() {
        return userID;
    }

    public void setUserID(String userID) {
        this.userID = userID;
    }
}
