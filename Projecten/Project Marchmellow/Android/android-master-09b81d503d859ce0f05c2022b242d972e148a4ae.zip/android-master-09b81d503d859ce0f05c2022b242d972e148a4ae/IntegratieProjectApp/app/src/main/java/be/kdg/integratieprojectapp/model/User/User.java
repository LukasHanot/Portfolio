package be.kdg.integratieprojectapp.model.User;

import com.google.gson.annotations.SerializedName;

/**
 * Created by jeroe on 20/04/2016.
 */
public class User {
    public String UserId;
    @SerializedName("UserName")
    public String UserName;
    @SerializedName("name")
    public String name;
    @SerializedName("lastname")
    public String lastname;
    @SerializedName("postalcode")
    public int postalcode;
    @SerializedName("Email")
    public String Email;
    @SerializedName("Password")
    public String Password;
    @SerializedName("ConfirmPassword")
    public String ConfirmPassword;

    public User(String UserName, String name, String lastname, int postalcode, String Email, String Password, String ConfirmPassword) {
        this.UserName = UserName;
        this.name = name;
        this.lastname = lastname;
        this.postalcode = postalcode;
        this.Email = Email;
        this.Password = Password;
        this.ConfirmPassword = ConfirmPassword;
    }

    public User(){

    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String Email) {
        this.Email = Email;
    }

    public String getPassword() {
        return Password;
    }

    public String getUserName() {
        return UserName;
    }

    public void setUserName(String userName) {
        this.UserName = userName;
    }

    public String getname() {
        return name;
    }

    public void setname(String name) {
        this.name = name;
    }

    public String getLastname() {
        return lastname;
    }

    public void setLastname(String lastname) {
        this.lastname = lastname;
    }

    public int getPostalCode() {
        return postalcode;
    }

    public void setPostalCode(int postalCode) {
        this.postalcode = postalCode;
    }

    public void setPassword(String Password) {
        this.Password = Password;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getConfirmPassword() {
        return ConfirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        ConfirmPassword = confirmPassword;
    }

    public String getUserId() {
        return UserId;
    }

    public void setUserId(String userId) {
        UserId = userId;
    }

    public int getPostalcode() {
        return postalcode;
    }

    public void setPostalcode(int postalcode) {
        this.postalcode = postalcode;
    }
}