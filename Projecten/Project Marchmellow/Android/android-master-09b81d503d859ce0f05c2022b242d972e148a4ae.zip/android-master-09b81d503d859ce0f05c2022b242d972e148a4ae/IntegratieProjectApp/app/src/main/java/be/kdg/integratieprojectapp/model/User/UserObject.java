package be.kdg.integratieprojectapp.model.User;

/**
 * Created by jeroe on 22/04/2016.
 */
public class UserObject {
    public User user;

    public UserObject(User user) {
        this.user = user;
    }
}
