﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.EF;
using Domain.Budget;

namespace BL
{
  public class BegrotingsManager
  {
    private BegrotingsRepository repo;

    public BegrotingsManager(UnitOfWorkManager uofMgr)
    {
      repo = new DAL.EF.BegrotingsRepository(uofMgr.UnitOfWork); 
    }
    //import voor budget
    public BegrotingsManager()
    {
      repo = new DAL.EF.BegrotingsRepository();
    }

    public void addBudget(DataSet result)
    {
      repo.createBudget(result);
    }

    public object getBudget()
    {
      return repo.ReadBudget();
    }
    public IEnumerable<BudgetLine> getBudgetLines()
    {
      return repo.ReadBudgets();
    }

    public object getBudgetYear(int year)
    {
      return repo.ReadBudgetYear(year);
    }

    public void addPostcodes(DataSet result)
    {
      repo.createPostcodes(result);
    }

    public object getBudgetPostal(int postal)
    {
     return repo.ReadBudgetPostal(postal);
    }

    public object getBudgetYearPostal(int year, int postal)
    {
      return repo.ReadBudgetYearPostal(year,postal);
    }

    public List<CategoryA> getCategories()
    {
      return repo.ReadCategories();
    }

    public List<CategoryA> getCategoryA()
    {
      return repo.ReadCategoryA();
    }
    public List<CategoryB> getCategoryB()
    {
      return repo.ReadCategoryB();
    }
     public List<CategoryC> getCategoryC()
    {
      return repo.ReadCategoryC();
    }

    public void addTaxes(DataSet result)
    {
      repo.createTaxes(result);
    }

    public int getPostalheadCode(int postalcode)
    {
     return repo.readPostalHeadOfPostalCode(postalcode).postalCode;
    }

    public Domain.Location.PostalHead getPostalhead(int postalcode)
    {
      return repo.readPostalHeadOfPostalCode(postalcode);
    }

    public object getSalaryOverview(double salary, int postal)
    {
      return null;
    }
  }
}
