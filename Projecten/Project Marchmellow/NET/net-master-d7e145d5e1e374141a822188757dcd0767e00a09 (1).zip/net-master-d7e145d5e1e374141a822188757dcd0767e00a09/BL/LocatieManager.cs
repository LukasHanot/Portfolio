﻿using DAL.EF;
using Domain.Budget;
using Domain.Location;
using Domain.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BL
{
  public class LocatieManager
  {
    private readonly LocatieRepository repo;

    public LocatieManager(UnitOfWorkManager uofMgr)
    {
      repo = new DAL.EF.LocatieRepository(uofMgr.UnitOfWork);
    }
    /*public IEnumerable<PostalHead> getPostalHeadsWithProjects(IEnumerable<Project> allProjects)
    {
      return repo.ReadPostalHeadsWithProjects(allProjects);
    }*/

    public IEnumerable<PostalCode> getPostalCodes()
    {
      return repo.ReadPostalCodes();
    }

    public PostalHead getPostalHeadByUserPostalCode(int postalCode)
    {
      return repo.ReadPostalHeadByUserPostalCode(postalCode);
    }
    public PostalHead getPostalHeadByUserPostalCode(int? postalCode)
    {
      return repo.ReadPostalHeadByUserPostalCode(postalCode);
    }


    public PostalCode getPostalCode(int id)
    {
      return repo.ReadPostalCode(id);
    }

    public PostalCode addPostalCode(int nr, int postalCode, string name, Cluster? cluster, PostalHead postalhead)
    {
      PostalCode postalcode = new PostalCode()
      {
        nr = nr,
        postalCode = postalCode,
        name = name,
        cluster = cluster,
        postalHead = postalhead
      };
      return repo.CreatePostalCode(postalcode);
    }
    public void changePostalCode(PostalCode postalcode)
    {
      repo.UpdatePostalCode(postalcode);
    }
    public void changePlace(Place place)
    {
      repo.UpdatePlace(place);
    }
    public IEnumerable<PostalHead> getPostalHeadsWithBudget(IEnumerable<BudgetLine> budgetlines)
    {
      return repo.ReadPostalHeadsWithBudget(budgetlines);
    }

    /*public IEnumerable<PostalCode> getPostalCodesByUserPostalHead(int userPostalCode)
    {
      return repo.ReadPostalCodesByUserPostalHead(userPostalCode);
    }*/

    public Place getPlaceByPostalCode(int postalCode)
    {
      return repo.ReadPlaceByPostalCode(postalCode);
    }
    /*public int getPostalCodeUser(string email)
    {
      return repo.ReadPostalCode(email);
    }*/

    /* public string getLocation(int postcalCode)
     {
       return repo.ReadLocation(postcalCode);
     }*/

    public double? getCommunTax(int postalCode)
    {
      return repo.ReadPostalCodeByPostalcode(postalCode).taxe;
    }


    public IEnumerable<PostalCode> getPostalCodesFromKnownHeadPostal(int postalcode)
    {

      return repo.ReadPostalCodesByUserPostalHead(postalcode);
    }
  }
}
