﻿using System;
using System.Collections.Generic;
using DAL.EF;
using Domain.Project;
using System.Linq;

namespace BL
{
  public class ProjectManager
  {
    private readonly ProjectRepository repo;

    public ProjectManager(UnitOfWorkManager uofMgr)
    {
      repo = new DAL.EF.ProjectRepository(uofMgr.UnitOfWork);
    }

    public Project getProject(int? projectId)
    {
      return repo.ReadProject(projectId);
    }

    public IEnumerable<Project> getProjects()
    {
      return repo.ReadProjects();
    }

    public void changeProject(Project project)
    {
      repo.UpdateProject(project);
    }

    public void removeProject(int projectId)
    {
      repo.DeleteProject(projectId);
    }

    public Project addProject(double amount, List<bool> canModify, DateTime endDate, List<double> maxAmount, List<double> minAmount, int postalcode, DateTime startDate, Status status, string text, TypeProject type, int year, List<Domain.Budget.CategoryA> categoryAs)
    {
      //maak project en projectDetails
      Project project = new Project();
      project.amount = amount;
      project.endDate = endDate;
      project.postalCode = postalcode;
      project.startDate = startDate;
      project.status = status;
      project.text = text;
      project.type = type;
      project.year = year;

      //lees de list en projectdetails
      int veld = 0;
      foreach (Domain.Budget.CategoryA catA in categoryAs)
      {
        ProjectDetail pdA = new ProjectDetail();
        pdA.canModify = canModify.ElementAt(veld);
        pdA.categoryA = catA;
        pdA.maxAmount = maxAmount.ElementAt(veld);
        pdA.minAmount = minAmount.ElementAt(veld);
        veld = veld+1;
        project.projectDetails.Add(pdA);
        foreach (Domain.Budget.CategoryB catB in catA.CategoriesB)
        {
          ProjectDetail pdB = new ProjectDetail();
          pdB.canModify = canModify.ElementAt(veld);
          pdB.categoryA = catA;
          pdB.categoryB = catB;
          pdB.maxAmount = maxAmount.ElementAt(veld);
          pdB.minAmount = minAmount.ElementAt(veld);
          veld = veld + 1;
          project.projectDetails.Add(pdB);

          foreach (Domain.Budget.CategoryC catC in catB.CategoriesC)
      {
            if (veld < canModify.Count) { 
            ProjectDetail pdC = new ProjectDetail();
            pdC.canModify = canModify.ElementAt(veld);
            pdC.categoryA = catA;
            pdC.categoryB = catB;
            pdC.categoryC = catC;
            pdC.maxAmount = maxAmount.ElementAt(veld);
            pdC.minAmount = minAmount.ElementAt(veld);
              veld = veld + 1;
              project.projectDetails.Add(pdC);
            }
          }
        }
      }

      //save
     return  repo.CreateProject(project);
    }

    public void updateProject(Project project)
    {
      repo.UpdateProject(project);
    }

    public IEnumerable<Proposition> getPropositionsForUserPlace(int postalCode)
    {
      return repo.ReadPropositionsForUserPlace(postalCode);
    }

    public IEnumerable<Project> getProjectsViaPostal(int postalcode)
    {
      return repo.ReadProjectsViaPostal(postalcode);
    }

    public IEnumerable<Comment> getAllCommentsByUserId(string id)
    {
      return repo.ReadCommentsByUserId(id);
    }

    public IEnumerable<Proposition> getPropositionsForProject(int id)
    {
      return repo.ReadPropositionsForProject(id);
    }

    public IEnumerable<Proposition> getAllPropositions()
    {
      return repo.ReadAllPropositions();
    }

    public Proposition getPropositionViaId(int id)
    {
      return repo.ReadPsopositionViaId(id);
    }

    public void removeProposition(int id)
    {
      repo.DeleteProposition(id);
    }

    public IEnumerable<Comment> getAllCommentsByPropositionId(int id)
    {
      return repo.ReadAllCommentsByPropositionId(id);
    }

    public IEnumerable<Comment> getAllComments()
    {
     return repo.ReadAllComments();
    }

    public void addProposition(Proposition p, List<double> first_value)
    {
      List<ProjectDetail> projDetails = p.project.projectDetails.Where(d => d.canModify.Equals(true)).ToList();
      int i = 0;
      foreach (ProjectDetail d in projDetails)
      {
        PropositionDetail propDetail = new PropositionDetail();
        propDetail.categoryA = d.categoryA;
        propDetail.categoryB = d.categoryB;
        propDetail.categoryC = d.categoryC;
        propDetail.amount = first_value.ElementAt(i);
        p.details.Add(propDetail);
        i++;
      }

      repo.createProposition(p);

      //na creeren , toevoegen aan lijst van project
      Project project = p.project;
      project.propositions.Add(p);
      updateProject(project);

    }

   

    public void changeCommentStateToApproved(int id)
    {
      repo.UpdateCommentStateToApproved(id);
    }

    public void removeComment(int id)
    {
      repo.DeleteComment(id);
    }

    public Comment getCommentById(int id)
    {
      return repo.ReadCommentById(id);
    }

    public void changeCommentStateToDenied(int id)
    {
      repo.UpdateCommentStateToDenied(id);
    }

    public IEnumerable<Proposition> getPropositionsForUser(string userId)
    {
      return repo.ReadPropositionsForUser(userId);
    }

    public void changeComment(Comment comment)
    {
      repo.UpdateComment(comment);
    }
    public IEnumerable<Project> GetProjects()
    {
      return repo.ReadProjects();
    }
  }
}



