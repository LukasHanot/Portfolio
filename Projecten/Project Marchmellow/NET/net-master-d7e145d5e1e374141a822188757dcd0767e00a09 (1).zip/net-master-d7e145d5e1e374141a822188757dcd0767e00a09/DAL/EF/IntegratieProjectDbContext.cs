﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using Domain.Project;
using Domain.Budget;
using Domain.Location;

namespace DAL.EF
{
 // [DbConfigurationType(typeof(IntegratieProjectDbConfiguration))]
  public class IntegratieProjectDbContext : DbContext
  {
    private readonly bool delaySave;
    public IntegratieProjectDbContext(bool unitOfWorkPresent = false) : base("DefaultConnection")
    {
      this.Configuration.LazyLoadingEnabled = false;
      delaySave = unitOfWorkPresent;
    }
    //Deze commentaar weghalen bij het veranderen van een model. Daarna terug  in commentaar zetten
    /*
    public IntegratieProjectDbContext() : base("DefaultConnection")
    {
      this.Configuration.LazyLoadingEnabled = false;
   
    }*/
    
    public override int SaveChanges()
    {
      if (delaySave) return -1;
      return base.SaveChanges();
    }
    internal int CommitChanges()
    {
      if (delaySave)
      {
        return base.SaveChanges();
      }
      throw new InvalidOperationException("No UnitOfWork present, use SaveChanges instead");
    }
    public DbSet<Project> Project { get; set; }
    public DbSet<ProjectDetail> ProjectDetail { get; set; }
    public DbSet<Place> Place { get; set; }
    public DbSet<Comment> Comment { get; set; }
    public DbSet<Proposition> Proposition { get; set; }
    public DbSet<BudgetLine> Budget { get; set; }
    public DbSet<CategoryA> CategoryA { get; set; }
    public DbSet<CategoryB> CategoryB { get; set; }
    public DbSet<CategoryC> CategoryC { get; set; }
    public DbSet<AnnualAccount> AnnualAccount { get; set; }
    public DbSet<PostalCode> PostalCode { get; set; }
    public DbSet<PostalHead> PostalHead { get; set; }
    public DbSet<Domain.Budget.Action> Action { get; set; }

    protected override void OnModelCreating(DbModelBuilder modelBuilder)
    {
      modelBuilder.Entity<Project>().HasKey(t => t.nr);
      modelBuilder.Entity<ProjectDetail>().HasKey(t => t.nr);
      modelBuilder.Entity<Comment>().HasKey(t => t.nr);
      modelBuilder.Entity<Proposition>().HasKey(t => t.nr);
      modelBuilder.Entity<BudgetLine>().HasKey(t => t.number);
      modelBuilder.Entity<CategoryA>().HasKey(t => t.nr);
      modelBuilder.Entity<CategoryB>().HasKey(t => t.nr);
      modelBuilder.Entity<CategoryC>().HasKey(t => t.nr);
      modelBuilder.Entity<AnnualAccount>().HasKey(t => t.number);
      modelBuilder.Entity<Place>().HasKey(t => t.nr);
      modelBuilder.Entity<PostalCode>().HasKey(t => t.nr);
      modelBuilder.Entity<PostalHead>().HasKey(t => t.nr);
      modelBuilder.Entity<Domain.Budget.Action>().HasKey(t=> t.nr);

      //modelBuilder.Entity<CategoryA>().HasMany<CategoryB>();
      modelBuilder.Entity<Project>().HasMany<Proposition>(prop => prop.propositions);
      modelBuilder.Entity<CategoryA>().HasMany<CategoryB>(c => c.CategoriesB);
      modelBuilder.Entity<CategoryB>().HasMany<CategoryC>(c => c.CategoriesC);
      modelBuilder.Entity<Project>().HasMany<ProjectDetail>(p => p.projectDetails);
      modelBuilder.Entity<Proposition>().HasMany<PropositionDetail>(p => p.details);
      modelBuilder.Entity<Proposition>().HasMany<Comment>(c => c.comments);

     
    }
  }
}
