﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;
using Domain.Project;

namespace DAL.EF
{
  public class IntegratieProjectDbInitializer : DropCreateDatabaseIfModelChanges<IntegratieProjectDbContext>
  {
    protected override void Seed(IntegratieProjectDbContext context)
    {
      /*context.Action.Load();
      context.Budget.Load();
      context.CategoryA.Load();
      context.CategoryB.Load();
      context.CategoryC.Load();
      context.PostalCode.Load();
      context.PostalHead.Load();*/
      /*
      Project p1 = new Project()
      {
        startDate = new DateTime(2016, 9, 9, 13, 5, 59),
        endDate = new DateTime(2017, 9, 9, 13, 5, 59),
        text = "Voorbeeld project",
        type = TypeProject.BESPARING,
        status = Status.OPEN,
        propositions = { new Proposition(), new Proposition() },
        amount = 700
      };
      context.Project.Add(p1);
      context.SaveChanges();*/
    }
  }
}
