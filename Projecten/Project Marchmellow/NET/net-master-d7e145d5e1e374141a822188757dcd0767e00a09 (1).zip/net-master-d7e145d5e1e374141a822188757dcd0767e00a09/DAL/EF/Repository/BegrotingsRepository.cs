﻿using Domain.Budget;
using Domain.Location;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;

namespace DAL.EF
{
    public class BegrotingsRepository
    {
        private readonly IntegratieProjectDbContext ctx;
        private bool ActionBestaatNiet = false;
        private bool PostalheadBestaatNiet = false;
        private string actionCode;
        private string actionShort;


        public BegrotingsRepository(UnitOfWork uow)
        {
            ctx = uow.Context;
            //ctx.Action.Load();

        }

        //Inlezen budget
        public BegrotingsRepository()
        {
            ctx = new IntegratieProjectDbContext();
        }

        public void createBudget(DataSet result)
        {
            //methode uitschrijven om van de result.Tables[0] de data uit te lezen, rij per rij en deze in de database te zetten.
            //code om het weer te geven op de pagina, en er dus door te bladeren.
            LoadAlles();

            //Itereer door elke rij
            int rij = 0;
            foreach (DataRow row in result.Tables[0].Rows)
            {
                BudgetLine budgetLine = new BudgetLine();
                budgetLine.group = row.ItemArray[0].ToString().Trim();

                budgetLine.management = readManagement(row.ItemArray[1].ToString().Trim());


                //actie toevoegen op basis van actie code
                Domain.Budget.Action act = readActionPK(row.ItemArray[2].ToString().Trim());
                if (act != null) { budgetLine.Action = act; }
                else { actionCode = row.ItemArray[2].ToString().Trim(); ActionBestaatNiet = true; }



                if (ActionBestaatNiet)
                {
                    actionShort = row.ItemArray[3].ToString().Trim();
                }
                if (ActionBestaatNiet)
                {
                    Domain.Budget.Action actionNieuw = new Domain.Budget.Action
                    {
                        code = actionCode,
                        shortDescription = actionShort,
                        longDescription = row.ItemArray[4].ToString().Trim()
                    };
                    budgetLine.Action = actionNieuw;
                    ctx.SaveChanges();
                }

                ActionBestaatNiet = false;

                //categorieA toevoegen op basis van samengestelde string
                budgetLine.categoryA = readCatA(row.ItemArray[5].ToString().Trim());


                //Categorie B toevoegen
                budgetLine.categoryB = readCatB(row.ItemArray[6].ToString().Trim());

                //categorie C toevoegen
                budgetLine.categoryC = readCatC(row.ItemArray[7].ToString().Trim());

                //boekjaar opzoeken
                budgetLine.bookingYear = Int32.Parse(row.ItemArray[12].ToString().Trim());

                //bedrag
                budgetLine.expense = Double.Parse(row.ItemArray[14].ToString().Trim());

                //lijn opslaan in context
                InitializeSubcategories(budgetLine.categoryA, budgetLine.categoryB, budgetLine.categoryC);
                ctx.Budget.Add(budgetLine);


                //ctx.SaveChanges();
                rij++;
                //om de 50 rijen, inserts, gaan we committen naar de databank
                if (rij % 1000 == 0)
                {
                    ctx.SaveChanges();
                }

            }
            ctx.SaveChanges();


        }

        public object ReadComparisonBudget(int postal, int year)
        {
            throw new NotImplementedException();
        }


        public List<CategoryB> ReadCategoryB()
        {
            LoadAlles();
            return ctx.CategoryB.ToList();
        }
        public List<CategoryC> ReadCategoryC()
        {
            LoadAlles();
            return ctx.CategoryC.ToList();
        }

        public List<CategoryA> ReadCategoryA()
        {
            LoadAlles();
            return ctx.CategoryA.ToList();
        }

        public List<CategoryA> ReadCategories()
        {
            LoadAlles();
            return ctx.CategoryA.ToList();
        }

        private void InitializeSubcategories(CategoryA categoryA, CategoryB categoryB, CategoryC categoryC)
        {
            if (!categoryA.CategoriesB.Contains(categoryB))
            {
                categoryA.CategoriesB.Add(categoryB);
            }
            if (!categoryB.CategoriesC.Contains(categoryC))
            {
                categoryB.CategoriesC.Add(categoryC);
            }
        }

        /*private void LinkSubCategories()
        {
          foreach (CategoryA catA in ctx.CategoryA.ToList<CategoryA>())
          {
            foreach (CategoryB catB in ctx.CategoryB.ToList<CategoryB>().Where(c => c.categoryID.Substring(0,2).Equals(catA.categoryID)))
            {
              catA.CategoriesB.Add(catB);
            }
          }

          foreach (CategoryB catB in ctx.CategoryB.ToList<CategoryB>())
          {
            foreach (CategoryC catC in ctx.CategoryC.ToList<CategoryC>().Where(c => c.categoryID.Substring(0, 3).Equals(catB.categoryID)))
            {
              catB.CategoriesC.Add(catC);
            }
          }


        }*/

        private CategoryC readCatC(string v)
        {
            //checkIfExists
            CategoryC catC = ctx.CategoryC.Where(c => c.categoryID.Equals(v.Substring(0, 4))).FirstOrDefault();
            if (catC != null)
            {
                return catC;
            }
            else
            {
                return createCatC(v);
            }
        }

        private CategoryC createCatC(string v)
        {

            CategoryC catC = new CategoryC { categoryID = v.Substring(0, 4), name = v.Substring(5, (v.Length - 5)) };
            ctx.CategoryC.Add(catC);
            //CategoryB headCat = getHeadCatOfC(catC);
            //headCat.CategoriesC.Add(catC);

            ctx.SaveChanges();
            return catC;
        }

        private CategoryB getHeadCatOfC(CategoryC catC)
        {
            return ctx.CategoryB.Where(a => a.categoryID.Equals(catC.categoryID.Substring(0, 3))).FirstOrDefault();
        }

        private CategoryB readCatB(string v)
        {
            //checkIfExists
            CategoryB catB = ctx.CategoryB.Where(c => c.categoryID.Equals(v.Substring(0, 3))).FirstOrDefault();
            if (catB != null)
            {
                return catB;
            }
            else
            {
                return createCatB(v);

            }
        }

        private CategoryB createCatB(string v)
        {

            CategoryB catB = new CategoryB { categoryID = v.Substring(0, 3), name = v.Substring(4, (v.Length - 4)) };
            ctx.CategoryB.Add(catB);
            //CategoryA headCat = getHeadCatOfB(catB) ;
            //headCat.CategoriesB.Add(catB);
            ctx.SaveChanges();
            return catB;
        }

        private CategoryA getHeadCatOfB(CategoryB catB)
        {
            return ctx.CategoryA.Where(a => a.categoryID.Equals(catB.categoryID.Substring(0, 2))).FirstOrDefault();
        }

        private CategoryA readCatA(string v)
        {
            //checkIfExists
            CategoryA catA = ctx.CategoryA.Where(c => c.categoryID.Equals(v.Substring(0, 2))).FirstOrDefault();
            if (catA != null)
            {
                return catA;
            }
            else
            {
                return createCatA(v);

            }

        }

        private CategoryA createCatA(string v)
        {

            CategoryA catA = new CategoryA { categoryID = v.Trim().Substring(0, 2), name = v.Trim().Substring(3, (v.Length - 3)) };
            ctx.CategoryA.Add(catA);
            ctx.SaveChanges();
            return catA;
        }

        private Domain.Budget.Action readActionPK(string v)
        {
            return ctx.Action.Where(a => a.code.Equals(v)).FirstOrDefault();

        }


        private Management readManagement(String col)
        {
            if (col.StartsWith("AGB"))
            {
                return Management.AGB;
            }
            else if (col.StartsWith("AG"))
            {
                return Management.AGKinder;
            }
            else if (col.StartsWith("OCMW"))
            {
                return Management.OCMW;

            }
            else
            {
                return Management.GEMEENTE;
            }
        }

        public IEnumerable<BudgetLine> ReadBudgets()
        {
            LoadAlles();
            IEnumerable<BudgetLine> budgets = ctx.Budget.ToList<BudgetLine>().Where(b => b.expense != 0);
            return budgets;
        }

        public IEnumerable<BudgetLine> ReadBudget()
        {
            LoadAlles();
            IEnumerable<BudgetLine> budget = ctx.Budget.AsEnumerable().Where(b => b.expense != 0);

            return budget;
        }
        public object ReadBudgetYear(int year)
        {
            LoadAlles();
            IEnumerable<BudgetLine> budget = ctx.Budget.AsEnumerable().Where(b => b.bookingYear == year).Where(b => b.expense != 0);

            return budget;
        }


        public object ReadBudgetYearPostal(int year, int postal)
        {

            LoadAlles();
            PostalCode pc = ctx.PostalCode.Where(p => p.postalCode == postal).FirstOrDefault();
            PostalHead ph = new PostalHead();
            ph = pc.postalHead;
            if (pc != null)
            {
                return ctx.Budget.AsEnumerable().Where(b => b.group.Equals(ph.name)).Where(b => b.bookingYear == year).Where(b => b.expense != 0);
            }

            return null;
        }

        public IEnumerable<BudgetLine> ReadBudgetPostal(int postal)
        {
            LoadAlles();
            PostalCode pc = ctx.PostalCode.Where(p => p.postalCode == postal).FirstOrDefault();
            PostalHead ph = new PostalHead();
            ph = pc.postalHead;
            if (pc != null)
            {
                return ctx.Budget.AsEnumerable().Where(b => b.group.Equals(ph.name)).Where(b => b.expense != 0);
            }
            else
            {
                return null;
            }


        }


        private void LoadAlles()
        {
            ctx.Action.Load();
            ctx.Budget.Load();
            ctx.CategoryA.Load();
            ctx.CategoryB.Load();
            ctx.CategoryC.Load();
            ctx.PostalCode.Load();
            ctx.PostalHead.Load();
        }
        public void createTaxes(DataSet result)
        {
            foreach (DataRow row in result.Tables[0].Rows)
            {
                LoadAlles();
                string name = row.ItemArray[0].ToString().Trim();
                PostalCode pc = ctx.PostalCode.Where(p => p.name.Equals(name)).FirstOrDefault();
                if (pc != null)
                {
                    int pk = pc.nr;
                    PostalCode pc1 = ctx.PostalCode.Find(pk);
                    pc1.taxe = double.Parse(row.ItemArray[1].ToString().Trim());
                }



            }
            ctx.SaveChanges();
        }

        public void createPostcodes(DataSet result)
        {
            //methode uitschrijven om van de result.Tables[0] de data uit te lezen, rij per rij en deze in de database te zetten.
            //Itereer door elke rij
            foreach (DataRow row in result.Tables[0].Rows)
            {

                PostalCode postalCode = new PostalCode();
                PostalHead postalHead = new PostalHead();

                //postcode sub
                postalCode.postalCode = int.Parse(row.ItemArray[0].ToString().Trim());


                //sub naam gemeente
                postalCode.name = row.ItemArray[1].ToString().Trim();

                //postcode hoofdgemeente
                //Zie of hoofdgemeente bestaat
                int pcode = int.Parse(row.ItemArray[2].ToString().Trim());
                postalHead = readPostalHead(pcode);
                if (postalHead != null)
                {
                    PostalheadBestaatNiet = false;
                }
                else
                {
                    postalHead = new PostalHead();
                    postalHead.postalCode = pcode;
                    PostalheadBestaatNiet = true;
                }



                //hoofdgemeente naam
                if (PostalheadBestaatNiet)
                {
                    postalHead.name = row.ItemArray[3].ToString().Trim();
                }

                //provincie hoofdgemeente
                if (PostalheadBestaatNiet)
                {
                    postalHead.province = row.ItemArray[4].ToString().Trim();
                }



                //save en link de data met elkaar
                if (PostalheadBestaatNiet)
                {
                    createPostalHead(postalHead);
                }
                postalCode.postalHead = postalHead;
                ctx.PostalCode.Add(postalCode);
                PostalheadBestaatNiet = false;


            }
            ctx.SaveChanges();
        }

        private void createPostalHead(PostalHead postalHead)
        {
            ctx.PostalHead.Add(postalHead);
            ctx.SaveChanges();

        }

        public PostalHead readPostalHeadOfPostalCode(int postal)
        {
            LoadAlles();
            return ctx.PostalCode.Where(p => p.postalCode == postal).FirstOrDefault().postalHead;

        }

        public PostalHead readPostalHead(int v)
        {
            return ctx.PostalHead.Where(p => p.postalCode == v).FirstOrDefault();
        }

    }
}
