﻿using Domain.Budget;
using Domain.Location;
using Domain.Project;
using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DAL.EF
{
  public class LocatieRepository
  {
    private readonly IntegratieProjectDbContext ctx;

    public LocatieRepository(UnitOfWork uow)
    {
      ctx = uow.Context;
    }
    public PostalCode CreatePostalCode(PostalCode postalcode)
    {
      ctx.PostalCode.Add(postalcode);
      ctx.SaveChanges();
      return postalcode; // 
    }

    public void UpdatePostalCode(PostalCode postalcode)
    {
      ctx.Entry(postalcode).State = System.Data.Entity.EntityState.Modified;
      ctx.SaveChanges();
    }
    public void UpdatePlace(Place place)
    {
      ctx.Entry(place).State = System.Data.Entity.EntityState.Modified;
      ctx.SaveChanges();
    }

    /*public int ReadPostalCode(string email)
    {
      throw new NotImplementedException();
    }*/
    public IEnumerable<PostalCode> ReadPostalCodes()
    {
      IEnumerable<PostalCode> postalcodes = ctx.PostalCode.AsEnumerable<PostalCode>();
      return postalcodes;
    }
    public IEnumerable<PostalCode> ReadPostalCodesByUserPostalHead(int userPostalcode)
    {
      ctx.PostalCode.Load();
      ctx.PostalHead.Load();
      PostalHead postalHead = ctx.PostalCode.Where(p => p.postalCode==userPostalcode).FirstOrDefault().postalHead;
      IEnumerable<PostalCode> postalcodes = ctx.PostalCode.Where(t => t.postalHead.nr == postalHead.nr);
      return postalcodes;
    }
    /*
    public string ReadLocation(int postcalCode)
    {
      return ctx.Project.Find(postcalCode).ToString();
    }*/
    public PostalCode ReadPostalCode(int postcalCode)
    {
      return ctx.PostalCode.Find(postcalCode);
    }
    public Place ReadPlaceByPostalCode(int postalCode)
    {
      return ctx.Place.Where(t => t.postalCode == postalCode).FirstOrDefault();
    }
    public PostalHead ReadPostalHeadByUserPostalCode(int postalCode)
    {
      return ctx.PostalHead.Where(t => t.postalCode == postalCode).FirstOrDefault();
    }
    public PostalHead ReadPostalHeadByUserPostalCode(int? postalCode)
    {
      return ctx.PostalHead.Where(t => t.postalCode == postalCode).FirstOrDefault();
    }
    
    public IEnumerable<PostalHead> ReadPostalHeadsWithBudget(IEnumerable<BudgetLine> budgetlines)
    {
      IEnumerable<BudgetLine> groupedBudgetlines = budgetlines.GroupBy(t => t.group).Select(t => t.First());
      List<PostalHead> postalheads = new List<PostalHead>();
      foreach(BudgetLine b in groupedBudgetlines)
    {
        PostalHead p = new PostalHead();
        p = ctx.PostalHead.Where(t => t.name == b.group).FirstOrDefault();
        postalheads.Add(p);
      }
      return postalheads.AsEnumerable();

    }
   /* public IEnumerable<PostalHead> ReadPostalHeadsWithProjects(IEnumerable<Project> allProjects)
    {

    }*/
    
    /*public IEnumerable<Postalcode> ReadLocations()
    {
      IEnumerable<PostalCode> postalcodes = ctx.PostalCode.AsEnumerable<PostalCode>();
      return postalcodes;
    }*/

    public PostalCode ReadPostalCodeByPostalcode(int postalcode)
    {
      return ctx.PostalCode.Where(t => t.postalCode == postalcode).FirstOrDefault();
    }

   
  }
}
