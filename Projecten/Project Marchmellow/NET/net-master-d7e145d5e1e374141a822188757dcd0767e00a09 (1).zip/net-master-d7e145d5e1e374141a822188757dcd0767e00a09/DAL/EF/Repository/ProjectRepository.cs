﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain;
using Domain.Project;
using System.Data;
using System.Data.Entity;

namespace DAL.EF
{
  public class ProjectRepository
  {
    private readonly IntegratieProjectDbContext ctx;

    public ProjectRepository(UnitOfWork uow)
    {
      ctx = uow.Context;
    }

    private void LoadAlles()
    {
      ctx.Action.Load();
      ctx.Budget.Load();
      ctx.CategoryA.Load();
      ctx.CategoryB.Load();
      ctx.CategoryC.Load();
      ctx.PostalCode.Load();
      ctx.PostalHead.Load();
      ctx.Proposition.Load();
      ctx.ProjectDetail.Load();
      ctx.Project.Load();
      ctx.Comment.Load();
      ctx.Place.Load();
    }

    public Project ReadProject(int? projectId)
    {
      //Read a project based on the ID
      LoadAlles();
      return ctx.Project.Find(projectId);
     
    }

    public IEnumerable<Project> ReadProjects()
    {
      //Read all projects
      IEnumerable<Project> projects = ctx.Project.AsEnumerable<Project>();
      return projects;
    }

    public void UpdateProject(Project project)
    {
      //Update a project
      ctx.Entry(project).State = System.Data.Entity.EntityState.Modified;
      ctx.SaveChanges();
    }

    public void DeleteProject(int projectId)
    {
      //Delete a project based on ID
      Project project = ctx.Project.Find(projectId);
      ctx.Project.Remove(project);
      ctx.SaveChanges();
    }

    public Project CreateProject(Project project)
    {
      //Create a project
      ctx.Project.Add(project);
      ctx.SaveChanges();
      return project; // 
    }

    public IEnumerable<Project> ReadProjectsViaPostal(int postalcode)
    {
      //Read the projects with the admin's postal code
      return ctx.Project.Where(p => p.postalCode == postalcode);
    }

    public IEnumerable<Proposition> ReadAllPropositions()
    {
      LoadAlles();
      //Read all the propositions 
      return ctx.Proposition.AsEnumerable<Proposition>();
    }

    public IEnumerable<Comment> ReadCommentsByUserId(string id)
    {
      LoadAlles();
      //Read all the comments made by the logged in user
      return ctx.Comment.Where(c => c.userId == id);
    }

    public IEnumerable<Comment> ReadAllComments()
    {
      LoadAlles();
      //Read all the comments for the moderator
      return ctx.Comment.AsEnumerable<Comment>();
    }

    public IEnumerable<Proposition> ReadPropositionsForProject(int id)
    {
      LoadAlles();
      //Read all the propositions for a project
      return ctx.Proposition.Where(p => p.project.nr == id);
    }

    public Proposition ReadPsopositionViaId(int id)
    {
      LoadAlles();
      //Read the propositions based on the ID
      return ctx.Proposition.Find(id);
    }

    public void UpdateComment(Comment comment)
    {
      //Update a Comment
      ctx.Entry(comment).State = System.Data.Entity.EntityState.Modified;
      ctx.SaveChanges();
    }

    public IEnumerable<Proposition> ReadPropositionsForUserPlace(int postalCode)
    {
      //Read the users place propositions
      LoadAlles();
      return ctx.Proposition.Where(p => p.project.postalCode == postalCode);
    }

    public void DeleteProposition(int id)
    {
      //Delete the proposition from the database by ID
      Proposition proposition = ctx.Proposition.Find(id);
      ctx.Proposition.Remove(proposition);
      ctx.SaveChanges();
    }

    public IEnumerable<Proposition> ReadPropositionsForUser(string userId)
    {
      LoadAlles();
      //Read all the propositions from the database for a user
      return ctx.Proposition.Where(c => c.userId == userId);
    }

    public IEnumerable<Comment> ReadAllCommentsByPropositionId(int id)
    {
      LoadAlles();
      //Read all the comments from the database by Proposition
      return ctx.Comment.Where(c => c.proposition.nr == id);
    }


    public void DeleteComment(int id)
    {
      //Delete the comment, based on the id
      Comment comment = ctx.Comment.Find(id);
      ctx.Comment.Remove(comment);
      ctx.SaveChanges();
    }

    public void UpdateCommentStateToApproved(int id)
    {
      //Update a Comment and set to approved/denied
      Comment comment = ctx.Comment.Find(id);
      comment.commentState = CommentStatus.APPROVED;
      ctx.SaveChanges();
    }

    public void UpdateCommentStateToDenied(int id)
    {
      //Update a Comment and set to approved/denied
      Comment comment = ctx.Comment.Find(id);
      comment.commentState = CommentStatus.DENIED;
      ctx.SaveChanges();
    }

    public void createProposition(Proposition p)
    {
      ctx.Proposition.Add(p);
      ctx.SaveChanges();
    }

    public Comment ReadCommentById(int id)
    {
      LoadAlles();
      return ctx.Comment.Find(id);
    }

   
  }
}
