namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.AnnualAccounts",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        categoryA_categoryID = c.Int(),
                        categoryB_categoryID = c.Int(),
                        categoryC_categoryID = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_categoryID)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_categoryID)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_categoryID)
                .Index(t => t.categoryA_categoryID)
                .Index(t => t.categoryB_categoryID)
                .Index(t => t.categoryC_categoryID);
            
            CreateTable(
                "dbo.CategoryAs",
                c => new
                    {
                        categoryID = c.Int(nullable: false, identity: true),
                        name = c.String(),
                    })
                .PrimaryKey(t => t.categoryID);
            
            CreateTable(
                "dbo.CategoryBs",
                c => new
                    {
                        categoryID = c.Int(nullable: false, identity: true),
                        name = c.String(),
                    })
                .PrimaryKey(t => t.categoryID);
            
            CreateTable(
                "dbo.CategoryCs",
                c => new
                    {
                        categoryID = c.Int(nullable: false, identity: true),
                        name = c.String(),
                    })
                .PrimaryKey(t => t.categoryID);
            
            CreateTable(
                "dbo.Budgets",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        categoryA_categoryID = c.Int(),
                        categoryB_categoryID = c.Int(),
                        categoryC_categoryID = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_categoryID)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_categoryID)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_categoryID)
                .Index(t => t.categoryA_categoryID)
                .Index(t => t.categoryB_categoryID)
                .Index(t => t.categoryC_categoryID);
            
            CreateTable(
                "dbo.Comments",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.Projects",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        startDate = c.DateTime(nullable: false),
                        endDate = c.DateTime(nullable: false),
                        text = c.String(),
                        type = c.Int(nullable: false),
                        status = c.Int(nullable: false),
                        minAmount = c.Double(nullable: false),
                        maxAmount = c.Double(nullable: false),
                        amount = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.Propositions",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        date = c.DateTime(nullable: false),
                        Project_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.Projects", t => t.Project_nr)
                .Index(t => t.Project_nr);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.Propositions", "Project_nr", "dbo.Projects");
            DropForeignKey("dbo.Budgets", "categoryC_categoryID", "dbo.CategoryCs");
            DropForeignKey("dbo.Budgets", "categoryB_categoryID", "dbo.CategoryBs");
            DropForeignKey("dbo.Budgets", "categoryA_categoryID", "dbo.CategoryAs");
            DropForeignKey("dbo.AnnualAccounts", "categoryC_categoryID", "dbo.CategoryCs");
            DropForeignKey("dbo.AnnualAccounts", "categoryB_categoryID", "dbo.CategoryBs");
            DropForeignKey("dbo.AnnualAccounts", "categoryA_categoryID", "dbo.CategoryAs");
            DropIndex("dbo.Propositions", new[] { "Project_nr" });
            DropIndex("dbo.Budgets", new[] { "categoryC_categoryID" });
            DropIndex("dbo.Budgets", new[] { "categoryB_categoryID" });
            DropIndex("dbo.Budgets", new[] { "categoryA_categoryID" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryC_categoryID" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryB_categoryID" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryA_categoryID" });
            DropTable("dbo.Propositions");
            DropTable("dbo.Projects");
            DropTable("dbo.Comments");
            DropTable("dbo.Budgets");
            DropTable("dbo.CategoryCs");
            DropTable("dbo.CategoryBs");
            DropTable("dbo.CategoryAs");
            DropTable("dbo.AnnualAccounts");
        }
    }
}
