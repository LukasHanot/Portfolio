namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations1 : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.BegrotingBestands",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                    })
                .PrimaryKey(t => t.nr);
            
        }
        
        public override void Down()
        {
            DropTable("dbo.BegrotingBestands");
        }
    }
}
