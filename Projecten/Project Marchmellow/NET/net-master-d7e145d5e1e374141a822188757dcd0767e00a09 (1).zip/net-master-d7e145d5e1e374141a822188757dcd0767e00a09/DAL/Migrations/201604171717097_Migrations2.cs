namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations2 : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.BegrotingBestands", "group", c => c.String());
            AddColumn("dbo.BegrotingBestands", "boardName", c => c.String());
            AddColumn("dbo.BegrotingBestands", "actieCode", c => c.String());
            AddColumn("dbo.BegrotingBestands", "actieKort", c => c.String());
            AddColumn("dbo.BegrotingBestands", "actieLang", c => c.String());
            AddColumn("dbo.BegrotingBestands", "categoryA", c => c.String());
            AddColumn("dbo.BegrotingBestands", "categoryB", c => c.String());
            AddColumn("dbo.BegrotingBestands", "categoryC", c => c.String());
            AddColumn("dbo.BegrotingBestands", "niveauA", c => c.String());
            AddColumn("dbo.BegrotingBestands", "niveauB", c => c.String());
            AddColumn("dbo.BegrotingBestands", "niveauC", c => c.String());
            AddColumn("dbo.BegrotingBestands", "niveauD", c => c.String());
            AddColumn("dbo.BegrotingBestands", "boekjaar", c => c.Int(nullable: false));
            AddColumn("dbo.BegrotingBestands", "ontvangst", c => c.Int(nullable: false));
            AddColumn("dbo.BegrotingBestands", "uitgave", c => c.Int(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.BegrotingBestands", "uitgave");
            DropColumn("dbo.BegrotingBestands", "ontvangst");
            DropColumn("dbo.BegrotingBestands", "boekjaar");
            DropColumn("dbo.BegrotingBestands", "niveauD");
            DropColumn("dbo.BegrotingBestands", "niveauC");
            DropColumn("dbo.BegrotingBestands", "niveauB");
            DropColumn("dbo.BegrotingBestands", "niveauA");
            DropColumn("dbo.BegrotingBestands", "categoryC");
            DropColumn("dbo.BegrotingBestands", "categoryB");
            DropColumn("dbo.BegrotingBestands", "categoryA");
            DropColumn("dbo.BegrotingBestands", "actieLang");
            DropColumn("dbo.BegrotingBestands", "actieKort");
            DropColumn("dbo.BegrotingBestands", "actieCode");
            DropColumn("dbo.BegrotingBestands", "boardName");
            DropColumn("dbo.BegrotingBestands", "group");
        }
    }
}
