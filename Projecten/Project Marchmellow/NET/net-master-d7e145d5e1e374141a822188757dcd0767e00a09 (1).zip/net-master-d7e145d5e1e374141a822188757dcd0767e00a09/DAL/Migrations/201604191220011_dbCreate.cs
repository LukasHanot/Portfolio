namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class dbCreate : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Actions",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        code = c.String(),
                        shortDescription = c.String(),
                        longDescription = c.String(),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.AnnualAccounts",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        action_nr = c.Int(),
                        categoryA_nr = c.Int(),
                        categoryB_nr = c.Int(),
                        categoryC_nr = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.Actions", t => t.action_nr)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_nr)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_nr)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_nr)
                .Index(t => t.action_nr)
                .Index(t => t.categoryA_nr)
                .Index(t => t.categoryB_nr)
                .Index(t => t.categoryC_nr);
            
           
            
            CreateTable(
                "dbo.Budgets",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        Action_nr = c.Int(),
                        categoryA_nr = c.Int(),
                        categoryB_nr = c.Int(),
                        categoryC_nr = c.Int(),
                        place_nr = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.Actions", t => t.Action_nr)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_nr)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_nr)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_nr)
                .ForeignKey("dbo.Places", t => t.place_nr)
                .Index(t => t.Action_nr)
                .Index(t => t.categoryA_nr)
                .Index(t => t.categoryB_nr)
                .Index(t => t.categoryC_nr)
                .Index(t => t.place_nr);
            
            
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PostalCodes", "postalHead_nr", "dbo.PostalHeads");
            DropForeignKey("dbo.Budgets", "place_nr", "dbo.Places");
            DropForeignKey("dbo.Budgets", "categoryC_nr", "dbo.CategoryCs");
            DropForeignKey("dbo.Budgets", "categoryB_nr", "dbo.CategoryBs");
            DropForeignKey("dbo.Budgets", "categoryA_nr", "dbo.CategoryAs");
            DropForeignKey("dbo.Budgets", "Action_nr", "dbo.Actions");
            DropForeignKey("dbo.AnnualAccounts", "categoryC_nr", "dbo.CategoryCs");
            DropForeignKey("dbo.AnnualAccounts", "categoryB_nr", "dbo.CategoryBs");
            DropForeignKey("dbo.AnnualAccounts", "categoryA_nr", "dbo.CategoryAs");
            DropForeignKey("dbo.AnnualAccounts", "action_nr", "dbo.Actions");
            DropIndex("dbo.PostalCodes", new[] { "postalHead_nr" });
            DropIndex("dbo.Budgets", new[] { "place_nr" });
            DropIndex("dbo.Budgets", new[] { "categoryC_nr" });
            DropIndex("dbo.Budgets", new[] { "categoryB_nr" });
            DropIndex("dbo.Budgets", new[] { "categoryA_nr" });
            DropIndex("dbo.Budgets", new[] { "Action_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryC_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryB_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryA_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "action_nr" });
            DropTable("dbo.Propositions");
            DropTable("dbo.Projects");
            DropTable("dbo.PostalHeads");
            DropTable("dbo.PostalCodes");
            DropTable("dbo.Comments");
            DropTable("dbo.Places");
            DropTable("dbo.Budgets");
            DropTable("dbo.CategoryCs");
            DropTable("dbo.CategoryBs");
            DropTable("dbo.CategoryAs");
            DropTable("dbo.AnnualAccounts");
            DropTable("dbo.Actions");
        }
    }
}
