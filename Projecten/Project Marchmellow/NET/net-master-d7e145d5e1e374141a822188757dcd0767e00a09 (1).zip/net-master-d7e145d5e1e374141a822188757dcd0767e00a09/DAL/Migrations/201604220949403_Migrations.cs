namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Projects", "minAmount", c => c.Double(nullable: false));
            AddColumn("dbo.Projects", "maxAmount", c => c.Double(nullable: false));
        }
        
        public override void Down()
        {
            DropColumn("dbo.Projects", "maxAmount");
            DropColumn("dbo.Projects", "minAmount");
        }
    }
}
