namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations : DbMigration
    {
        public override void Up()
        {
            AddColumn("dbo.Places", "amountChildren", c => c.Int(nullable: false));
            AddColumn("dbo.Places", "amountWomen", c => c.Int(nullable: false));
            AddColumn("dbo.Places", "amountMen", c => c.Int(nullable: false));
            AddColumn("dbo.Places", "surfaceArea", c => c.Double(nullable: false));
            AddColumn("dbo.Places", "compositionCouncil", c => c.String());
            AddColumn("dbo.Places", "aldermen", c => c.String());
            DropColumn("dbo.Places", "political");
        }
        
        public override void Down()
        {
            AddColumn("dbo.Places", "political", c => c.String());
            DropColumn("dbo.Places", "aldermen");
            DropColumn("dbo.Places", "compositionCouncil");
            DropColumn("dbo.Places", "surfaceArea");
            DropColumn("dbo.Places", "amountMen");
            DropColumn("dbo.Places", "amountWomen");
            DropColumn("dbo.Places", "amountChildren");
        }
    }
}
