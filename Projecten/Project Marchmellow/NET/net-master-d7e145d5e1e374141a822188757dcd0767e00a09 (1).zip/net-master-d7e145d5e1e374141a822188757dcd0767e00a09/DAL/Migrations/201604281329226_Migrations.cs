namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class Migrations : DbMigration
    {
        public override void Up()
        {
            DropIndex("dbo.Propositions", new[] { "Project_nr" });
            CreateTable(
                "dbo.ProjectDetails",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        minAmount = c.Double(nullable: false),
                        maxAmount = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.nr);
            
            AddColumn("dbo.CategoryAs", "Project_nr", c => c.Int());
            AddColumn("dbo.Comments", "date", c => c.DateTime(nullable: false));
            AddColumn("dbo.Comments", "text", c => c.String());
            AddColumn("dbo.Comments", "userId", c => c.String());
            AddColumn("dbo.Comments", "propisitionId", c => c.Int(nullable: false));
            AddColumn("dbo.Comments", "userEmail", c => c.String());
            AddColumn("dbo.Comments", "commentState", c => c.Int(nullable: false));
            AddColumn("dbo.Propositions", "userId", c => c.String());
            CreateIndex("dbo.CategoryAs", "Project_nr");
            CreateIndex("dbo.Propositions", "project_nr");
            AddForeignKey("dbo.CategoryAs", "Project_nr", "dbo.Projects", "nr");
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.CategoryAs", "Project_nr", "dbo.Projects");
            DropIndex("dbo.Propositions", new[] { "project_nr" });
            DropIndex("dbo.CategoryAs", new[] { "Project_nr" });
            DropColumn("dbo.Propositions", "userId");
            DropColumn("dbo.Comments", "commentState");
            DropColumn("dbo.Comments", "userEmail");
            DropColumn("dbo.Comments", "propisitionId");
            DropColumn("dbo.Comments", "userId");
            DropColumn("dbo.Comments", "text");
            DropColumn("dbo.Comments", "date");
            DropColumn("dbo.CategoryAs", "Project_nr");
            DropTable("dbo.ProjectDetails");
            CreateIndex("dbo.Propositions", "Project_nr");
        }
    }
}
