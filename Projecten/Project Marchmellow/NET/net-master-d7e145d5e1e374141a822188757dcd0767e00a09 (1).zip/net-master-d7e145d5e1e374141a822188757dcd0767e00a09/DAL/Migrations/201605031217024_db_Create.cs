namespace DAL.Migrations
{
    using System;
    using System.Data.Entity.Migrations;
    
    public partial class db_Create : DbMigration
    {
        public override void Up()
        {
            CreateTable(
                "dbo.Actions",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        code = c.String(),
                        shortDescription = c.String(),
                        longDescription = c.String(),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.AnnualAccounts",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        action_nr = c.Int(),
                        categoryA_nr = c.Int(),
                        categoryB_nr = c.Int(),
                        categoryC_nr = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.Actions", t => t.action_nr)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_nr)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_nr)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_nr)
                .Index(t => t.action_nr)
                .Index(t => t.categoryA_nr)
                .Index(t => t.categoryB_nr)
                .Index(t => t.categoryC_nr);
            
            CreateTable(
                "dbo.CategoryAs",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        name = c.String(),
                        categoryID = c.String(),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.CategoryBs",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        name = c.String(),
                        categoryID = c.String(),
                        CategoryA_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.CategoryAs", t => t.CategoryA_nr)
                .Index(t => t.CategoryA_nr);
            
            CreateTable(
                "dbo.CategoryCs",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        name = c.String(),
                        categoryID = c.String(),
                        CategoryB_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.CategoryBs", t => t.CategoryB_nr)
                .Index(t => t.CategoryB_nr);
            
            CreateTable(
                "dbo.BudgetLines",
                c => new
                    {
                        number = c.Int(nullable: false, identity: true),
                        group = c.String(),
                        management = c.Int(nullable: false),
                        bookingYear = c.Int(nullable: false),
                        expense = c.Double(nullable: false),
                        Action_nr = c.Int(),
                        categoryA_nr = c.Int(),
                        categoryB_nr = c.Int(),
                        categoryC_nr = c.Int(),
                    })
                .PrimaryKey(t => t.number)
                .ForeignKey("dbo.Actions", t => t.Action_nr)
                .ForeignKey("dbo.CategoryAs", t => t.categoryA_nr)
                .ForeignKey("dbo.CategoryBs", t => t.categoryB_nr)
                .ForeignKey("dbo.CategoryCs", t => t.categoryC_nr)
                .Index(t => t.Action_nr)
                .Index(t => t.categoryA_nr)
                .Index(t => t.categoryB_nr)
                .Index(t => t.categoryC_nr);
            
            CreateTable(
                "dbo.Comments",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        date = c.DateTime(nullable: false),
                        text = c.String(),
                        userId = c.String(),
                        userEmail = c.String(),
                        commentState = c.Int(nullable: false),
                        proposition_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.Propositions", t => t.proposition_nr)
                .Index(t => t.proposition_nr);
            
            CreateTable(
                "dbo.Propositions",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        date = c.DateTime(nullable: false),
                        userId = c.String(),
                        userEmail = c.String(),
                        extraInformation = c.String(),
                        project_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.Projects", t => t.project_nr)
                .Index(t => t.project_nr);
            
            CreateTable(
                "dbo.Projects",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        startDate = c.DateTime(nullable: false),
                        endDate = c.DateTime(nullable: false),
                        text = c.String(),
                        type = c.Int(nullable: false),
                        status = c.Int(nullable: false),
                        postalCode = c.Int(nullable: false),
                        year = c.Int(nullable: false),
                        amount = c.Double(nullable: false),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.ProjectDetails",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        canModify = c.Boolean(nullable: false),
                        minAmount = c.Double(nullable: false),
                        maxAmount = c.Double(nullable: false),
                        Project_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.Projects", t => t.Project_nr)
                .Index(t => t.Project_nr);
            
            CreateTable(
                "dbo.Places",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        amountCitizens = c.Int(nullable: false),
                        amountChildren = c.Int(nullable: false),
                        amountWomen = c.Int(nullable: false),
                        amountMen = c.Int(nullable: false),
                        surfaceArea = c.Double(nullable: false),
                        compositionCouncil = c.String(),
                        aldermen = c.String(),
                        postalCode = c.Int(nullable: false),
                        taxPercentage = c.Double(nullable: false),
                        picture = c.String(),
                        about = c.String(),
                    })
                .PrimaryKey(t => t.nr);
            
            CreateTable(
                "dbo.PostalCodes",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        postalCode = c.Int(nullable: false),
                        name = c.String(),
                        taxe = c.Double(),
                        cluster = c.Int(),
                        postalHead_nr = c.Int(),
                    })
                .PrimaryKey(t => t.nr)
                .ForeignKey("dbo.PostalHeads", t => t.postalHead_nr)
                .Index(t => t.postalHead_nr);
            
            CreateTable(
                "dbo.PostalHeads",
                c => new
                    {
                        nr = c.Int(nullable: false, identity: true),
                        postalCode = c.Int(nullable: false),
                        name = c.String(),
                        province = c.String(),
                    })
                .PrimaryKey(t => t.nr);
            
        }
        
        public override void Down()
        {
            DropForeignKey("dbo.PostalCodes", "postalHead_nr", "dbo.PostalHeads");
            DropForeignKey("dbo.Propositions", "project_nr", "dbo.Projects");
            DropForeignKey("dbo.ProjectDetails", "Project_nr", "dbo.Projects");
            DropForeignKey("dbo.Comments", "proposition_nr", "dbo.Propositions");
            DropForeignKey("dbo.BudgetLines", "categoryC_nr", "dbo.CategoryCs");
            DropForeignKey("dbo.BudgetLines", "categoryB_nr", "dbo.CategoryBs");
            DropForeignKey("dbo.BudgetLines", "categoryA_nr", "dbo.CategoryAs");
            DropForeignKey("dbo.BudgetLines", "Action_nr", "dbo.Actions");
            DropForeignKey("dbo.AnnualAccounts", "categoryC_nr", "dbo.CategoryCs");
            DropForeignKey("dbo.AnnualAccounts", "categoryB_nr", "dbo.CategoryBs");
            DropForeignKey("dbo.AnnualAccounts", "categoryA_nr", "dbo.CategoryAs");
            DropForeignKey("dbo.CategoryBs", "CategoryA_nr", "dbo.CategoryAs");
            DropForeignKey("dbo.CategoryCs", "CategoryB_nr", "dbo.CategoryBs");
            DropForeignKey("dbo.AnnualAccounts", "action_nr", "dbo.Actions");
            DropIndex("dbo.PostalCodes", new[] { "postalHead_nr" });
            DropIndex("dbo.ProjectDetails", new[] { "Project_nr" });
            DropIndex("dbo.Propositions", new[] { "project_nr" });
            DropIndex("dbo.Comments", new[] { "proposition_nr" });
            DropIndex("dbo.BudgetLines", new[] { "categoryC_nr" });
            DropIndex("dbo.BudgetLines", new[] { "categoryB_nr" });
            DropIndex("dbo.BudgetLines", new[] { "categoryA_nr" });
            DropIndex("dbo.BudgetLines", new[] { "Action_nr" });
            DropIndex("dbo.CategoryCs", new[] { "CategoryB_nr" });
            DropIndex("dbo.CategoryBs", new[] { "CategoryA_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryC_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryB_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "categoryA_nr" });
            DropIndex("dbo.AnnualAccounts", new[] { "action_nr" });
            DropTable("dbo.PostalHeads");
            DropTable("dbo.PostalCodes");
            DropTable("dbo.Places");
            DropTable("dbo.ProjectDetails");
            DropTable("dbo.Projects");
            DropTable("dbo.Propositions");
            DropTable("dbo.Comments");
            DropTable("dbo.BudgetLines");
            DropTable("dbo.CategoryCs");
            DropTable("dbo.CategoryBs");
            DropTable("dbo.CategoryAs");
            DropTable("dbo.AnnualAccounts");
            DropTable("dbo.Actions");
        }
    }
}
