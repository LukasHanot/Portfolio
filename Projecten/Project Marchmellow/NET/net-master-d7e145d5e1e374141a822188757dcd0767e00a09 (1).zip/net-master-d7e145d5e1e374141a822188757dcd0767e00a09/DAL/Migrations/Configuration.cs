namespace DAL.Migrations
{
  using Domain.Location;
  using System;
  using System.Data.Entity;
  using System.Data.Entity.Migrations;
  using System.Linq;

  internal sealed class Configuration : DbMigrationsConfiguration<DAL.EF.IntegratieProjectDbContext>
    {
        public Configuration()
        {
            AutomaticMigrationsEnabled = false;
        }

        protected override void Seed(DAL.EF.IntegratieProjectDbContext context)
        {
      //  This method will be called after migrating to the latest version.

      //  You can use the DbSet<T>.AddOrUpdate() helper extension method 
      //  to avoid creating duplicate seed data. E.g.
      //
      //    context.People.AddOrUpdate(
      //      p => p.FullName,
      //      new Person { FullName = "Andrew Peters" },
      //      new Person { FullName = "Brice Lambson" },
      //      new Person { FullName = "Rowan Miller" }
      //    );
      //
      /*
      PostalHead ph1 = new PostalHead { postalCode = 1000, name = "Brussel", province = "Brussels Hoofdstedelijk gewest" };
      PostalHead ph2 = new PostalHead { postalCode = 2000, name = "Antwerpen", province = "Antwerpen" };
      PostalHead ph3 = new PostalHead { postalCode = 2110, name = "Wijnegem", province = "Antwerpen" };

      PostalCode pc1 = new PostalCode { postalCode = 2140, name = "Borgerhout", postalHead = ph2 };
      PostalCode pc2 = new PostalCode { postalCode = 2018, name = "Antwerpen", postalHead = ph2 };
      PostalCode pc3 = new PostalCode { postalCode = 1030, name = "Schaarbeek", postalHead = ph1 };
      PostalCode pc4 = new PostalCode { postalCode = 2110, name = "Wijnegem", postalHead = ph3 };


      context.PostalHead.AddOrUpdate(ph1);
      context.PostalHead.AddOrUpdate(ph2);
      context.PostalHead.AddOrUpdate(ph3);

      context.PostalCode.AddOrUpdate(pc1);
      context.PostalCode.AddOrUpdate(pc2);
      context.PostalCode.AddOrUpdate(pc3);
      context.PostalCode.AddOrUpdate(pc4);


      context.SaveChanges();

  */


    }
    }
}
