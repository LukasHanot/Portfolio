﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Budget
{
  public class Action
  {
    [Key]
    public int nr { get; set; }
    public string code { get; set; }
    public string shortDescription { get; set; }
    public string longDescription { get; set; }
  }
}
