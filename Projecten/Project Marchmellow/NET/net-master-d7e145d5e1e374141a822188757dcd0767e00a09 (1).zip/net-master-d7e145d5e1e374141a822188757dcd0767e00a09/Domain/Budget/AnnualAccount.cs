﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Budget
{
  public class AnnualAccount
  {
    private string group { get; set; }
    private string boardName { get; set; }
    private Action action { get; set; }
    private CategoryA categoryA { get; set; }
    private CategoryB categoryB { get; set; }
    private CategoryC categoryC { get; set; }
    private DateTime bookingYear { get; set; }
    private double expense { get; set; }
    [Key]
    public int number { get; set; }
  }
}
