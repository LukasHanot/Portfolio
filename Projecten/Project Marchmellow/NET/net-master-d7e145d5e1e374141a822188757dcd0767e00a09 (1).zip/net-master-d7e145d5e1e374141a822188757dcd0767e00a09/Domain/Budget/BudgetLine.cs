﻿using Domain.Location;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Budget
{
  public class BudgetLine
  {
 
    public String group { get; set; }
    public Management management { get; set; }
    public Action Action { get; set; }
    public CategoryA categoryA { get; set; }
    public CategoryB categoryB { get; set; }
    public CategoryC categoryC { get; set; }
    public int bookingYear { get; set; }
    public double expense { get; set; }
    [Key]
    public int number { get; set; }
  }
}
