﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Domain.Budget
{
  public interface Category
  {
    [Key]
    int nr { get; set; }
    [Required]
    string name { get; set; }
    [Required]
    string categoryID { get; set; }

  }
}
