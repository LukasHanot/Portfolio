﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Domain.Budget
{
  public class CategoryC : Category
  {
    [Key]
    public int nr { get; set; }
    public string name { get; set; }
    public string categoryID { get; set; }

  }
}
