﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Budget
{
  public enum Management
  {
    AGKinder=1, AGB=2, GEMEENTE=3, OCMW =4
  }
}
