﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Domain.Project;

namespace Domain.Location
{
  public class BigPlaceProjectModel
  {
    public Place place { get; set; }
    public IEnumerable<Project.Project> projects { get; set; }
  }
}
