﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Location
{
  public enum Cluster
  {
    [Display(Name = "regionaalstedelijk gebied centrumgemeenten")]
    REGIONAALGC = 1,

    [Display(Name = "structuurondersteunend kleinstedelijk gebied")]
    STRUCTUURONDERSTEUNENDKG=2,

    [Display(Name ="buitengebied")]
    BUITENGEBIED = 3,

    [Display(Name = "grootstedelijk gebied randgemeenten")]
    GROOTSTEDELIJKGR = 4,

    [Display(Name = "kleinstedelijk gebied op provinciaal niveau")]
    KLEINSTEDELIJKGOPN = 5,

    [Display(Name = "regionaalstedelijk gebied randgemeenten")]
    REGIONAALGR = 6,

    [Display(Name = "Vlaams strategisch gebied rond Brussel")]
    VLAAMSSGRB = 7

  }
}
