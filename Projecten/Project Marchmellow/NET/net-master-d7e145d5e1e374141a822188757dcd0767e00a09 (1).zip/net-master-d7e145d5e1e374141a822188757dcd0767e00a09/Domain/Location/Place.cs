﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Location
{
  public class Place
  {
    [Key]
    public int nr { get; set; }

    public int amountCitizens { get; set; }
    public int amountChildren { get; set; }
    public int amountWomen { get; set; }
    public int amountMen { get; set; }
    public double surfaceArea { get; set; }
    public string compositionCouncil { get; set; }
    public string aldermen { get; set; }
    public int postalCode { get; set; }
    public double taxPercentage { get; set; } = 0.1;
    public string picture { get; set; }
    public string about { get; set; }
  }
}
