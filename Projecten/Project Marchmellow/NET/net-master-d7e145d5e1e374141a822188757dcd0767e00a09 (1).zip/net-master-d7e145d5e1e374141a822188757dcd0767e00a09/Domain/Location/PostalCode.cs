﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Location
{
  public class PostalCode
  {
    [Key]
    public int nr { get; set; }
    public int postalCode { get; set; }
    public string name { get; set; }
    public double? taxe { get; set; }
    public Cluster? cluster { get; set; }
    public PostalHead postalHead { get; set; }
  }
}
