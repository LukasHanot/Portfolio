﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Location
{
  public class PostalHead
  {
    [Key]
    public int nr { get; set; }
    public int postalCode { get; set; }
    public string name { get; set; }
    public string province { get; set; }
  }
}
