﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Project
{
  public class Comment
  {
    [Key]
    public int nr { get; set; }
    public DateTime date { get; set; }
    public string text { get; set; }
    public string userId { get; set; }
    public string userEmail { get; set; }
    public CommentStatus commentState { get; set; }
    public Proposition proposition { get; set; }
  }
}
