﻿using Domain.Location;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Project
{
  public class Project
  {
    [Key]
    public int nr { get; set; }
    public DateTime startDate { get; set; }
    public DateTime endDate { get; set; }
    public String text { get; set; }
    public TypeProject type { get; set; }
    public Status status { get; set; }
    public int postalCode { get; set; }
    public int year { get; set; }
    public double amount { get; set; }
    public List<ProjectDetail> projectDetails { get; set; }
    public List<Proposition> propositions { get; set; }


    public Project()
    {
      projectDetails = new List<ProjectDetail>();
      propositions = new List<Proposition>();
    }
 
  }
}
