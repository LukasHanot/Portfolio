﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Domain.Project
{//voor elke budgetLine in project een detail
  public class ProjectDetail
  {
    [Key]
    public int nr { get; set; }
    public bool canModify { get; set; }
    public double minAmount { get; set; }
    public double maxAmount { get; set; }
    public Budget.CategoryA categoryA { get; set; }
    public Budget.CategoryB categoryB { get; set; }
    public Budget.CategoryC categoryC { get; set; }


  }
}
