﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Project
{
  public class Proposition
  {
    public DateTime date { get; set; }
    //public Uri VideoURL { get; set; }
    public IList<Comment> comments { get; set; }
    //public PropositionDetail propositionDetail { get; set; }
    [Key]
    public int nr { get; set; }
    public string userId { get; set; }
    public Project project { get; set; }
    public string extraInformation { get; set; }
    public List<PropositionDetail> details { get; set; }
    public Proposition()
    {
      details = new List<PropositionDetail>();
      comments = new List<Comment>();
    }

  }
}
