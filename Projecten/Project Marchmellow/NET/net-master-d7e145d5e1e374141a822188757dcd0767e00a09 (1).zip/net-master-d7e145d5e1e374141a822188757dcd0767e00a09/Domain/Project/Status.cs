﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Project
{
  public enum Status
  {
    OPEN=1,CLOSED=2
  }
}
