﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web.Mvc;
using System.Net;
using System.Net.Http;
using Microsoft.AspNet.Identity;
using System.Web;
using Microsoft.AspNet.Identity.Owin;
using IntegratieProject.Models;
using BL;

namespace IntegratieProject.Controllers
{   
    [Authorize]
    public class BudgetController : Controller
    {
    
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;

    public BudgetController()
    {
    }

    public BudgetController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
    {
      UserManager = userManager;
      SignInManager = signInManager;

    }

    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }




    
    public ActionResult Index()
      {
        UnitOfWorkManager uowMgr = new UnitOfWorkManager();
        ProjectManager mgrProj = new ProjectManager(uowMgr);
       
        IEnumerable<Domain.Project.Project> projects = mgrProj.getProjects();
        return View(projects);
      }
    [HttpGet]
    public ActionResult Details(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProj = new ProjectManager(uowMgr);
    
      Domain.Project.Project project = mgrProj.getProject(id);
      return View(project);
    }

    [HttpGet]
    public ActionResult Edit(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProj = new ProjectManager(uowMgr);
     
      Domain.Project.Project project = mgrProj.getProject(id);
      ViewBag.projectDetails = project.projectDetails;
      return View(project);
    }
    [HttpPost]
    public ActionResult Edit(Domain.Project.Project project)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProj = new ProjectManager(uowMgr);
      
      mgrProj.updateProject(project);
      uowMgr.Save();
      string ret = "Details/" + project.nr;
      return RedirectToAction(ret,"Budget");
    }

    [HttpGet]
    public ActionResult AddProject(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
     
      BegrotingsManager mgrBud = new BegrotingsManager(uowMgr);

      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      IEnumerable<Domain.Budget.BudgetLine> budgetLines = (IEnumerable<Domain.Budget.BudgetLine>)mgrBud.getBudgetPostal(currentUser.postalcode);
      ViewBag.postalheadcode = mgrBud.getPostalheadCode(currentUser.postalcode);
      ViewBag.BudgetLines = budgetLines.ToList();
      ViewBag.Categories = mgrBud.getCategories();
      ViewBag.year = id;
      
      return View();
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public ActionResult AddProject(BudgetViewModels.BudgetViewModel model)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProj = new ProjectManager(uowMgr);
      BegrotingsManager mgrBud = new BegrotingsManager(uowMgr);

      String[] checkvalue =Request.Form.GetValues("canModify");
      List<bool> canmodifyReal = new List<bool>();
      for (int i = 0; i < checkvalue.Length ; i++)
      {
        if (checkvalue[i].Equals("true"))
        {
          canmodifyReal.Add(true);
          i++;
        }
        else { canmodifyReal.Add(false); }
      }
      model.canModify = canmodifyReal;
      List<Domain.Budget.CategoryA> categoryAs =  mgrBud.getCategoryA();
      Domain.Project.Project proj = mgrProj.addProject(model.amount,model.canModify,model.endDate,model.maxAmount,model.minAmount,model.postalcode,model.startDate,model.status,model.text,model.type,model.year, categoryAs);

      uowMgr.Save();
      return RedirectToAction("Index", "Home");
    }

  }
}
