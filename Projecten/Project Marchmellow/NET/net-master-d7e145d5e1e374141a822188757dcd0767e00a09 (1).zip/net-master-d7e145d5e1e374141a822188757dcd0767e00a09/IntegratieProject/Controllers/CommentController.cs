﻿using BL;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Domain.Project;
using System.Net.Mail;
using System.Net;

namespace IntegratieProject.Controllers
{
  [Authorize]
  public class CommentController : Controller
  {
   
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;

    public CommentController()
    {

    }

    public CommentController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
    {
      UserManager = userManager;
      SignInManager = signInManager;

    }

    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }

    //ONDERSTAANDE METHODES ZIJN VOOR DE GEWONE GEBRUIKER
    // GET: Comment
    public ActionResult SummaryCommentsUser()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
   
    //Alle comments van een user opvragen adhv het userId
    var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      IEnumerable<Comment> comments = mgrProject.getAllCommentsByUserId(currentUser.Id);
      return View(comments);
    }


    //ONDERSTAANDE METHODS ZIJN VOOR DE MODERATOR
    // GET: Comment
    public ActionResult SummaryCommentsMod()
    {

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
     
      //Alle comments opvragen om deze te beheren
      IEnumerable<Comment> comments = mgrProject.getAllComments();
      return View(comments);
    }

    // GET: Comment
    public ActionResult SummaryCommentsForPropMod(int id)
    {

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);

      //Alle comments opvragen van een voorstelom deze te beheren
      IEnumerable<Comment> comments = mgrProject.getAllCommentsByPropositionId(id);
      return View(comments);
    }
    

    // POST: Comment/EditProject/5
    [HttpPost]
    public ActionResult EditCommentStateToApproved(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);

      if (ModelState.IsValid)
      {

        // TODO: Add update logic here
        mgrProject.changeCommentStateToApproved(id);
        return RedirectToAction("SummaryCommentsMod");
      }
      uowMgr.Save();
      return View();
    }

    // POST: Comment/EditProject/5
    [HttpPost]
    public ActionResult EditCommentStateToDenied(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
     
      if (ModelState.IsValid)
      {

        // TODO: Add update logic here
        mgrProject.changeCommentStateToDenied(id);
        return RedirectToAction("SummaryCommentsMod");
      }
      uowMgr.Save();
      return View();
    }

    // POST: Comment/DeleteComment/5
    [HttpPost]

    public ActionResult DeleteComment(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
 
      if (ModelState.IsValid)
      {
        // TODO: Add delete logic here
        mgrProject.removeComment(id);
        return RedirectToAction("SummaryCommentsMod");
      }
      uowMgr.Save();
      return View();
    }

    // GET: Comment
    public ActionResult EditComment(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
   
      Comment comment = mgrProject.getCommentById(id);
      return View(comment);
    }

    [HttpPost]
    public ActionResult EditComment(int id, Comment comment)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
   
      if (ModelState.IsValid)
      {
        // TODO: Add delete logic here
        mgrProject.changeComment(comment);
        return RedirectToAction("SummaryCommentsMod");
      }
      uowMgr.Save();
      return View();
    }
    /*
    //Automatic mail sent when denying or approving a comment
    public void SendMail()
    {
      MailMessage msg = new MailMessage();
      msg.From = new MailAddress("cinema.nandi@gmail.com");
      msg.To.Add("vishalgilbile@rediffmail.com");
      msg.Body = "Testing the automatic mail";
      msg.IsBodyHtml = true;
      msg.Subject = "Movie Data";
      SmtpClient smt = new SmtpClient("smtp.gmail.com");
      smt.Port = 587;
      smt.Credentials = new NetworkCredential("Your Gmail Id", "Your Password");
      smt.EnableSsl = true;
      smt.Send(msg);
    }
    */
  }
}
