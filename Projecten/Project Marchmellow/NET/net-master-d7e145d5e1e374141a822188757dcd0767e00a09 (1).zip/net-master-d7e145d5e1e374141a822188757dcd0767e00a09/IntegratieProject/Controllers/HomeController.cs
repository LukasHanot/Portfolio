﻿using BL;
using Domain.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using IntegratieProject.Models;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.AspNet.Identity;
using Domain.Location;
using Domain.Budget;

namespace IntegratieProject.Controllers
{
  public class HomeController : Controller
  {
    UnitOfWorkManager uowMgr = new UnitOfWorkManager();
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;
    
    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }


    [HttpGet]
    public ActionResult Index(int? postalCode)
    {
          //tijdelijke postalcode
           int postalcode = 2000;

     
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      LocatieManager mgrLocatie = new LocatieManager(uowMgr);
      ProjectManager Projectmgr = new ProjectManager(uowMgr);
      var model = new IndexCommunModel();
      Domain.Location.PostalHead postalhead;
    /*
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;

      if (postalCode == null)
      {
        postalhead = mgrLocatie.getPostalHeadByUserPostalCode(userPostalcode);
      }
      else
      {
        postalhead = mgrLocatie.getPostalHeadByUserPostalCode(postalCode);
      }


      ViewBag.postalhead = postalhead;
      */

     //return View();
    



      IEnumerable<Project> projects = Projectmgr.getProjectsViaPostal(postalcode);

      IEnumerable<PostalCode> postalcodes = mgrLocatie.getPostalCodesFromKnownHeadPostal(postalcode);
      model.postalcodes = postalcodes;

      List<Project> openProjects = new List<Project>();
      foreach (var item in projects)
      {
        if (item.status.Equals( Status.OPEN))
        {
          openProjects.Add(item);
        }
      }
      model.projects = openProjects;
      model.detailscommun = mgrLocatie.getPlaceByPostalCode(postalcode);

      
      return View(model);

    }
    
    /*[HttpGet]
    ActionResult Index(int postalCode)
    {
      return View();
    }*/
    

   /* public ActionResult Index(int postalcode)
    {
      
      String Location = locatiemgr.getLocation(postalcode);
      IEnumerable < Project > Projects = Projectmgr.getProjectsViaPostal(postalcode);

      return View(Location, Projects);
    }*/


    public ActionResult ProjectsOfLocation(int PostalCode)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager Projectmgr = new ProjectManager(uowMgr);

      IEnumerable<Project> Projects = Projectmgr.getProjectsViaPostal(PostalCode);
      return View(Projects);
    }

    public ActionResult DetailsLocation(int PostalCode)
    {
      // String details = locatiemgr.getDetailsLocation(PostalCode);
      //  return View(details);
      return View();
    }
    public ActionResult About()
    {
      ViewBag.Message = "Your application description page.";

      return View();
    }

    public ActionResult Contact()
    {
      ViewBag.Message = "Your contact page.";

      return View();
    }
  }
}