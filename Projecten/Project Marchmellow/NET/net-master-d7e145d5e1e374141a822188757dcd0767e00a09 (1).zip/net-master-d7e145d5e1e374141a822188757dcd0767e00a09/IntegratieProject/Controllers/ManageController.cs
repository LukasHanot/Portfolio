﻿using System;
using System.Linq;
using System.Threading.Tasks;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Microsoft.Owin.Security;
using IntegratieProject.Models;
using Microsoft.AspNet.Identity.EntityFramework;
using System.IO;
using Excel;
using System.Data;
using BL;

namespace IntegratieProject.Controllers
{
    [Authorize]
    public class ManageController : Controller
    {
        private ApplicationSignInManager _signInManager;
        private ApplicationUserManager _userManager;
   

        public ManageController()
        {
        }

        public ManageController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
        {
            UserManager = userManager;
            SignInManager = signInManager;
      
        }
        
        public ApplicationSignInManager SignInManager
        {
            get
            {
                return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
            }
            private set 
            { 
                _signInManager = value; 
            }
        }
        
        public ApplicationUserManager UserManager
        {
            get
            {
                return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
            }
            private set
            {
                _userManager = value;
            }
        }

        //
        // GET: /Manage/SummaryProjects
        public async Task<ActionResult> Index(ManageMessageId? message)
        {
            ViewBag.StatusMessage =
                message == ManageMessageId.ChangePasswordSuccess ? "Your password has been changed."
                : message == ManageMessageId.SetPasswordSuccess ? "Your password has been set."
                : message == ManageMessageId.SetTwoFactorSuccess ? "Your two-factor authentication provider has been set."
                : message == ManageMessageId.Error ? "An error has occurred."
                : message == ManageMessageId.AddPhoneSuccess ? "Your phone number was added."
                : message == ManageMessageId.RemovePhoneSuccess ? "Your phone number was removed."
                : message == ManageMessageId.UpdateProfileSuccess ? "Uw profiel is correct geupdate."
                : "";

            var userId = User.Identity.GetUserId();
            var currentUser = UserManager.FindById(userId);
            var model = new IndexViewModel
            {
                HasPassword = HasPassword(),
                PhoneNumber = await UserManager.GetPhoneNumberAsync(userId),
                TwoFactor = await UserManager.GetTwoFactorEnabledAsync(userId),
                Logins = await UserManager.GetLoginsAsync(userId),
                BrowserRemembered = await AuthenticationManager.TwoFactorBrowserRememberedAsync(userId),
                postalcode = currentUser.postalcode,
                Email = currentUser.Email,
                BirthDay = currentUser.birthday,
                aboutMe = currentUser.aboutMe,
                job = currentUser.job,
                gender = currentUser.gender
              
            };
            return View(model);
        }

    // Post: /Manage/SummaryProjects
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> Index(IndexViewModel model)
    {

      var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());

      ManageMessageId? message;
      user.postalcode = model.postalcode;
      user.gender = model.gender;
      user.birthday = model.BirthDay;
      user.job = model.job;
      user.Email = model.Email;
      user.aboutMe = model.aboutMe;
      if (model.Profilepic != null)
      {
        if (model.Profilepic.ContentLength > (4 * 1024 * 1024))
        {
          ModelState.AddModelError("CustomError", "Image can not be lager than 4MB.");
          return View();
        }
        if (!(model.Profilepic.ContentType == "image/jpeg" || model.Profilepic.ContentType == "image/gif"))
        {
          ModelState.AddModelError("CustomError", "Image must be in jpeg or gif format.");
        }

        byte[] data = new byte[model.Profilepic.ContentLength];
        model.Profilepic.InputStream.Read(data, 0, model.Profilepic.ContentLength);
      }
      
      var result = await UserManager.UpdateAsync(user);
      if (result.Succeeded)
      {
        message = ManageMessageId.UpdateProfileSuccess;
      }
      else
      {
        message = ManageMessageId.Error;
      }
      var context = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
      context.SaveChanges();

      
      return RedirectToAction("Index", new { Message = message });
    }


    //ROLES
    [HttpGet]
    //[Authorize(Roles = "Admin, SuperAdmin")]
    public ActionResult Roles()
    {
      //prepopulat roles for the view dropdown
      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();
      var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(),Text = rr.Name}).ToList();
      ViewBag.Roles = list;

  
      return View();
    }
    
    //Post in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin,SuperAdmin")]
    public ActionResult RoleAddToUser(string UserName, string RoleName)
    {
      var user = UserManager.FindByName(UserName);
      UserManager.AddToRole(user.Id,RoleName);

      ViewBag.ResultMessage = "Rol succesvol toegevoegd aan de gebruiker!";

      //prepopulat roles for the view dropdown
      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();
      var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();
      ViewBag.Roles = list;


      
      return View("Roles");
    }

    //POST: in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin,SuperAdmin")]
    public ActionResult GetRoles(string UserName)
    {
      if (!string.IsNullOrWhiteSpace(UserName))
      {
        var user = UserManager.FindByName(UserName);
        ViewBag.RolesForThisUser = UserManager.GetRoles(user.Id);

        // prepopulat roles for the view dropdown
        var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
        var roles = roleManager.Roles.ToList();
        var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();

      

        ViewBag.Roles = list;
      }
      
      return View("Roles");
    }
    //POST: in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    //[Authorize(Roles = "Admin,SuperAdmin")]
    public ActionResult DeleteRoleForUser(string UserName, string RoleName)
    {
      var user = UserManager.FindByName(UserName);

      if (UserManager.IsInRole(user.Id, RoleName))
      {
        UserManager.RemoveFromRole(user.Id, RoleName);
        ViewBag.ResultMessage = "Rol verwijdert van deze gebruiker!";
      }
      else
      {
        ViewBag.ResultMessage = "Deze gebruiker heeft de rol niet!";
      }

      // prepopulat roles for the view dropdown
      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();
      var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();
      ViewBag.Roles = list;



    
      return View("Roles");
    }

    //
    // POST: /Manage/RemoveLogin
    [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> RemoveLogin(string loginProvider, string providerKey)
        {
            ManageMessageId? message;
            var result = await UserManager.RemoveLoginAsync(User.Identity.GetUserId(), new UserLoginInfo(loginProvider, providerKey));
            if (result.Succeeded)
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                if (user != null)
                {
                    await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                }
                message = ManageMessageId.RemoveLoginSuccess;
            }
            else
            {
                message = ManageMessageId.Error;
            }
      
      return RedirectToAction("ManageLogins", new { Message = message });
        }
    //GET: /Manage/AddBudget()
    public ActionResult AddBudget()
    {
      return View();
    }
    /* //met de uofManager
    //POST: /Manage/addBudget
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> AddBudget(HttpPostedFileBase upload)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager begrotingsmanager = new BegrotingsManager(uowMgr);

      if (ModelState.IsValid)
      {

        if (upload != null && upload.ContentLength > 0)
        {
          // ExcelDataReader works with the binary Excel file, so it needs a FileStream
          // to get started. This is how we avoid dependencies on ACE or Interop:
          Stream stream = upload.InputStream;

          // We return the interface, so that
          IExcelDataReader reader = null;


          if (upload.FileName.EndsWith(".xls"))
          {
            reader = ExcelReaderFactory.CreateBinaryReader(stream);
          }
          else if (upload.FileName.EndsWith(".xlsx"))
          {
            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
          }
          else
          {
            ModelState.AddModelError("File", "This file format is not supported");
            return View();
          }

          reader.IsFirstRowAsColumnNames = true;

          DataSet result = reader.AsDataSet();
          reader.Close();

          begrotingsmanager.addBudget(result);
          ModelState.AddModelError("File", "Is aan het uploaden");
          //return View();

          return RedirectToAction("Index", "Manage");
        }
        else
        {
          ModelState.AddModelError("File", "Please Upload Your file");
        }
      }
      uowMgr.Save();
      return View();



    }
    */

    //POST: /Manage/addBudget
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> AddBudget(HttpPostedFileBase upload)
    {
      //UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager begrotingsmanager = new BegrotingsManager();

      if (ModelState.IsValid)
      {

        if (upload != null && upload.ContentLength > 0)
        {
          // ExcelDataReader works with the binary Excel file, so it needs a FileStream
          // to get started. This is how we avoid dependencies on ACE or Interop:
          Stream stream = upload.InputStream;

          // We return the interface, so that
          IExcelDataReader reader = null;


          if (upload.FileName.EndsWith(".xls"))
          {
            reader = ExcelReaderFactory.CreateBinaryReader(stream);
          }
          else if (upload.FileName.EndsWith(".xlsx"))
          {
            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
          }
          else
          {
            ModelState.AddModelError("File", "This file format is not supported");
            return View();
          }

          reader.IsFirstRowAsColumnNames = true;

          DataSet result = reader.AsDataSet();
          reader.Close();

          begrotingsmanager.addBudget(result);
          ModelState.AddModelError("File", "Is aan het uploaden");
          //return View();

          return RedirectToAction("Index", "Manage");
        }
        else
        {
          ModelState.AddModelError("File", "Please Upload Your file");
        }
      }
      //uowMgr.Save();
      return View();



    }



    //GET: /Manage/AddPostcodes()
    public ActionResult AddPostcodes()
    {
      return View();
    }

    //POST: /Manage/AddPostcodes
    [HttpPost]
    [ValidateAntiForgeryToken]

    //voor het probleem met dubbele postalheads, doe uowMgr weg bij begrotingsmanager als parameter
    public async Task<ActionResult> AddPostcodes(HttpPostedFileBase upload)
    {
      //UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager begrotingsmanager = new BegrotingsManager();
      if (ModelState.IsValid)
      {

        if (upload != null && upload.ContentLength > 0)
        {
          // ExcelDataReader works with the binary Excel file, so it needs a FileStream
          // to get started. This is how we avoid dependencies on ACE or Interop:
          Stream stream = upload.InputStream;

          // We return the interface, so that
          IExcelDataReader reader = null;


          if (upload.FileName.EndsWith(".xls"))
          {
            reader = ExcelReaderFactory.CreateBinaryReader(stream);
          }
          else if (upload.FileName.EndsWith(".xlsx"))
          {
            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
          }
          else
          {
            ModelState.AddModelError("File", "This file format is not supported");
            return View();
          }

          reader.IsFirstRowAsColumnNames = true;

          DataSet result = reader.AsDataSet();
          reader.Close();

          begrotingsmanager.addPostcodes(result);
          ModelState.AddModelError("File", "Is aan het uploaden");
          //return View();
          //uowMgr.Save();
          return RedirectToAction("Index", "Manage");
        }
        else
        {
          ModelState.AddModelError("File", "Please Upload Your file");
        }
      }
      return View();



    }





    //GET: /Manage/AddTaxes()
    public ActionResult AddTaxes()
    {
      return View();
    }

    //POST: /Manage/AddPostcodes
    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<ActionResult> AddTaxes(HttpPostedFileBase upload)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager begrotingsmanager = new BegrotingsManager(uowMgr);
      if (ModelState.IsValid)
      {

        if (upload != null && upload.ContentLength > 0)
        {
          // ExcelDataReader works with the binary Excel file, so it needs a FileStream
          // to get started. This is how we avoid dependencies on ACE or Interop:
          Stream stream = upload.InputStream;

          // We return the interface, so that
          IExcelDataReader reader = null;


          if (upload.FileName.EndsWith(".xls"))
          {
            reader = ExcelReaderFactory.CreateBinaryReader(stream);
          }
          else if (upload.FileName.EndsWith(".xlsx"))
          {
            reader = ExcelReaderFactory.CreateOpenXmlReader(stream);
          }
          else
          {
            ModelState.AddModelError("File", "This file format is not supported");
            return View();
          }

          reader.IsFirstRowAsColumnNames = true;

          DataSet result = reader.AsDataSet();
          reader.Close();

          begrotingsmanager.addTaxes(result);
          ModelState.AddModelError("File", "Is aan het uploaden");
          //return View();

          return RedirectToAction("Index", "Manage");
        }
        else
        {
          ModelState.AddModelError("File", "Please Upload Your file");
        }
      }
      uowMgr.Save();
      return View();



    }





    //
    // GET: /Manage/AddPhoneNumber
    public ActionResult AddPhoneNumber()
        {
            return View();
        }

        //
        // POST: /Manage/AddPhoneNumber
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> AddPhoneNumber(AddPhoneNumberViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            // Generate the token and send it
            var code = await UserManager.GenerateChangePhoneNumberTokenAsync(User.Identity.GetUserId(), model.Number);
            if (UserManager.SmsService != null)
            {
                var message = new IdentityMessage
                {
                    Destination = model.Number,
                    Body = "Your security code is: " + code
                };
                await UserManager.SmsService.SendAsync(message);
            }
            return RedirectToAction("VerifyPhoneNumber", new { PhoneNumber = model.Number });
        }

        //
        // POST: /Manage/EnableTwoFactorAuthentication
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> EnableTwoFactorAuthentication()
        {
            await UserManager.SetTwoFactorEnabledAsync(User.Identity.GetUserId(), true);
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user != null)
            {
                await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
            }
      return RedirectToAction("Index", "Manage");
    }

        //
        // POST: /Manage/DisableTwoFactorAuthentication
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> DisableTwoFactorAuthentication()
        {
            await UserManager.SetTwoFactorEnabledAsync(User.Identity.GetUserId(), false);
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user != null)
            {
                await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
            }
      return RedirectToAction("Index", "Manage");
    }

        //
        // GET: /Manage/VerifyPhoneNumber
        public async Task<ActionResult> VerifyPhoneNumber(string phoneNumber)
        {
            var code = await UserManager.GenerateChangePhoneNumberTokenAsync(User.Identity.GetUserId(), phoneNumber);
            // Send an SMS through the SMS provider to verify the phone number
            return phoneNumber == null ? View("Error") : View(new VerifyPhoneNumberViewModel { PhoneNumber = phoneNumber });
        }

        //
        // POST: /Manage/VerifyPhoneNumber
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> VerifyPhoneNumber(VerifyPhoneNumberViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = await UserManager.ChangePhoneNumberAsync(User.Identity.GetUserId(), model.PhoneNumber, model.Code);
            if (result.Succeeded)
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                if (user != null)
                {
                    await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                }
                return RedirectToAction("Index", new { Message = ManageMessageId.AddPhoneSuccess });
            }
            // If we got this far, something failed, redisplay form
            ModelState.AddModelError("", "Failed to verify phone");
            return View(model);
        }

        //
        // GET: /Manage/RemovePhoneNumber
        public async Task<ActionResult> RemovePhoneNumber()
        {
            var result = await UserManager.SetPhoneNumberAsync(User.Identity.GetUserId(), null);
            if (!result.Succeeded)
            {
                return RedirectToAction("Index", new { Message = ManageMessageId.Error });
            }
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user != null)
            {
                await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
            }
            return RedirectToAction("Index", new { Message = ManageMessageId.RemovePhoneSuccess });
        }

        //
        // GET: /Manage/ChangePassword
        public ActionResult ChangePassword()
        {
            return View();
        }

        //
        // POST: /Manage/ChangePassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> ChangePassword(ChangePasswordViewModel model)
        {
            if (!ModelState.IsValid)
            {
                return View(model);
            }
            var result = await UserManager.ChangePasswordAsync(User.Identity.GetUserId(), model.OldPassword, model.NewPassword);
            if (result.Succeeded)
            {
                var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                if (user != null)
                {
                    await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                }
                return RedirectToAction("Index", new { Message = ManageMessageId.ChangePasswordSuccess });
            }
            AddErrors(result);
            return View(model);
        }

        //
        // GET: /Manage/SetPassword
        public ActionResult SetPassword()
        {
            return View();
        }

        //
        // POST: /Manage/SetPassword
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<ActionResult> SetPassword(SetPasswordViewModel model)
        {
            if (ModelState.IsValid)
            {
                var result = await UserManager.AddPasswordAsync(User.Identity.GetUserId(), model.NewPassword);
                if (result.Succeeded)
                {
                    var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
                    if (user != null)
                    {
                        await SignInManager.SignInAsync(user, isPersistent: false, rememberBrowser: false);
                    }
                    return RedirectToAction("Index", new { Message = ManageMessageId.SetPasswordSuccess });
                }
                AddErrors(result);
            }

            // If we got this far, something failed, redisplay form
            return View(model);
        }

        //
        // GET: /Manage/ManageLogins
        public async Task<ActionResult> ManageLogins(ManageMessageId? message)
        {
            ViewBag.StatusMessage =
                message == ManageMessageId.RemoveLoginSuccess ? "The external login was removed."
                : message == ManageMessageId.Error ? "An error has occurred."
                : "";
            var user = await UserManager.FindByIdAsync(User.Identity.GetUserId());
            if (user == null)
            {
                return View("Error");
            }
            var userLogins = await UserManager.GetLoginsAsync(User.Identity.GetUserId());
            var otherLogins = AuthenticationManager.GetExternalAuthenticationTypes().Where(auth => userLogins.All(ul => auth.AuthenticationType != ul.LoginProvider)).ToList();
            ViewBag.ShowRemoveButton = user.PasswordHash != null || userLogins.Count > 1;
            return View(new ManageLoginsViewModel
            {
                CurrentLogins = userLogins,
                OtherLogins = otherLogins
            });
        }

        //
        // POST: /Manage/LinkLogin
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult LinkLogin(string provider)
        {
            // Request a redirect to the external login provider to link a login for the current user
            return new AccountController.ChallengeResult(provider, Url.Action("LinkLoginCallback", "Manage"), User.Identity.GetUserId());
        }

        //
        // GET: /Manage/LinkLoginCallback
        public async Task<ActionResult> LinkLoginCallback()
        {
            var loginInfo = await AuthenticationManager.GetExternalLoginInfoAsync(XsrfKey, User.Identity.GetUserId());
            if (loginInfo == null)
            {
                return RedirectToAction("ManageLogins", new { Message = ManageMessageId.Error });
            }
            var result = await UserManager.AddLoginAsync(User.Identity.GetUserId(), loginInfo.Login);
            return result.Succeeded ? RedirectToAction("ManageLogins") : RedirectToAction("ManageLogins", new { Message = ManageMessageId.Error });
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing && _userManager != null)
            {
                _userManager.Dispose();
                _userManager = null;
            }

            base.Dispose(disposing);
        }




    #region Helpers
    // Used for XSRF protection when adding external logins
    private const string XsrfKey = "XsrfId";

        private IAuthenticationManager AuthenticationManager
        {
            get
            {
                return HttpContext.GetOwinContext().Authentication;
            }
        }

        private void AddErrors(IdentityResult result)
        {
            foreach (var error in result.Errors)
            {
                ModelState.AddModelError("", error);
            }
        }

        private bool HasPassword()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PasswordHash != null;
            }
            return false;
        }

        private bool HasPhoneNumber()
        {
            var user = UserManager.FindById(User.Identity.GetUserId());
            if (user != null)
            {
                return user.PhoneNumber != null;
            }
            return false;
        }

        public enum ManageMessageId
        {
            AddPhoneSuccess,
            ChangePasswordSuccess,
            SetTwoFactorSuccess,
            SetPasswordSuccess,
            RemoveLoginSuccess,
            RemovePhoneSuccess,
            UpdateProfileSuccess,
            Error
        }



#endregion
    }
}