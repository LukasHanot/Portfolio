﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BL;
using IntegratieProject.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.AspNet.Identity.Owin;
using System.Threading.Tasks;
using System.Web.Security;
using Domain.Location;
using Domain.Project;
using Domain.Budget;

namespace IntegratieProject.Controllers
{
  public class ModerationController : Controller
  {
    
    private ApplicationUserManager _userManager;

    public ModerationController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
    {
      UserManager = userManager;

    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }

    public ModerationController()
    {

    }

    public ActionResult SummaryAllPlaces()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      LocatieManager locatiemanager = new LocatieManager(uowMgr);
      BegrotingsManager begrotingsmanager = new BegrotingsManager(uowMgr);

      IEnumerable<BudgetLine> allBudgets = begrotingsmanager.getBudgetLines();
      IEnumerable<Domain.Location.PostalHead> postalHeads = locatiemanager.getPostalHeadsWithBudget(allBudgets);

      return View(postalHeads);
    }

    //GET SummaryUsersMod pagina
    [HttpGet]
    //    [Authorize(Roles = "Admin, SuperAdmin")]
    public ActionResult ViewUsersMod()
    {
      //Laad rollen in ViewBag
      IEnumerable<ApplicationUser> users = UserManager.Users.AsEnumerable();
      return View(users);
    }

    //Post in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    //   [Authorize(Roles = "Admin,SuperAdmin")]
    public ActionResult RoleAddToUser(string UserName, string RoleName)
    {
      var user = UserManager.FindByName(UserName);
      UserManager.AddToRole(user.Id, RoleName);

      ViewBag.ResultMessage = "Rol succesvol toegevoegd aan de gebruiker!";

      //prepopulat roles for the view dropdown
      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();
      var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();
      ViewBag.Roles = list;
      return View("Roles");
    }

    //POST: in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    // [Authorize(Roles = "Admin,SuperAdmin")]
    public void GetRoles(string UserName)
    {
      if (!string.IsNullOrWhiteSpace(UserName))
      {
        var user = UserManager.FindByName(UserName);
        ViewBag.RolesForThisUser = UserManager.GetRoles(user.Id);

        // prepopulat roles for the view dropdown
        var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
        var roles = roleManager.Roles.ToList();
        var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();

        ViewBag.Roles = list;
      }
    }


    //POST: in onderdeel view Roles
    [HttpPost]
    [ValidateAntiForgeryToken]
    //   [Authorize(Roles = "Admin,SuperAdmin")]
    public ActionResult DeleteRoleForUser(string UserName, string RoleName)
    {
      var user = UserManager.FindByName(UserName);

      if (UserManager.IsInRole(user.Id, RoleName))
      {
        UserManager.RemoveFromRole(user.Id, RoleName);
        ViewBag.ResultMessage = "Rol verwijdert van deze gebruiker!";
      }
      else
      {
        ViewBag.ResultMessage = "Deze gebruiker heeft de rol niet!";
      }

      // prepopulat roles for the view dropdown
      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();
      var list = roles.Select(rr => new SelectListItem { Value = rr.Name.ToString(), Text = rr.Name }).ToList();
      ViewBag.Roles = list;

      return View("Roles");
    }

    [HttpGet]
    //    [Authorize(Roles = "SuperAdmin")]
    public ActionResult SummarySuperAdmins()
    {
      //Laad alle Superadmins en toon deze voor het beheer
      List<ApplicationUser> users = UserManager.Users.ToList();
      List<ApplicationUser> superadmins = new List<ApplicationUser>();

      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>());
      var roles = roleManager.Roles.ToList();

      foreach (ApplicationUser user in users)
      {
        if (UserManager.IsInRole(user.Id, "SuperAdmin"))
        {
          superadmins.Add(user);
        }
      }
        return View(superadmins.AsEnumerable());
      }




    [HttpGet]
    //    [Authorize(Roles = "SuperAdmin")]
    public ActionResult EditSuperAdmin(string id)
    {
      var user = UserManager.FindById(id);
      return View(user);
    }

    [HttpPost]
    //    [Authorize(Roles = "SuperAdmin")]
    public ActionResult EditSuperAdmin(IndexViewModel model)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();

      if (ModelState.IsValid)
      {
        var user = UserManager.FindById(User.Identity.GetUserId());
        user.postalcode = model.postalcode;
        user.birthday = model.BirthDay;
        user.job = model.job;
        user.Email = model.Email;
        user.aboutMe = model.aboutMe;
      }

      var context = HttpContext.GetOwinContext().Get<ApplicationDbContext>();
      context.SaveChanges();
      uowMgr.Save();
      return RedirectToAction("Index");

    }
  }
}