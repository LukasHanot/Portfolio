﻿using BL;
using Domain.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Domain.Project;
using System.Dynamic;

namespace IntegratieProject.Controllers
{
  public class PlaceController : Controller
  {
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;

    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }

    // GET: Place
    public ActionResult Index()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      LocatieManager mgrLocatie = new LocatieManager(uowMgr);

      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;
      PostalHead postalhead = mgrLocatie.getPostalHeadByUserPostalCode(userPostalcode);
      //ViewBag.Places = places;
      return View();

    }


    // GET: Place/Details/5
    /*public ActionResult GemeenteDetails(int postalCode)
    {
      //Place place = mgrLocatie.getPlaceByPostalCode(postalCode);
      //return View(place);
      return View();
    }*/
    // GET: Place
    public ActionResult GemeenteSummary()
    {

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      LocatieManager mgrLocatie = new LocatieManager(uowMgr);

      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;
      Place place = mgrLocatie.getPlaceByPostalCode(userPostalcode);
      IEnumerable<Project> projects = mgrProject.getProjectsViaPostal(userPostalcode);
      BigPlaceProjectModel bigplaceProjectModel = new BigPlaceProjectModel();
      bigplaceProjectModel.place = place;
      bigplaceProjectModel.projects = projects;
      return View(bigplaceProjectModel);

    }
    
    /*public ActionResult GemeenteSummary (int postalCode)
    {
      UnitOfWorkManager uowmgr = new UnitOfWorkManager();
      LocatieManager mgrLocatie = new LocatieManager(uowmgr);
      ProjectManager mgrProject = new ProjectManager(uowmgr);
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;
      //PostalHead postalhead = mgrLocatie.getPostalHeadByUserPostalCode(userPostalcode);
      Place place = mgrLocatie.getPlaceByPostalCode(userPostalcode);
      IEnumerable<Project> projects = mgrProject.getProjectsViaPostal(userPostalcode);
      BigPlaceProjectModel bigplaceProjectModel = new BigPlaceProjectModel();
      bigplaceProjectModel.place = place;
      bigplaceProjectModel.projects = projects;
      return View(bigplaceProjectModel);

    }*/  

    /*[HttpPost]
    public ActionResult GemeenteSummary(Place place)
    {
      Place place = mgrLocatie.addPlace(postalCode);
    }*/

    // GET: Project
    /*public ActionResult _PartialProjectsForPlace()
    {
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;
      BigPlaceProjectModel bigplaceprojectmodel = new BigPlaceProjectModel();
      IEnumerable<Project> projects = mgrProject.getProjectsViaPostal(userPostalcode);
      bigplaceprojectmodel.projects = projects;
      return PartialView(bigplaceprojectmodel);
    }*/

    /*public ActionResult PlaceIndex()
    {
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      int userPostalcode = currentUser.postalcode;

      Place place = mgrLocatie.getPlaceByPostalCode(userPostalcode);
      IEnumerable<Project> projects = mgrProject.getProjectsViaPostal(currentUser.postalcode);
      dynamic mymodel = new ExpandoObject();
      mymodel.PlaceInfo = place;
      mymodel.ProjectInfo = projects;
      return View(mymodel);
    }*/


    /*public ActionResult CreateGemeente()
    {
      return View();
    }*/

    /* [HttpPost]
     public ActionResult CreateGemeente(PostalCode postalcode)
     {
       if (ModelState.IsValid)
       {
         postalcode = mgrLocatie.addPostalCode(postalcode.nr, postalcode.postalCode, postalcode.name, postalcode.cluster, postalcode.postalHead);
         return RedirectToAction("Index");
       }
       return View();
     }*/

    // GET: Place/Create
    public ActionResult Create()
    {
      return View();
    }

    // POST: Place/Create
    [HttpPost]
    public ActionResult Create(FormCollection collection)
    {
      try
      {
        // TODO: Add insert logic here

        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }








    /* public ActionResult EditGemeente(int id)
     {
       PostalCode postalcode = mgrLocatie.getPostalCode(id);
       return View(postalcode);
     }

     [HttpPost]
     public ActionResult EditGemeente(int id, PostalCode postalcode)
     {
       try
       {
         // TODO: Add update logic here
         mgrLocatie.changePostalCode(postalcode);
         return RedirectToAction("EditGemeente");
       }
       catch
       {
         return View();
       }
     }*/


    // GET: Place/Edit/5
    public ActionResult Edit(int id)
    {
      return View();
    }

    public ActionResult EditPlace(int postalCode)
    {

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      LocatieManager mgrLocatie = new LocatieManager(uowMgr);
      Place place = mgrLocatie.getPlaceByPostalCode(postalCode);
      return View(place);
    }

    [HttpPost]
    public ActionResult EditPlace(Place place)
    {

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      LocatieManager mgrLocatie = new LocatieManager(uowMgr);
      try
      {
        mgrLocatie.changePlace(place);
        uowMgr.Save();
        return RedirectToAction("GemeenteSummary", new { postalCode = place.postalCode });
        
      }
      catch
      {
        return View();
      }
      
    }

    // POST: Place/Edit/5
    [HttpPost]
    public ActionResult Edit(int id, FormCollection collection)
    {
      try
      {
        // TODO: Add update logic here

        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }

    // GET: Place/Delete/5
    public ActionResult Delete(int id)
    {
      return View();
    }

    // POST: Place/Delete/5
    [HttpPost]
    public ActionResult Delete(int id, FormCollection collection)
    {
      try
      {
        // TODO: Add delete logic here

        return RedirectToAction("Index");
      }
      catch
      {
        return View();
      }
    }
  }
}
