﻿using System.Collections.Generic;
using System.Web;
using System.Web.Mvc;
using BL;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Domain.Project;

namespace IntegratieProject.Controllers.ProjectControllers
{
  [Authorize]
  public class ProjectController : Controller
  {
    
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;

    public ProjectController()
    {

    }

    public ProjectController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
    {
      UserManager = userManager;
      SignInManager = signInManager;

    }

    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }

    // GET: Project
    public ActionResult SummaryProjects()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      IEnumerable<Project> projects = mgrProject.getProjectsViaPostal(currentUser.postalcode);
      return View(projects);
    }

  

    // GET: Project/CreateProject/
    public ActionResult CreateProject()
    {
      return View();
    }

    // POST: Project/CreateProject
    [HttpPost]
    public ActionResult CreateProject(Project project)
    {
      if (ModelState.IsValid)
      {
       // project = mgrProject.addProject(project.startDate, project.endDate, project.text, project.type, project.status, project.minAmount, project.maxAmount, project.amount, project.postalCode);
        return RedirectToAction("SummaryProjects");
      }
      return View();
    }

    // GET: Project/EditProject/5
    public ActionResult EditProject(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      Project project = mgrProject.getProject(id);
      return View(project);
    }

    // POST: Project/EditProject/5
    [HttpPost]
    public ActionResult EditProject(int id, Project project)
    {
      if (ModelState.IsValid)
      {
        UnitOfWorkManager uowMgr = new UnitOfWorkManager();
        ProjectManager mgrProject = new ProjectManager(uowMgr);
        // TODO: Add update logic here
        mgrProject.changeProject(project);
        uowMgr.Save();
        return RedirectToAction("SummaryProjects");
      }
      return View();
    }
    
    // GET: Project/DeleteProject/5
    public ActionResult DeleteProject(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      Project project = mgrProject.getProject(id);
      return View(project);
    }

    // POST: Project/DeleteProject/5
    [HttpPost]
    public ActionResult DeleteProject(int id, FormCollection collection)
    {
      if (ModelState.IsValid)
      {
        UnitOfWorkManager uowMgr = new UnitOfWorkManager();
        ProjectManager mgrProject = new ProjectManager(uowMgr);
        // TODO: Add delete logic here
        mgrProject.removeProject(id);
        uowMgr.Save();
        return RedirectToAction("SummaryProjects");
      }
      return View();
    }

    // GET: Project/SummaryPropositions/Reactions
    public ActionResult SummaryCommentsMod(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      IEnumerable<Comment> comments = mgrProject.getAllCommentsByPropositionId(id);
      return View(comments);
    }



  }
}
