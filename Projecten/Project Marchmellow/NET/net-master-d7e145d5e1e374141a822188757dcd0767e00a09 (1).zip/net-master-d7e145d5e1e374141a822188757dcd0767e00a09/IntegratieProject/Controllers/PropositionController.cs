﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using BL;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.Owin;
using Domain.Project;

namespace IntegratieProject.Controllers
{
    public class PropositionController : Controller
    {
    
    private ApplicationSignInManager _signInManager;
    private ApplicationUserManager _userManager;

    public PropositionController()
    {

    }

    public PropositionController(ApplicationUserManager userManager, ApplicationSignInManager signInManager)
    {
      UserManager = userManager;
      SignInManager = signInManager;

    }

    public ApplicationSignInManager SignInManager
    {
      get
      {
        return _signInManager ?? HttpContext.GetOwinContext().Get<ApplicationSignInManager>();
      }
      private set
      {
        _signInManager = value;
      }
    }

    public ApplicationUserManager UserManager
    {
      get
      {
        return _userManager ?? HttpContext.GetOwinContext().GetUserManager<ApplicationUserManager>();
      }
      private set
      {
        _userManager = value;
      }
    }

    // GET: Project/SummaryPropositions
    public ActionResult SummaryPropositionsAdmin()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      IEnumerable<Proposition> propositions = mgrProject.getAllPropositions();
      return View(propositions);
    }

    // GET: Proposition/DeleteProposition/5
    public ActionResult DeleteProposition(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      Proposition proposition = mgrProject.getPropositionViaId(id);
      return View(proposition);
    }

    // POST: Project/DeleteProposition/5
    [HttpPost]
    public ActionResult DeleteProposition(int id, FormCollection collection)
    {
      if (ModelState.IsValid)
      {
        UnitOfWorkManager uowMgr = new UnitOfWorkManager();
        ProjectManager mgrProject = new ProjectManager(uowMgr);
        // TODO: Add delete logic here
        mgrProject.removeProposition(id);
        uowMgr.Save();
        return RedirectToAction("SummaryPropositions");
      }
      return View();
    }

    // GET: Project/SummaryPropositions
    public ActionResult SummaryPropositionsUser()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);
      IEnumerable<Proposition> propositions = mgrProject.getPropositionsForUser(userId);
      return View(propositions);
    }
    
    // GET: Project/SummaryPropositions
    public ActionResult SummaryPropositionsPlaceUser()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);

      IEnumerable<Proposition> propositions = mgrProject.getPropositionsForUserPlace(currentUser.postalcode);
      return View(propositions);
    }


    [HttpGet]
    [Authorize]
    public ActionResult AddProposition(int id)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      Project project = mgrProject.getProject(id);
      List<ProjectDetail> details = project.projectDetails.Where(d => d.canModify.Equals(true)).ToList();
      ViewBag.details = details;
      ViewBag.year = project.year;
      ViewBag.postal = project.postalCode;
      ViewBag.amount = project.amount ;


      return View();
    }


    [HttpPost]
    public ActionResult AddProposition(int id, Proposition proposition, List<Double> first_value)
    {
      var userId = User.Identity.GetUserId();
      var currentUser = UserManager.FindById(userId);

      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      ProjectManager mgrProject = new ProjectManager(uowMgr);
      Project project = mgrProject.getProject(id);


      Proposition p = proposition;
      p.date = DateTime.Now;
      p.userId = userId;
      p.project = project;
      mgrProject.addProposition(p,first_value);

      uowMgr.Save();

      return RedirectToAction("Index", "Manage");
    }
   

  }
}
