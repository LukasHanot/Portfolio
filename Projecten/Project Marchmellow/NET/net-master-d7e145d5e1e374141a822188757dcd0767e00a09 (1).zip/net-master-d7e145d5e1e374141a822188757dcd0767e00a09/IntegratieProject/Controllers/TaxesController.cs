﻿using BL;
using Domain.Budget;
using Domain.Location;
using IntegratieProject.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Mvc;

namespace IntegratieProject.Controllers
{
    public class TaxesController : Controller
    {
    UnitOfWorkManager uowMgr = new UnitOfWorkManager();

   

    public ActionResult LocalTaxOverview(double Salary  )
    {

     BegrotingsManager mgr = new BegrotingsManager(uowMgr);
     LocatieManager Locmgr = new LocatieManager(uowMgr);
    var model = new TaxViewModel();
     
      // get huidige Gemeente
      int postalcode = 2000;
  


      //Get lijst van categorieenA
      model.categoriesA = mgr.getCategoryA();

      //get gemeenteBelastingpercentage voor eigen gemeente

      double? tax = Locmgr.getCommunTax(postalcode);
      double? belasting = Salary * 0.1307 * tax;
      
      double percCat = 0.1;
      double taxCategorie = (double)belasting * percCat;

      model.taxcat = taxCategorie;
      model.belasting = (double)belasting;
      model.salary = Salary;
      model.postcode1 = postalcode;
      return View(model);
    }

   /* [ChildActionOnly]
    public PartialViewResult CompareTaxView(int postalcode = 2000, double Salary)
    {
     LocatieManager Locmgr = new LocatieManager(uowMgr);
     BegrotingsManager mgr = new BegrotingsManager(uowMgr);

      var model = new TaxViewModel();


      model.categoriesA = mgr.getCategoryA();
      double? tax = Locmgr.getCommunTax(postalcode);
      double? belasting = Salary * 0.1307 * tax;
      double taxCategorie;
      taxCategorie = (double)belasting * 0.1;

    


      model.taxcat = taxCategorie;
      model.belasting = (double)belasting;
      model.salary = Salary;
      
      return PartialView(model);
    }*/
    }
}

