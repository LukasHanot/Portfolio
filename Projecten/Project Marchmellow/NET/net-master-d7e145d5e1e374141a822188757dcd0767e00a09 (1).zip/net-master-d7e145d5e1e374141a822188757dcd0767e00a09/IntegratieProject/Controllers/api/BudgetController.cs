﻿using BL;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

namespace IntegratieProject.Controllers.api
{
    public class BudgetController : ApiController
    {
    

    [HttpGet]
    [Route("api/Budget/getAll")]
    public IHttpActionResult getBudgetData()
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager mgr = new BegrotingsManager(uowMgr);
      string jsonString = JsonConvert.SerializeObject(mgr.getBudget());
      JArray json = JArray.Parse(jsonString);

   
      return Ok(json);
    }

    [HttpGet]
    [Route("api/Budget/{year}")]
    public IHttpActionResult getBudgetDataYear(int year)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager mgr = new BegrotingsManager(uowMgr);
      string jsonString = JsonConvert.SerializeObject(mgr.getBudgetYear(year));
      JArray json = JArray.Parse(jsonString);


      return Ok(json);
    }

    [HttpGet]
    [Route("api/Budget/postcode/{postal}")]
    public IHttpActionResult getBudgetPostalCodes(int postal)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager mgr = new BegrotingsManager(uowMgr);
      string jsonString = JsonConvert.SerializeObject(mgr.getBudgetPostal(postal));
      JArray json = JArray.Parse(jsonString);


      return Ok(json);
    }

    [HttpGet]
    [Route("api/Budget/{year}/{postal}")]
    public IHttpActionResult getBudgetYearPostalCodes(int year,int postal)
    {
      UnitOfWorkManager uowMgr = new UnitOfWorkManager();
      BegrotingsManager mgr = new BegrotingsManager(uowMgr);
      string jsonString = JsonConvert.SerializeObject(mgr.getBudgetYearPostal(year,postal));
      JArray json = JArray.Parse(jsonString);


      return Ok(json);
    }

        [HttpGet]
        [Route("api/{postal}")]
        public IHttpActionResult getPostal(int postal)
        {
            UnitOfWorkManager uowMgr = new UnitOfWorkManager();
            BegrotingsManager mgr = new BegrotingsManager(uowMgr);
            string jsonString = JsonConvert.SerializeObject(mgr.getPostalhead(postal));
            JObject json = JObject.Parse(jsonString);


            return Ok(json);
        }
    }
}
