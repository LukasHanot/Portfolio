﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntegratieProject.Models
{
  public class BudgetViewModels
  {
    public class BudgetViewModel
    {
      public int year { get; set; }
      public DateTime startDate { get; set; }
      public DateTime endDate { get; set; }
      public string text { get; set; }
      public Domain.Project.TypeProject type { get; set; }
      public Domain.Project.Status status { get; set; }
      public int postalcode { get; set; }
      public double amount { get; set; }
      // de lijst van categorieen en extra's
      public List<bool> canModify { get; set; }
      public List<Double> minAmount { get; set; }
      public List<Double> maxAmount { get; set; }


    }

  }
}