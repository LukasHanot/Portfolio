﻿using Domain.Location;
using Domain.Project;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntegratieProject.Models
{
  public class IndexCommunModel
  {
    public Place detailscommun { get; set; } 
    public List<Project> projects { get; set; }
    public IEnumerable<PostalCode> postalcodes { get; set; }
  }
}