﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntegratieProject.Models
{
  public enum Job
  {
    Student=1, Arbeider=2, Bediende=3, Zelfstandige=4, Gepensioneerd=5, Anders=6
  }
}