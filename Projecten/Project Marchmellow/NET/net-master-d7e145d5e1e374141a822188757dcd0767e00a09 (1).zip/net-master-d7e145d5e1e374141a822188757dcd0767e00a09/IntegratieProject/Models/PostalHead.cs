﻿using System;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;
using System.Web;

namespace IntegratieProject.Models
{
  public class PostalHead
    //haha
  {
    public int nr { get; set; }
    public int postalCode { get; set; }

    public String name { get; set; }

    public String province { get; set; }
  }

  public class MyContext : DbContext
  {
    public DbSet<PostalHead> postalHead { get; set; }
  }
}