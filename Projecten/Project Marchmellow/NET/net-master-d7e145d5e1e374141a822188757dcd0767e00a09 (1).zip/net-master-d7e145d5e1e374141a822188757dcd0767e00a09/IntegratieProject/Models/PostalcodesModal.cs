﻿using Domain.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace IntegratieProject.Models
{
  public class PostalcodesModal
  {
    public SelectList DropDownList { get; set; }
    public IEnumerable<PostalCode> postalcodes { get; set; }
  }
}