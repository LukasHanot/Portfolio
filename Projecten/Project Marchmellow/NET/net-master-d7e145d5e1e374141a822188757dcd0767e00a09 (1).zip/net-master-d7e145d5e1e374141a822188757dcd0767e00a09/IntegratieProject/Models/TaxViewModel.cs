﻿using Domain.Budget;
using Domain.Location;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace IntegratieProject.Models
{
  public class TaxViewModel
  {
    public IEnumerable<CategoryA> categoriesA { get; set; }
   // public List <double?> Tax { get; set; }
   public double taxcat { get; set; }
    public double belasting { get; set; }
    public double salary { get; set; }
      public int postcode1 { get; set; }
    public int postcode2 { get; set; }
  }
}