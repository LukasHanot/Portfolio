﻿using IntegratieProject.Models;
using Microsoft.AspNet.Identity;
using Microsoft.AspNet.Identity.EntityFramework;
using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(IntegratieProject.Startup))]
namespace IntegratieProject
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
            createRolesandUsers();
        }



    private void createRolesandUsers()
    {
      ApplicationDbContext context = new ApplicationDbContext();

      var roleManager = new RoleManager<IdentityRole>(new RoleStore<IdentityRole>(context));
      var UserManager = new UserManager<ApplicationUser>(new UserStore<ApplicationUser>(context));

      // creating Creating Manager role   
      if (!roleManager.RoleExists("Admin"))
      {
        var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
        role.Name = "Admin";
        roleManager.Create(role);

      }

      // creating Creating moderator role   
      if (!roleManager.RoleExists("Moderator"))
      {
        var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
        role.Name = "Moderator";
        roleManager.Create(role);

      }
      // creating Creating gebruiker role   
      if (!roleManager.RoleExists("Gebruiker"))
      {
        var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
        role.Name = "Gebruiker";
        roleManager.Create(role);

      }
      // In Startup iam creating first Admin Role and creating a default Admin User   
      if (!roleManager.RoleExists("SuperAdmin"))
      {

        // first we create Admin rolz  
        var role = new Microsoft.AspNet.Identity.EntityFramework.IdentityRole();
        role.Name = "SuperAdmin";
        roleManager.Create(role);
        context.SaveChanges();
        //Here we create a Admin super user who will maintain the website                 

        
      }


      var user = new ApplicationUser();
      user.UserName = "admin";
      user.Email = "admin@admin.com";
      user.postalcode = 2140;
      user.lastname = "admin";
      user.name = "admin";
      

      string userPWD = "@dmin1";

      var chkUser = UserManager.Create(user, userPWD);

      //Add default User to Role SuperAdmin  
      if (chkUser.Succeeded)
      {
        var result1 = UserManager.AddToRole(user.Id, "SuperAdmin");

      }


    }



  }
}
