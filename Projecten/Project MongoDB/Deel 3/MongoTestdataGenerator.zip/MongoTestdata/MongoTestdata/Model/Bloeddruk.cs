﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoTestdata.Model
{
    public class Bloeddruk
    {
        public int bovendruk { get; set; }
        public int onderdruk { get; set; }
    }
}
