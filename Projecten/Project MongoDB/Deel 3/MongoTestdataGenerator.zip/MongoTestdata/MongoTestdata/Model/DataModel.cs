﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoTestdata.Model
{
    public class DataModel
    {
        public int gebruikerid { get; set; }
        public int activiteit { get; set; }
        public string activiteitNaam { get; set; }
        public double gewicht { get; set; }
        public int lengte { get; set; }
        public DateTime starttijd { get; set; }
        public DateTime eindtijd { get; set; }
        public List<Metingen> metingen { get; set; }
        public GPS startgps { get; set; }
        public GPS eindgps { get; set; }
        public double calVerbrand { get; set; }

    }
}
