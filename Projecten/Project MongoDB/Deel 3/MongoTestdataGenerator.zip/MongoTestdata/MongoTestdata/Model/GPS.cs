﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoTestdata.Model
{
    public class GPS
    {
        public double longitude { get; set; }
        public double latitude { get; set; }
    }
}
