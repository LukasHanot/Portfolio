﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MongoTestdata.Model
{
    public class Metingen
    {
        public int meetingnummer { get; set; }
        //public int aantalseconden { get; set; }
        public Bloeddruk bloeddruk { get; set; }
        public double snelheid { get; set; }
        public int hartslag { get; set;  }
    }
}
