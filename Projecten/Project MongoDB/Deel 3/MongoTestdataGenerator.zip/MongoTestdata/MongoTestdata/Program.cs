﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace MongoTestdata
{
    class Program
    {

        static void Main(string[] args)
        {
            //variabelen
            int aantalGebruikers = 50;
            int aantalActiviteiten = 60;
            Random random = new Random();
            List<Model.DataModel> lijst = new List<Model.DataModel>();
            List<Model.Metingen> meting = new List<Model.Metingen>();
            /*MEMO
            Hartslag tussen 60 - 160
            Bloeddruk: bovendruk - onderdruk beide tussen 80 - 160 && onderdruk < bovendruk
            Snelheid: tussen 0 - 40 !! lopers gaan geen 40 km/u !!
            GPS: Long en Lat nauwkeurig tot 0.00000 (5 na de komma)
            verbruikteCal= 'calPerSecond' * duurtijd(sec) * (lengte(cm)/gewicht(kg))
            */

            Console.WriteLine("Start data generatie");

            //voor alle gebruikers
            for (int i =0; i < aantalGebruikers; i++)
            {
                double gewicht = random.NextDouble() *(120-50) + 50;
                int lengte = random.Next(150,200);
                //voor elke gebruiker 60 activiteiten aanmaken
                for (int x =0; x < aantalActiviteiten; x++)
                {
                    //Activiteit aanmaken
                    DateTime begintijd = new DateTime(2015, random.Next(1, 13), random.Next(1, 28), random.Next(1, 24), random.Next(1, 60), random.Next(1, 60));
                    int activiteit = random.Next(1, 9);
                    int secondenSindsStart = 0;
                    double calps = 0;
                    string activiteitNaam = "";
                    //Gps data aanmaken
                    double longtitudewaarde = random.NextDouble() * (100 - 1) + 1;
                    double latitudewaarde = random.NextDouble() * (100 - 1) + 1;
                    double longtitudewaarde2 = random.NextDouble() * (100 - 1) + 1;
                    double latitudewaarde2 = random.NextDouble() * (100 - 1) + 1;
                    longtitudewaarde = Math.Truncate(longtitudewaarde * 1000) / 1000;
                    longtitudewaarde2 = Math.Truncate(longtitudewaarde2 * 1000) / 1000;
                    latitudewaarde = Math.Truncate(latitudewaarde * 1000) / 1000;
                    latitudewaarde2 = Math.Truncate(latitudewaarde2 * 1000) / 1000;

                    Model.DataModel model = new Model.DataModel()
                    {
                        gebruikerid = i + 1,
                        gewicht = gewicht,
                        lengte = lengte,
                        activiteit = activiteit,
                        metingen = new List<Model.Metingen>(),
                        starttijd = begintijd,
                        startgps = new Model.GPS() { longitude = longtitudewaarde, latitude = latitudewaarde },
                        eindgps = new Model.GPS() { longitude = longtitudewaarde2, latitude = latitudewaarde2 }
                    };

                    int aantalMetingen = random.Next(970, 1031);
                    // voor alle activiteiten 1000 metingen maken
                    for (int z = 0; z < aantalMetingen; z++)
                    {
                        int minsnelheid = 0;
                        int maxsnelheid = 40;
                        int maxbovendruk = 160;
                        switch (activiteit)
                        {
                            case 1:
                                //walking
                                activiteitNaam = "walking";
                                minsnelheid = 2;
                                maxsnelheid = 7;
                                maxbovendruk = 100;
                                calps = 0.018888889;
                                break;
                            case 2:
                                //slow bicycle
                                activiteitNaam = "bicycle";
                                minsnelheid = 10;
                                maxsnelheid = 15;
                                maxbovendruk = 100;
                                calps = 0.056666667;
                                break;
                            case 3:
                                //fast bicycle
                                activiteitNaam = "fast bicycle";
                                minsnelheid = 15;
                                maxsnelheid = 30;
                                maxbovendruk = 160;
                                calps = 0.17;
                                break;
                            case 4:
                                //Jogging
                                activiteitNaam = "jogging";
                                minsnelheid = 8;
                                maxsnelheid = 11;
                                maxbovendruk = 140;
                                calps = 0.113333333;
                                break;
                            case 5:
                                //running
                                activiteitNaam = "running";
                                minsnelheid = 11;
                                maxsnelheid = 14;
                                maxbovendruk = 160;
                                calps = 0.194444444;
                                break;
                            case 6:
                                //sexual activity
                                activiteitNaam = "sexual activity";
                                minsnelheid = 0;
                                maxsnelheid = 0;
                                maxbovendruk = 160;
                                calps = 0.033333333;
                                break;
                            case 7:
                                //swimming
                                activiteitNaam = "swimming";
                                minsnelheid = 3;
                                maxsnelheid = 10;
                                maxbovendruk = 160;
                                calps = 0.138888889;
                                break;
                            case 8:
                                //Gardening
                                activiteitNaam = "gardening";
                                minsnelheid = 0;
                                maxsnelheid = 2;
                                maxbovendruk = 80;
                                calps = 0.055555556;
                                break;
                        }
                        //bloeddruk berekenen
                        int onderdruk = 0;
                        int bovendruk = 0;
                        int hartslag = 60;
                        do
                        {
                            onderdruk = random.Next(80, maxbovendruk);
                            bovendruk = random.Next(80, maxbovendruk);
                            hartslag = random.Next(60, maxbovendruk);
                        } while (onderdruk > bovendruk);



                        Model.Metingen meeting = new Model.Metingen()
                        {
                            meetingnummer = z,
                            //aantalseconden = secondenSindsStart,
                            bloeddruk = new Model.Bloeddruk() { onderdruk = onderdruk, bovendruk = bovendruk },
                            hartslag = hartslag,
                            snelheid = (random.NextDouble() * (maxsnelheid - minsnelheid) + minsnelheid)
                        };
                        model.metingen.Add(meeting);

                        //seconden sinds start optellen
                        secondenSindsStart = secondenSindsStart + 10;
                    }
                    model.activiteitNaam = activiteitNaam;
                    model.eindtijd = begintijd.AddSeconds(secondenSindsStart);
                    TimeSpan duurtijd = (model.eindtijd - model.starttijd);
                    model.calVerbrand = (calps * duurtijd.TotalSeconds) * (model.lengte / model.gewicht);

                    //model omvormen tot json en dan wegschrijven naar een bestand
                    string json = JsonConvert.SerializeObject(model);
                    Console.WriteLine("write line number " + i+ ":" +x);
                    System.IO.File.AppendAllText(@"C:\temp\mongoTestData.json", json);

                }
            }
            
            Console.WriteLine("Done writing file just press enter");
            Console.ReadLine();
            
        }
    }
}
