package be.kdg.shareit.biz.domain.gebruiker;


import be.kdg.shareit.biz.domain.lening.Reservatie;
import be.kdg.shareit.biz.domain.lening.ReservatieStatus;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jan on 3/12/2016.
 */
public class Gebruiker {

    private String naam;
    //private GeoLocatie locatie;
    private String email;
    private String password;
    private int deelpunten;
    private List<Reservatie> reservaties;

    public Gebruiker(String email, String password) {
        this.email=email;
        this.password=password;
        this.reservaties = new ArrayList<>();
    }
                                                                //ReservatieStatus.Type.GERESERVEERD
    public List<Reservatie> vraagReservatiesOp(ReservatieStatus.Type status, Gebruiker aanbieder) {
        List<Reservatie> afhalingsReservaties = new ArrayList<>();
        for (int i = 0; i < reservaties.size(); i++) {
            Reservatie huidigeReservatie = reservaties.get(i);
            LocalDate gereserveerdeDatum = huidigeReservatie.getDate();
            Gebruiker reservatieAanbieder = huidigeReservatie.getAanbieder();
            if (aanbieder.equals(reservatieAanbieder) && LocalDate.now().equals(gereserveerdeDatum) && status.equals(ReservatieStatus.Type.GERESERVEERD)) {
                afhalingsReservaties.add(huidigeReservatie);
            }
        }
        return afhalingsReservaties;
    }

    public String getEmail() {
        return email;
    }

    public void addReservatie(Reservatie rsv) {
        reservaties.add(rsv);
    }
}
