package be.kdg.shareit.biz.domain.lening;

import be.kdg.shareit.biz.domain.gebruiker.Gebruiker;


/**
 * Created by jan on 3/12/2016.
 */
public class Gereedschap {
    private Gebruiker aanbieder;
    private int dagPrijs;
    private String beschrijving;
    private int waarde;
    private int aankoopprijs;
    private GereedschapType gereedschapType;


    public Gereedschap(Gebruiker aanbieder, GereedschapType type, int dagPrijs, String beschrijving, int waarde, int aankoopprijs) {
        this.aanbieder = aanbieder;
        this.gereedschapType = type;
        this.dagPrijs = dagPrijs;
        this.beschrijving = beschrijving;
        this.waarde = waarde;
        this.aankoopprijs = aankoopprijs;
    }

    public Gebruiker getAanbieder() {
        return aanbieder;
    }

    public GereedschapType getGereedschapType() {
        return gereedschapType;
    }

    public int getDagPrijs() {
        return dagPrijs;
    }
}
