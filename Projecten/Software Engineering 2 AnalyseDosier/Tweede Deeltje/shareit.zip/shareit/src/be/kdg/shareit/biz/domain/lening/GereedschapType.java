package be.kdg.shareit.biz.domain.lening;

/**
 * Created by jan on 3/12/2016.
 */
public class GereedschapType {

	private long waarborg;
	private String naam;

	public GereedschapType(String naam, long waarborg) {
		this.naam = naam;
		this.waarborg = waarborg;
	}


	public long getWaarborg() {
		return waarborg;
	}
}
