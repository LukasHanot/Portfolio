package be.kdg.shareit.biz.domain.lening;

import be.kdg.shareit.biz.domain.gebruiker.Gebruiker;

import java.time.LocalDate;


/**
 * Created by jan on 3/12/2016.
 */
public class Reservatie {
	private LocalDate beginDate;
	private LocalDate eindDate;
	private Gereedschap gereedschap;
	private Gebruiker ontlener;


	public Reservatie(Gebruiker ontlener, Gereedschap gereedschap,  LocalDate from, LocalDate to) {
		this.ontlener = ontlener;
		this.gereedschap = gereedschap;
		this.beginDate = from;
		this.eindDate = to;
	}


	public LocalDate getDate() {
		return beginDate;
	}

	public Gebruiker getAanbieder() {
		return gereedschap.getAanbieder();
	}

	public Gereedschap getGereedschap() {
		return gereedschap;
	}

	public long getAantalDagen() {
		long aantalDagen;
		if (eindDate.toEpochDay() - beginDate.toEpochDay() == 0) {
			aantalDagen = 1;
		} else {
			aantalDagen = eindDate.toEpochDay() - beginDate.toEpochDay();
		}
		return aantalDagen;
	}
}
