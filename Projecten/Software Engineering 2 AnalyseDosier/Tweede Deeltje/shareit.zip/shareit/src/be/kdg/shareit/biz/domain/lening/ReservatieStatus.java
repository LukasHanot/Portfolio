package be.kdg.shareit.biz.domain.lening;

import java.time.LocalDateTime;
import java.time.chrono.ChronoLocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jan on 3/12/2016.
 */
public class ReservatieStatus {
	private Reservatie reservatie;
	private LocalDateTime tijdstip;
	private Type type;
	private Status status;

	public ReservatieStatus(Reservatie reservatie, Type type) {
		this.reservatie = reservatie;
		this.type = type;
		tijdstip = LocalDateTime.now();
		status = Status.ONBEVESTIGD;
	}

	public Type getType() {
		return type;
	}

	public Reservatie getReservatie() {
		return reservatie;
	}

	public enum Type {
		GERESERVEERD,
		AFGEHAALD, TERUGGEBRACHT,
		ANNULATIE_AANBIEDER,
		ANNULATIE_ONTLENER
	}

	public enum Status {
		ONBEVESTIGD, BEVESTIGD
	}
}
