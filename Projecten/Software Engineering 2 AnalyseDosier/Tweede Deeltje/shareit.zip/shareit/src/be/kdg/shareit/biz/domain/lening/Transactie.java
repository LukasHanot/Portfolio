package be.kdg.shareit.biz.domain.lening;


import be.kdg.shareit.biz.domain.gebruiker.Gebruiker;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by jan on 3/12/2016.
 */
public class Transactie {

	private Gebruiker aanbieder;
	private Gebruiker ontlener;
	private List<TransactieLijn> transactieLijnen;
	private LocalDateTime tijdstip;
	private Type type;
	private Status status;

	public Transactie(Gebruiker aanbieder, Gebruiker ontlener, List<Reservatie> selectieLijst, List<ReservatieStatus.Type>selectie, Transactie.Type type) {
		this.aanbieder = aanbieder;
		this.ontlener = ontlener;
		this.tijdstip = LocalDateTime.now();
		transactieLijnen = new ArrayList<>();
		this.type = type;
		this.status = Status.NIEUW;
		//Methode init aangemaakt omdat anders alles in constructor staat, heel onoverzichtelijk.
		init(selectieLijst, selectie);

	}

	private void init(List<Reservatie> selectieLijst, List<ReservatieStatus.Type> selectie) {
		for (int i = 0; i < selectieLijst.size(); i++) {
			ReservatieStatus reservatieStatus = new ReservatieStatus(selectieLijst.get(i), selectie.get(i));
			switch (selectie.get(i)) {
				case AFGEHAALD: transactieLijnen.add(new TransactieLijn(reservatieStatus, TransactieLijn.Type.WAARBORG));
					transactieLijnen.add(new TransactieLijn(reservatieStatus, TransactieLijn.Type.ONTLENING));
					break;
				case ANNULATIE_AANBIEDER: transactieLijnen.add(new TransactieLijn(reservatieStatus, TransactieLijn.Type.ANNULATIE));
					break;
				case ANNULATIE_ONTLENER: transactieLijnen.add(new TransactieLijn(reservatieStatus, TransactieLijn.Type.ANNULATIE));
					break;
			}
		}

	}

	public long getPrijs() {
		long kost = 0;
		for (TransactieLijn t: transactieLijnen ) {
			kost += t.getSharepoints();
		}
		return kost;
	}

	public Status getStatus() {
		return status;
	}

	public Gebruiker getAanbieder() {
		return aanbieder;
	}

	public Gebruiker getOntlener() {
		return ontlener;
	}

	public int getAantalLijnen(TransactieLijn.Type type) {
		int aantal = 0;
		for (TransactieLijn t:transactieLijnen) {
			if (t.getType().equals(type)) aantal++;
		}
		return aantal;
	}

	public int getAantalReservatieStatusAnnulatie(ReservatieStatus.Type type) {
		int aantal = 0;
		for (TransactieLijn t:transactieLijnen) {
			if (t.getReservatieStatus().getType().equals(type)) aantal++;
		}
		return aantal;
	}

	public int getAantalTransactieLijnen() {
		return transactieLijnen.size();
	}


	public enum Status {
		NIEUW, OK,
		GEEN_TOELATING,
		SALDO_ONTOEREIKEND,
		BETALING_MISLUKT
	}

	public enum Type {
		AFHALEN, TERUGBRENGEN, ANNULEREN, VERHANDELEN
	}



}
