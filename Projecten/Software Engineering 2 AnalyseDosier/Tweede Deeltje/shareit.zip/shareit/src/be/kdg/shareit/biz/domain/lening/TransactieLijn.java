package be.kdg.shareit.biz.domain.lening;

import java.time.LocalDate;

/**
 * Created by Tim on 17/12/2016.
 */
public class TransactieLijn {

    private long sharepoints;
    private float bedrag;
    private Type type;
    private ReservatieStatus reservatieStatus;

    public TransactieLijn(ReservatieStatus reservatieStatus, Type type) {
        this.type = type;
        this.reservatieStatus = reservatieStatus;
        this.bedrag = 0;
        initSharepoints();
    }

    private void initSharepoints() {
        switch (type) {
            case WAARBORG: this.sharepoints=reservatieStatus.getReservatie().getGereedschap().getGereedschapType().getWaarborg();
            break;
            case ONTLENING: this.sharepoints=((reservatieStatus.getReservatie().getGereedschap().getDagPrijs()) * (reservatieStatus.getReservatie().getAantalDagen()));
            break;
            case ANNULATIE: if (LocalDate.now().isAfter(reservatieStatus.getReservatie().getDate().minusDays(7))) this.sharepoints=(long)(((reservatieStatus.getReservatie().getGereedschap().getDagPrijs()) * (reservatieStatus.getReservatie().getAantalDagen()))*0.1);
            break;
        }
        if (reservatieStatus.getType().equals(ReservatieStatus.Type.ANNULATIE_AANBIEDER)) {
            this.sharepoints = this.sharepoints * (-1);
        }
    }

    public Type getType() {
        return type;
    }

    public ReservatieStatus getReservatieStatus() {
        return reservatieStatus;
    }

    public long getSharepoints() {
        return sharepoints;
    }


    public enum Type {
        WAARBORG, ONTLENING, VERHANDEL_SHAREPOINTS, ANNULATIE
    }
}
