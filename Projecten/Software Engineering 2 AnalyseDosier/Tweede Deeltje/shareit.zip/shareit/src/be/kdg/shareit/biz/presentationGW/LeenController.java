package be.kdg.shareit.biz.presentationGW;

import be.kdg.shareit.biz.domain.gebruiker.Gebruiker;
import be.kdg.shareit.biz.domain.lening.*;


import java.time.LocalDate;
import java.util.*;

/**
 * Created by jan on 3/12/2016.
 */
public class LeenController {
//TODO Vul  methoden aan
	private Gebruiker loggedIn;
	private List<Gebruiker> gebruikers;
	private Gebruiker huidigeOntlener;

	public LeenController() {
		this.gebruikers = new ArrayList<>();
	}

	public List<Reservatie> vraagAfhalingReservatiesOp(String ontlener){

		//TODO implementeer
		huidigeOntlener = new Gebruiker("groucho.marx@kdg.be", "S3cret");
		for (int i = 0; i < gebruikers.size(); i++) {
			if (gebruikers.get(i).getEmail().equals(ontlener)) {
				huidigeOntlener=gebruikers.get(i);
			}
		}
		return (huidigeOntlener.vraagReservatiesOp(ReservatieStatus.Type.GERESERVEERD, loggedIn));
	}

	public Transactie selecteerReservatiesVoorAfhaling(List<Reservatie> rsvs,List<ReservatieStatus.Type> selectie ){
		//TODO implementeer

		Transactie transactie = new Transactie(loggedIn, huidigeOntlener, rsvs, selectie, Transactie.Type.AFHALEN);
		return transactie;
	}


	public void setLoggedIn(Gebruiker loggedIn) {
		this.loggedIn = loggedIn;
	}

	public void addGereedschap(Gereedschap jlb) {

	}

	public void addGebruiker(Gebruiker gebruiker) {
		gebruikers.add(gebruiker);
	}

	public Gebruiker getLoggedIn() {
		return loggedIn;
	}

	public Gebruiker getHuidigeOntlener() {
		return huidigeOntlener;
	}
}
