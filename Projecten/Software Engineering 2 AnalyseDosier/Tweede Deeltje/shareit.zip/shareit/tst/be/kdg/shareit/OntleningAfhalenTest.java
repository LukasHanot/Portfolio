package be.kdg.shareit;


import be.kdg.shareit.biz.domain.gebruiker.Gebruiker;
import be.kdg.shareit.biz.domain.lening.*;
import be.kdg.shareit.biz.presentationGW.LeenController;
import org.junit.Before;
import org.junit.Test;

import java.time.LocalDate;
import java.util.*;

import static be.kdg.shareit.biz.domain.lening.ReservatieStatus.Type.*;

import static org.junit.Assert.*;

/**
 * Created by overvelj on 14/11/2016.
 */
public class OntleningAfhalenTest {

	LeenController ctrl;

	@Before
	public void setUp() throws Exception {
		// De setUp klasse dient om
		// en de testdata, die je nodig hebt voor je tests, aan te maken.
		// Maak nooit testdata in de domeinklassen zelf aan!
		// Initialiseer ook je systeem en maak het aanspreekpunt
		// beschikbaar in de testmethoden via een instantie variabele van je testklas


		// test data
		// Je mag de aanroepen aanpassen als dat beter overeenkomt met je project,
		// maar je mag geen testdata verwijderen (je mag als je dat wenst wel data toevoegen).
		Gebruiker groucho = new Gebruiker("groucho.marx@kdg.be", "S3cret");
		Gebruiker karl = new Gebruiker("karl.marx@kdg.be", "Boer3");
		Gebruiker chico = new Gebruiker("chico.marx@kdg.be", "Nite@Opera");
		GereedschapType woofers = new GereedschapType("woofer", 130);
		GereedschapType micros = new GereedschapType("microfoons", 60);
		Gereedschap jlb = new Gereedschap(chico, woofers, 25, "JLB SUB 550P ", 500, 600);
		Gereedschap bose = new Gereedschap(karl, woofers, 40, "Bose F1 Powered Subwoofer", 800, 1100);
		Gereedschap bw = new Gereedschap(karl, woofers, 20, "B&W ASW608", 400, 450);
		Gereedschap shure = new Gereedschap(karl, micros, 4, "Shure SM58 met statief en kabels", 94, 110);
		Gereedschap shure2 = new Gereedschap(karl, micros, 3, "Shure PGA48", 50, 50);
		Gereedschap electroVoice = new Gereedschap(karl, micros, 30,
			"Electro Voice RE 27 N/D dynamische zang- en instrumentmicrofoon", 640, 760);
		//  ONTLEENBAAR karl -> groucho
		Reservatie rsv1 = new Reservatie(groucho, bose, LocalDate.now(), LocalDate.now().plusDays(5));
		// niet ontleend (morgen)
		Reservatie rsv2 = new Reservatie(groucho, shure2, LocalDate.now().plusDays(1), LocalDate.now().plusDays(3));
		// niet ontleend (aanbieder = chico)
		Reservatie rsv3 = new Reservatie(groucho, jlb, LocalDate.now(), LocalDate.now().plusDays(2));
		// ONTLEENBAAR
		Reservatie rsv4 = new Reservatie(groucho, shure2, LocalDate.now(), LocalDate.now());
		// ONTLEENBAAR
		Reservatie rsv5 = new Reservatie(groucho, electroVoice, LocalDate.now(), LocalDate.now().plusDays(1));
		// niet ontleend (ontlener = chico)
		Reservatie rsv6 = new Reservatie(chico, shure, LocalDate.now(), LocalDate.now().plusDays(1));
		// ONTLEENBAAR
		Reservatie rsv7 = new Reservatie(groucho, bw, LocalDate.now(), LocalDate.now().plusDays(1));


		// TODO: initialisatie systeem
		ctrl = new LeenController();
		ctrl.addGebruiker(groucho);
		ctrl.addGebruiker(karl);
		ctrl.addGebruiker(chico);
		groucho.addReservatie(rsv1);
		groucho.addReservatie(rsv2);
		groucho.addReservatie(rsv3);
		groucho.addReservatie(rsv4);
		groucho.addReservatie(rsv5);
		chico.addReservatie(rsv6);
		groucho.addReservatie(rsv7);
		// Preconditie: de aanbieder was ingelogd en het systeem weet wie de actieve aanbieder is.
		// TODO: uncomment de volgende lijn na initialisatie systeem
    	ctrl.setLoggedIn (karl);
	}


	// Alle testmethoden krijgen een annotation @Test
	// Iedere uitgewerkte operatie heeft (minstens) 1 testmethode.
	// Voeg in elke testmethode voldoende Asserts toe voor
	//          de verwachtte inhoud van de returnvalues.
	//          Ook alle postcondities uit de operationcontracts moeten geverifiëerd worden.
	@Test
	public void vraagAfhalingsReservatiesOpTest() throws Exception {
		Collection<Reservatie> rsvs = ctrl.vraagAfhalingReservatiesOp("groucho.marx@kdg.be");
		assertEquals(4, rsvs.size());
	}

	@Test
	public void selecteerReservatiesVoorAfhalingTest() throws Exception {
		List<Reservatie> rsvs = ctrl.vraagAfhalingReservatiesOp("groucho.marx@kdg.be");
		Transactie tx=ctrl.selecteerReservatiesVoorAfhaling(rsvs,
			Arrays.asList(AFGEHAALD, AFGEHAALD, ANNULATIE_AANBIEDER, ANNULATIE_ONTLENER));
// TODO-	Een Transactie afhaling was aangemaakt en opgeslagen in het systeem.
// TODO test  de teruggegeven transactie als de transactie opgeslagen in het systeem

		assertNotNull(tx);

		//TODO		-	De afhaling.status werd op onbevestigd gezet.

		assertEquals( Transactie.Status.NIEUW, tx.getStatus());

//TODO			-	Transactie afhaling werd geassocieerd met de ontvangende gebruiker (aanbieder).

		assertEquals(ctrl.getLoggedIn(), tx.getAanbieder());

//TODO			-	Transactie afhaling werd geassocieerd met de betalende gebruiker (ontlener).

		assertEquals(ctrl.getHuidigeOntlener(), tx.getOntlener());

//TODO			-	Voor elke meegenomen reservatie werd een TransactieLijn gemaakt voor de waarborg.

		assertEquals(2, tx.getAantalLijnen(TransactieLijn.Type.WAARBORG));


//TODO		-	Voor elke meegenomen reservatie werd een TransactieLijn gemaakt voor de ontlening.

		assertEquals(2, tx.getAantalLijnen(TransactieLijn.Type.ONTLENING));

//TODO		-	Voor elke niet beschikbare reservatie werd een TransactieLijn gemaakt voor de annulatie met de aanbieder als betalende gebruiker
//TODO		-	Voor elke niet beschikbare reservatie werd een TransactieLijn gemaakt voor de annulatie met de aanbieder als betalende gebruiker

		assertEquals(2, tx.getAantalLijnen(TransactieLijn.Type.ANNULATIE));
		assertEquals(1, tx.getAantalReservatieStatusAnnulatie(ReservatieStatus.Type.ANNULATIE_AANBIEDER));
		assertEquals(1, tx.getAantalReservatieStatusAnnulatie(ReservatieStatus.Type.ANNULATIE_ONTLENER));


//TODO			-	Alle TransactieLijn werden gekoppeld aan hun reservatie//(-status)

		assertEquals(6, tx.getAantalTransactieLijnen());


//TODO		-	Het totale transactiebedrag is gelijk aan de som van de te transfereren sharepoints

		/*****************************************************************************************
		*rsv1 -> 5 dagen aan 40/dag = 200
		*			+waarborg(=130)
		*			tot = 330
		*rsv4 -> 0(?) dagen dus 1 dag aan 3/dag = 3
		*			+waarborg(=60)
		*			tot = 63
		*rsv5 -> 1 dag aan 30/dag = 30
		*			ANNULATIE dus 10% van 30(ontleenkost)
		*			tot = -3 (<- aanbieder annuleert dus sharepoints gaan naar ontlener)
		*rsv7 -> 1 dag aan 20/dag = 20
		*			ANNULATIE dus 10% van 20(ontleenkost)
		*			tot = 2
		*	Totale prijs van transactie = 330 + 63 + (-3) + 2
		*								= 392
		*******************************************************************************************/

		assertEquals(392, tx.getPrijs());

		}




	@Test
	public void bevestigAfhaling() throws Exception {
		assertTrue("Moet niet getest worden", true);
	}



}
